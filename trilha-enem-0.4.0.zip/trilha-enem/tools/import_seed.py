"""Import the attributed API ENEM transcription and cross-check it with INEP PDFs.
No network access: inputs are pinned, downloaded files. Never executes source code.
"""
import argparse, hashlib, json, re, shutil, subprocess
from pathlib import Path
from urllib.parse import urlparse, unquote
import fitz
from pdf_vectors import vector_region

ROOT=Path(__file__).resolve().parents[1]

def answer_key(pdf):
    lines=[s.strip() for s in fitz.open(pdf)[0].get_text().splitlines() if s.strip()]
    out={}
    for i,s in enumerate(lines):
        if not re.fullmatch(r'\d{1,3}',s):continue
        n=int(s)
        if not 1<=n<=180:continue
        if i+1<len(lines) and re.fullmatch(r'[ABCDE]|Anulado',lines[i+1],re.I):
            value=None if lines[i+1].lower()=='anulado' else lines[i+1].upper()
            if n<=5:
                out[(n,'ingles')]=value
                if i+2<len(lines) and re.fullmatch('[ABCDE]',lines[i+2]):out[(n,'espanhol')]=lines[i+2]
            else:out[(n,None)]=value
    return out

def markers(pdf):
    doc=fitz.open(pdf);found=[];seen={}
    for page_no,page in enumerate(doc):
        if page_no==0:continue
        for block in page.get_text('dict')['blocks']:
            for line in block.get('lines',[]):
                text=''.join(s['text']for s in line['spans']).strip();m=re.fullmatch(r'QUEST[ÃA]O\s+(\d{1,3})',text,re.I)
                if m:
                    n=int(m.group(1));x,y,x2,y2=line['bbox'];col=int(x>page.rect.width/2)
                    found.append({'number':n,'page':page_no,'column':col,'y':y,'x':x})
    layouts={}
    for page_no,page in enumerate(doc):
        own=[m for m in found if m['page']==page_no]
        top=min((m['y']for m in own),default=60)+20
        cross=any(len(''.join(s['text']for s in line['spans']).strip())>30 and line['bbox'][0]<page.rect.width*.4 and line['bbox'][2]>page.rect.width*.6 and top<line['bbox'][1]<page.rect.height-40 for block in page.get_text('dict')['blocks']for line in block.get('lines',[]))
        layouts[page_no]=2 if any(m['column']==1 for m in own) else 1 if cross else 2
    for m in found:m['columns']=layouts[m['page']]
    found.sort(key=lambda m:(m['page'],m['column'],m['y']))
    for m in found:
        n=m['number'];m['language']=('ingles' if seen.get(n,0)==0 else 'espanhol')if n<=5 else None;seen[n]=seen.get(n,0)+1
    return doc,found

def question_clips(doc,found,target):
    i=found.index(target);nxt=found[i+1]if i+1<len(found)else None;parts=[]
    for page_no in range(target['page'], (nxt['page']if nxt else target['page'])+1):
        page=doc[page_no];width,height=page.rect.width,page.rect.height
        page_markers=[m for m in found if m['page']==page_no];layout=page_markers[0]['columns']if page_markers else 2
        columns=[c for c in range(layout) if (page_no>target['page']or c>=target['column']) and (not nxt or page_no<nxt['page']or c<=nxt['column'])]
        for c in columns:
            top=target['y']-3 if page_no==target['page']and c==target['column']else 45
            bottom=nxt['y']-8 if nxt and page_no==nxt['page']and c==nxt['column']else height-40
            if bottom<=top+5:continue
            clip=fitz.Rect(26 if c==0 else width/2+5,top,width-25 if layout==1 else width/2-5 if c==0 else width-25,bottom)
            text=page.get_text(clip=clip).strip()
            if clip.height<40 and (not text or re.fullmatch(r'Questões de \d+ a \d+ \(opção (?:inglês|espanhol)\)',text,re.I)):continue
            parts.append((page,clip))
    return parts

def snapshot(public,year,doc,found,target):
    images=[];text=[]
    for index,(page,clip)in enumerate(question_clips(doc,found,target)):
        data=vector_region(page,clip)
        dst=public/'questions'/str(year)/f"original-{target['number']}-{target['language']or'pt'}-{index}-{hashlib.sha256(data).hexdigest()[:10]}.svg"
        dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
        images.append('/'+str(dst.relative_to(public)));text.append(page.get_text(clip=clip))
    if not images:raise ValueError('No original question region: '+repr(target))
    return '\n\n'.join(f'![Questão original do Inep]({p})'for p in images),''.join(text)

def run(source,official,years):
    raw=json.loads((official/'manifest.json').read_text());files={x['file']:x for x in raw};questions=[];coverage=[];corrections=[];missing_assets=[]
    public=ROOT/'public';(public/'sources').mkdir(parents=True,exist_ok=True)
    for item in raw:
        if Path(item['file']).name!=item['file']:raise ValueError('Invalid source filename')
        file=official/item['file']
        if hashlib.sha256(file.read_bytes()).hexdigest()!=item['sha256']:raise ValueError('Source checksum mismatch: '+item['file'])
        target=public/'sources'/item['file']
        if target.exists()and target.read_bytes()!=file.read_bytes():raise ValueError('A different preserved source already exists: '+item['file'])
        if file.resolve()!=target.resolve():shutil.copy2(file,target)
    commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()
    for year in years:
        keys={};exam_docs={};locations={}
        for day in [1,2]:
            cd=1 if day==1 else 7;name=f'{year}_PV_impresso_D{day}_CD{cd}.pdf';gb=f'{year}_GB_impresso_D{day}_CD{cd}.pdf'
            keys.update(answer_key(official/gb));doc,found=markers(official/name);exam_docs[day]=(doc,found)
            for m in found:locations[(m['number'],m['language'])]=m
        source_dir=source/'public'/str(year)/'questions';seen=set()
        for path in sorted(source_dir.glob('*/details.json')):
            body=path.read_bytes();x=json.loads(body);n=int(x['index']);language=x.get('language');key=(n,language);seen.add(key)
            if key not in keys:raise ValueError(f'No official answer: {year} {key}')
            day=1 if n<=90 else 2;cd=1 if day==1 else 7;pdf=f'{year}_PV_impresso_D{day}_CD{cd}.pdf';gb=f'{year}_GB_impresso_D{day}_CD{cd}.pdf'
            media_dir=public/'questions'/str(year)/path.parent.name;media_dir.mkdir(parents=True,exist_ok=True)
            asset_problem=[]
            def media(url):
                if not url:return None
                u=urlparse(url)
                if u.hostname not in ['enem.dev','api.enem.dev']:raise ValueError(f'Unknown media host: {u.hostname}')
                rel=Path(unquote(u.path).lstrip('/'));file=source/'public'/rel
                if not file.resolve().is_relative_to((source/'public').resolve())or not file.is_file():missing_assets.append(str(file));asset_problem.append(url);return None
                if file.suffix.lower()not in ['.png','.jpg','.jpeg','.webp','.gif']:asset_problem.append(url);missing_assets.append(str(file));return None
                data=file.read_bytes();dst=media_dir/(file.stem+'-'+hashlib.sha256(data).hexdigest()[:10]+file.suffix.lower());dst.write_bytes(data);return '/'+str(dst.relative_to(public))
            context=x.get('context')or''
            for url in set(re.findall(r'https://(?:api\.)?enem\.dev/[^\s)]+',context)+list(x.get('files')or[])):
                replacement=media(url)
                if replacement:context=context.replace(url,replacement)
            alternatives=[{'letter':a['letter'],'text':a.get('text')or'','image':media(a.get('file'))}for a in x['alternatives']]
            official_answer=keys[key];area='linguagens'if n<=45 else 'ciencias-humanas'if n<=90 else 'ciencias-natureza'if n<=135 else 'matematica'
            notes=[]
            if x.get('correctAlternative')!=official_answer:notes.append('Gabarito ajustado conforme PDF do Inep.');corrections.append({'year':year,'number':n,'field':'answer','from':x.get('correctAlternative'),'to':official_answer})
            if x.get('discipline')!=area:notes.append('Área ajustada conforme numeração do caderno azul.');corrections.append({'year':year,'number':n,'field':'area','from':x.get('discipline'),'to':area})
            m=locations.get(key)
            q={'id':f'enem-{year}-regular-{n}'+('-'+language if language else ''),'year':year,'edition':'regular','day':day,'number':n,'language':language,'area':area,'subject':None,'context':context,'prompt':x.get('alternativesIntroduction')or'Assinale a alternativa correta.','alternatives':alternatives,'answer':official_answer,'annulled':official_answer is None,'explanation':None,'source':{'originalUrl':files[pdf]['originalUrl'],'answerKeyUrl':files[gb]['originalUrl'],'mirrorUrl':f'https://github.com/yunger7/enem-api/blob/{commit}/public/{year}/questions/{path.parent.name}/details.json','sha256':files[pdf]['sha256'],'transcriptionSha256':hashlib.sha256(body).hexdigest(),'provider':'API ENEM','booklet':f'Azul · Caderno {cd}','page':m['page']+1 if m else None},'status':'reviewed','answerVerified':True,'reviewNote':' '.join(notes)or'Estrutura e gabarito conferidos automaticamente. Resolução comentada pendente.'}
            if asset_problem or len(alternatives)!=5 or {a['letter'] for a in alternatives}!=set('ABCDE'):
                if not m:raise ValueError('Missing original PDF marker for incomplete question')
                q['context'],original_text=snapshot(public,year,*exam_docs[day],m);q['prompt']='Leia a questão original acima e selecione a alternativa.';q['alternatives']=[{'letter':a,'text':f'Alternativa {a}','image':None}for a in 'ABCDE'];q['reviewNote']='Transcrição incompleta; conteúdo recuperado como recorte do PDF original.';q['source']['provider']='PDF do Inep (cópia do acervo)'
            q['fingerprint']=hashlib.sha256(json.dumps([q['context'],q['prompt'],alternatives],ensure_ascii=False,sort_keys=True).encode()).hexdigest();questions.append(q)
        expected={(n,lang)for n in range(1,6)for lang in ['ingles','espanhol']}|{(n,None)for n in range(6,181)}
        # Missing transcriptions are retained as faithful crops of the original PDF.
        for key in sorted(expected-seen,key=lambda k:(k[0],k[1]or'')):
            n,language=key;day=1 if n<=90 else 2;cd=1 if day==1 else 7;m=locations.get(key)
            if not m:continue
            doc,found=exam_docs[day];original_context,original_text=snapshot(public,year,doc,found,m)
            pdf=f'{year}_PV_impresso_D{day}_CD{cd}.pdf';gb=f'{year}_GB_impresso_D{day}_CD{cd}.pdf';answer=keys[key]
            q={'id':f'enem-{year}-regular-{n}'+('-'+language if language else ''),'year':year,'edition':'regular','day':day,'number':n,'language':language,'area':'linguagens'if n<=45 else 'ciencias-humanas'if n<=90 else 'ciencias-natureza'if n<=135 else 'matematica','subject':None,'context':original_context,'prompt':'Leia a questão original acima e selecione a alternativa.','alternatives':[{'letter':a,'text':f'Alternativa {a}','image':None}for a in 'ABCDE'],'answer':answer,'annulled':answer is None,'explanation':None,'source':{'originalUrl':files[pdf]['originalUrl'],'answerKeyUrl':files[gb]['originalUrl'],'mirrorUrl':files[pdf]['mirrorUrl'],'sha256':files[pdf]['sha256'],'provider':'PDF do Inep (cópia do acervo)','page':m['page']+1,'booklet':f'Azul · Caderno {cd}'},'status':'reviewed','answerVerified':True,'reviewNote':'Questão exibida como recorte fiel do PDF. Transcrição acessível pendente.','fingerprint':hashlib.sha256(original_text.encode()).hexdigest()}
            questions.append(q);seen.add(key)
        missing=[str(n)+('-'+lang if lang else '')for n,lang in expected-seen]
        coverage.append({'year':year,'edition':'Regular · azul · dois dias','available':len(seen),'expected':185,'reviewed':len(seen),'status':'Gabaritos conferidos; revisão editorial em andamento','missing':missing})
    questions.sort(key=lambda q:(-q['year'],q['number'],q['language']or''))
    # A varied, deterministic opening, preserving all question identities.
    priorities=[(2023,137,None),(2023,91,None),(2023,1,'ingles'),(2023,46,None)]
    priority={key:i for i,key in enumerate(priorities)}
    questions.sort(key=lambda q:priority.get((q['year'],q['number'],q['language']),1000))
    editorial_path=ROOT/'data/editorial.json'
    editorial=json.loads(editorial_path.read_text())if editorial_path.exists()else{}
    for q in questions:
        if q['id']in editorial:
            item=editorial[q['id']]
            if item['answer']!=q['answer']:raise ValueError('Editorial answer mismatch: '+q['id'])
            q['subject']=item['subject'];q['explanation']=item['explanation'];q['status']='published';q['reviewNote']='Resolução comentada conferida com o enunciado e o gabarito do PDF.'
    payload={'questions':questions,'coverage':coverage,'importedAt':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()}
    (ROOT/'data').mkdir(exist_ok=True);(ROOT/'data/catalog.json').write_text(json.dumps(payload,ensure_ascii=False,separators=(',',':')))
    report={'upstream':'yunger7/enem-api','commit':commit,'pdfSources':raw,'questions':len(questions),'coverage':coverage,'corrections':corrections,'missingAssets':missing_assets}
    (ROOT/'data/import-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    (ROOT/'third-party').mkdir(exist_ok=True);shutil.copy2(source/'LICENSE',ROOT/'third-party/API-ENEM-LICENSE.txt')
    print(json.dumps({'questions':len(questions),'coverage':coverage,'corrections':len(corrections),'pdfMarkers':{year:sum(len(markers(official/f'{year}_PV_impresso_D{day}_CD{1 if day==1 else 7}.pdf')[1])for day in [1,2])for year in years}},ensure_ascii=False,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--official',type=Path,required=True);p.add_argument('--years',type=int,nargs='+',default=[2022,2023]);args=p.parse_args();run(args.source.resolve(),args.official.resolve(),args.years)
