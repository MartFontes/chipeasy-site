"""Render a PDF region as SVG while preserving native vectors and source pixels."""
import xml.etree.ElementTree as ET
ET.register_namespace('','http://www.w3.org/2000/svg')
ET.register_namespace('xlink','http://www.w3.org/1999/xlink')

def vector_region(page,clip):
    svg=ET.fromstring(page.get_svg_image(text_as_path=True))
    svg.set('viewBox',f'{clip.x0:g} {clip.y0:g} {clip.width:g} {clip.height:g}')
    svg.set('width',str(round(clip.width*4)))
    svg.set('height',str(round(clip.height*4)))
    return ET.tostring(svg,encoding='utf-8',xml_declaration=True)
