import assert from "node:assert/strict";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import { chromium } from "@playwright/test";

const base = process.env.TEST_BASE_URL || "http://127.0.0.1:3100";
const previews = "docs/previews";
const catalog = JSON.parse(
  await readFile("data/catalog.json", "utf8"),
).questions;
const browser = await chromium.launch({
  executablePath:
    process.env.CHROMIUM_PATH ||
    (existsSync("/usr/bin/chromium") ? "/usr/bin/chromium" : undefined),
  args: ["--no-sandbox"],
});
const report = [];
await mkdir(previews, { recursive: true });
async function navigate(page, name) {
  const menu = page.getByRole("button", { name: "Abrir menu", exact: true });
  if (await menu.isVisible()) await menu.click();
  await page.getByRole("button", { name, exact: true }).click();
}
async function check(page, width, screen) {
  const layout = await page.evaluate(() => ({
    page: document.documentElement.scrollWidth <= innerWidth,
    dialogs: [
      ...document.querySelectorAll('[role="dialog"],dialog[open]'),
    ].every((el) => el.scrollWidth <= el.clientWidth + 1),
  }));
  assert(layout.page && layout.dialogs, `${width}px: overflow em ${screen}`);
  report.push({ width, screen, overflow: false });
}
async function answerCurrent(page) {
  const label = await page.getByRole("dialog").getAttribute("aria-label");
  const match = label.match(/Questão (\d+) do Enem (\d+)/);
  const q = catalog.find(
    (q) =>
      q.number === Number(match[1]) &&
      q.year === Number(match[2]) &&
      q.language !== "espanhol",
  );
  await page.keyboard.press(q.answer.toLowerCase());
  await page
    .getByRole("button", { name: "Conferir resposta", exact: true })
    .click();
}
try {
  for (const width of [320, 393, 768, 1024, 1440]) {
    const context = await browser.newContext({
      viewport: { width, height: width < 721 ? 852 : 1000 },
      isMobile: width < 721,
      hasTouch: width < 721,
    });
    const page = await context.newPage();
    const errors = [];
    const remote = [];
    page.on("pageerror", (e) => errors.push(e.message));
    page.on("request", (r) => {
      if (!r.url().startsWith(base) && /^https?:/.test(r.url()))
        remote.push(r.url());
    });
    await page.goto(base, { waitUntil: "networkidle" });
    await page.evaluate(() => document.fonts.ready);
    const fonts = await page.evaluate(() =>
      [...document.fonts]
        .filter((f) => f.status === "loaded")
        .map((f) => f.family),
    );
    assert(fonts.length >= 2, `${width}px: fontes não carregadas`);
    await check(page, width, "jornada");
    const name = width === 1440 ? "desktop" : width === 393 ? "mobile" : null;
    if (name) {
      await page.screenshot({ path: `${previews}/${name}.png` });
      await page.screenshot({
        path: `${previews}/${name}-full.png`,
        fullPage: true,
      });
    }
    if (width === 768)
      await page.screenshot({ path: `${previews}/tablet.png`, fullPage: true });
    for (const area of [
      "Ciências Humanas",
      "Ciências da Natureza",
      "Matemática",
      "Linguagens",
    ]) {
      await page.getByRole("button", { name: area, exact: true }).click();
      await check(page, width, `mundo-${area}`);
    }
    await page
      .getByRole("button", { name: "Começar minha jornada", exact: true })
      .click();
    await page.locator(".question-overlay").evaluate((el) => el.scrollTo(0, 0));
    await check(page, width, "leitor");
    if (name) {
      await page.waitForTimeout(250);
      await page.screenshot({ path: `${previews}/reader-${name}.png` });
    }
    for (let i = 0; i < 5; i++) {
      await answerCurrent(page);
      await page
        .getByRole("button", {
          name: i === 4 ? "Concluir lição" : "Próxima questão",
          exact: true,
        })
        .click();
    }
    await check(page, width, "conclusão");
    if (name) {
      await page.waitForTimeout(500);
      await page.screenshot({ path: `${previews}/celebration-${name}.png` });
      if (width === 1440)
        await page.screenshot({ path: `${previews}/celebration.png` });
    }
    await page
      .getByRole("dialog")
      .getByRole("button", { name: "Continuar minha jornada", exact: true })
      .click();
    await page
      .getByRole("button", {
        name: "Abrir baú diário, bônus recebido",
        exact: true,
      })
      .click();
    await check(page, width, "baú");
    if (name) {
      await page.waitForTimeout(400);
      await page.screenshot({ path: `${previews}/chest-${name}.png` });
    }
    await page.keyboard.press("Escape");
    for (const screen of [
      "Meu espaço",
      "Banco de questões",
      "Caderno de erros",
      "Favoritos",
      "Meus simulados",
      "Meu desempenho",
      "Meu perfil",
    ]) {
      await navigate(page, screen);
      await check(page, width, screen);
      if (name && ["Banco de questões", "Meu desempenho"].includes(screen)) {
        const file = screen === "Banco de questões" ? "library" : "progress";
        await page.screenshot({
          path: `${previews}/${file}-${name}.png`,
          fullPage: true,
        });
      }
    }
    for (const url of ["/acervo", "/revisao"]) {
      await page.goto(base + url);
      await page.getByRole("heading", { level: 1 }).waitFor();
      await check(page, width, url);
    }
    assert.deepEqual(errors, [], `${width}px: erros JavaScript`);
    assert.deepEqual(remote, [], `${width}px: solicitações externas`);
    await context.close();
  }
  await writeFile(
    "docs/interface-validation.json",
    JSON.stringify(
      {
        version: "0.4.0",
        layouts: report.length,
        javascriptErrors: 0,
        externalRequests: 0,
        results: report,
      },
      null,
      2,
    ) + "\n",
  );
  console.log(
    JSON.stringify({
      layouts: report.length,
      overflow: 0,
      javascriptErrors: 0,
      externalRequests: 0,
    }),
  );
} finally {
  await browser.close();
}
