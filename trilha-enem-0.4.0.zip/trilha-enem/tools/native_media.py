"""Recover figures from the original PDF as vectors, without redrawing exam data.
OpenCV is used only to locate the existing figure in the PDF, never to enhance it.
"""
import argparse,hashlib,json,re,sys
from pathlib import Path
import fitz
from import_seed import markers,question_clips
from pdf_vectors import vector_region

ROOT=Path(__file__).resolve().parents[1]
def save_region(year,number,page,clip,kind):
    data=vector_region(page,clip)
    path=ROOT/f'public/questions/{year}/vector-{number}-{kind}-{hashlib.sha256(data).hexdigest()[:12]}.svg'
    path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    return '/'+path.relative_to(ROOT/'public').as_posix()

def locate(image_path,regions,min_confidence=.9):
    import cv2,numpy as np
    template=cv2.imread(str(image_path),cv2.IMREAD_GRAYSCALE)
    if template is None or template.std()<8:return None
    ys,xs=np.where(template<235)
    if not len(xs):return None
    left,right,top,bottom=max(0,int(xs.min())-1),min(template.shape[1],int(xs.max())+2),max(0,int(ys.min())-1),min(template.shape[0],int(ys.max())+2)
    template=template[top:bottom,left:right]
    best=None
    def check(scale):
        nonlocal best
        w,h=round(template.shape[1]*scale),round(template.shape[0]*scale)
        if min(w,h)<16:return
        resized=cv2.resize(template,(w,h),interpolation=cv2.INTER_AREA if scale<1 else cv2.INTER_CUBIC)
        for page,clip,gray in regions:
            if w>=gray.shape[1]or h>=gray.shape[0]:continue
            result=cv2.matchTemplate(gray,resized,cv2.TM_CCOEFF_NORMED)
            _,score,_,point=cv2.minMaxLoc(result)
            if best is None or score>best['score']:best={'score':float(score),'scale':float(scale),'point':point,'width':w,'height':h,'page':page,'clip':clip}
    for scale in np.geomspace(.12,4,36):check(scale)
    if not best:return None
    scale=best['scale']
    for scale in np.linspace(scale*.92,scale*1.08,15):check(scale)
    if best['score']<min_confidence:return None
    x,y=best['point'];clip=best['clip'];dpi_scale=2.5
    box=fitz.Rect(clip.x0+x/dpi_scale-1.5,clip.y0+y/dpi_scale-1.5,clip.x0+(x+best['width'])/dpi_scale+1.5,clip.y0+(y+best['height'])/dpi_scale+1.5)&clip
    return best['page'],box,best['score']

def run(match_figures):
    qs=json.loads((ROOT/'data/catalog.json').read_text())['questions'];docs={};mapping={};records=[];unmatched=[];hidden=[]
    approved={a['old']:a for a in json.loads((ROOT/'data/media-approvals.json').read_text())}if(ROOT/'data/media-approvals.json').exists()else{}
    for q in qs:
        paths=list(dict.fromkeys(re.findall(r'!\[[^\]]*\]\((/questions/[^)]+)\)',q['context'])+[a['image']for a in q['alternatives']if a['image']]))
        if not paths:continue
        source=q['source']['originalUrl'].split('/')[-1]
        if source not in docs:docs[source]=markers(ROOT/'public/sources'/source)
        doc,found=docs[source];marker=next(m for m in found if m['number']==q['number']and m['language']==q['language'])
        clips=question_clips(doc,found,marker);regions=[]
        if match_figures and any('/original-'not in path for path in paths):
            import cv2,numpy as np
            for page,clip in clips:
                pix=page.get_pixmap(matrix=fitz.Matrix(2.5,2.5),clip=clip,colorspace=fitz.csGRAY,alpha=False)
                regions.append((page,clip,np.frombuffer(pix.samples,dtype=np.uint8).reshape(pix.height,pix.width)))
        for path in paths:
            if path in mapping:continue
            manual=approved.get(path)
            if manual:
                if manual['questionId']!=q['id']or manual['pdf']!=source:raise ValueError('Approved media source mismatch')
                page=doc[manual['page']-1];clip=fitz.Rect(manual['clip']);score=None;kind='figure'
                if not page.rect.contains(clip):raise ValueError('Approved media region outside page')
            elif '/original-'in path:
                match=re.search(r'-(\d+)-[a-f0-9]+\.jpg$',path)
                if not match:continue # already a vector from a new import
                index=int(match.group(1))
                if index>=len(clips):hidden.append(path);continue
                page,clip=clips[index];score=1.0;kind='question'
            elif match_figures:
                if path in [a['image']for a in q['alternatives']]:
                    # Similar circuits, formulas and graphs can correlate highly
                    # while representing different answers. Only reviewed regions
                    # may replace an alternative; a match score is insufficient.
                    unmatched.append(path);continue
                result=locate(ROOT/'public'/path.lstrip('/'),regions)
                if not result:unmatched.append(path);continue
                page,clip,score=result
                kind='figure'
            else:continue
            new=save_region(q['year'],q['number'],page,clip,kind);mapping[path]=new
            records.append({'old':path,'new':new,'questionId':q['id'],'pdf':source,'page':page.number+1,'clip':list(clip),'confidence':round(score,5)if score is not None else None,'kind':kind,'manualReview':bool(manual),'alternativeLetter':manual.get('alternativeLetter')if manual else None})
        print(q['id'],len(mapping),'recuperadas',flush=True)
    (ROOT/'data/media-map.json').write_text(json.dumps(mapping,ensure_ascii=False,indent=2)+'\n')
    (ROOT/'data/media-hidden.json').write_text(json.dumps(hidden,indent=2)+'\n')
    report={'method':'Native PDF vectors and original embedded images. No generative changes, sharpening or bitmap upscaling.','upgraded':len(mapping),'questionCrops':sum(r['kind']=='question'for r in records),'figures':sum(r['kind']=='figure'for r in records),'records':records,'unmatched':unmatched,'hiddenHeaderFragments':hidden}
    (ROOT/'data/media-quality.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items()if k not in ['records','unmatched']},ensure_ascii=False))

def refresh_crops():
    report=json.loads((ROOT/'data/media-quality.json').read_text());mapping=json.loads((ROOT/'data/media-map.json').read_text());qs={q['id']:q for q in json.loads((ROOT/'data/catalog.json').read_text())['questions']};docs={}
    for record in report['records']:
        if record['kind']!='question':continue
        q=qs[record['questionId']];pdf=record['pdf']
        if pdf not in docs:docs[pdf]=markers(ROOT/'public/sources'/pdf)
        doc,found=docs[pdf];marker=next(m for m in found if m['number']==q['number']and m['language']==q['language']);index=int(re.search(r'-(\d+)-[a-f0-9]+\.jpg$',record['old']).group(1));page,clip=question_clips(doc,found,marker)[index]
        record.update(new=save_region(q['year'],q['number'],page,clip,'question'),clip=list(clip),page=page.number+1);mapping[record['old']]=record['new']
    (ROOT/'data/media-quality.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');(ROOT/'data/media-map.json').write_text(json.dumps(mapping,ensure_ascii=False,indent=2)+'\n')
    print('Recortes vetoriais atualizados:',report['questionCrops'])

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--match-figures',action='store_true');parser.add_argument('--refresh-crops',action='store_true');args=parser.parse_args()
    if args.refresh_crops:refresh_crops()
    else:run(args.match_figures)
