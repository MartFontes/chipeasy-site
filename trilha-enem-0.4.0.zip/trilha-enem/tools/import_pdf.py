"""Create a review batch from a text/OCR ENEM PDF and its answer key.
Full question crops preserve formulas, graphs and alternatives. Nothing is auto-published.
"""
import argparse, hashlib, json, re, shutil, subprocess, tempfile
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse
import fitz
from import_seed import markers, snapshot, answer_key

ROOT=Path(__file__).resolve().parents[1]

def ocr_pdf(source,dest):
    if not shutil.which('tesseract'):raise ValueError('Instale o Tesseract para usar --ocr.')
    languages=subprocess.check_output(['tesseract','--list-langs'],text=True,stderr=subprocess.STDOUT)
    language='por+eng'if'por'in languages.splitlines()else'eng'
    original=fitz.open(source);combined=fitz.open()
    for n,page in enumerate(original):
        image=dest.parent/f'ocr-{n}.png';page.get_pixmap(dpi=160).save(image)
        prefix=dest.parent/f'ocr-{n}'
        subprocess.run(['tesseract',str(image),str(prefix),'-l',language,'pdf'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=150)
        combined.insert_pdf(fitz.open(str(prefix)+'.pdf'))
    combined.save(dest)
    return language

def run(args):
    for file in [args.exam,args.answers]:
        if not file.is_file()or file.stat().st_size>60*1024*1024:raise ValueError('Os PDFs devem existir e ter até 60 MB cada.')
        with fitz.open(file)as d:
            if len(d)>120:raise ValueError('O limite é de 120 páginas por documento.')
    if args.year<2010:raise ValueError('O importador automático inicial usa o formato de 2010 em diante. Edições anteriores exigem um adaptador de classificação e numeração.')
    source_url=args.source_url or 'https://download.inep.gov.br/enem/provas_e_gabaritos/'+args.exam.name
    answers_url=args.answer_key_url or 'https://download.inep.gov.br/enem/provas_e_gabaritos/'+args.answers.name
    if any(urlparse(s).scheme!='https'for s in [source_url,answers_url]):raise ValueError('Informe URLs HTTPS para a proveniência.')
    with tempfile.TemporaryDirectory(prefix='trilha-ocr-')as tmp:
        temp=Path(tmp);exam=args.exam;answers=args.answers;ocr_language=None
        if args.ocr:
            exam=temp/'exam-ocr.pdf';answers=temp/'answers-ocr.pdf';ocr_language=ocr_pdf(args.exam,exam);ocr_pdf(args.answers,answers)
        keys=answer_key(answers);doc,found=markers(exam)
        if not found:raise ValueError('Nenhuma questão identificada. Se o PDF for uma imagem, use --ocr e revise o resultado.')
        sha=hashlib.sha256(args.exam.read_bytes()).hexdigest();gbsha=hashlib.sha256(args.answers.read_bytes()).hexdigest();questions=[];issues=[];seen=set()
        (ROOT/'public/sources').mkdir(parents=True,exist_ok=True)
        for source in [args.exam,args.answers]:
            target=ROOT/'public/sources'/source.name
            if target.exists() and target.read_bytes()!=source.read_bytes():
                raise ValueError('Já existe um PDF diferente com esse nome. Renomeie a nova origem para preservar a prova anterior.')
            if source.resolve()!=target.resolve():shutil.copy2(source,target)
        for m in found:
            n,language=m['number'],m['language'];key=(n,language)
            if key in seen:issues.append(f'Marcador repetido: {key}');continue
            seen.add(key)
            context,text=snapshot(ROOT/'public',args.year,doc,found,m)
            has_answer=key in keys;answer=keys.get(key)
            if not has_answer:issues.append(f'Gabarito não identificado: {key}')
            q={'id':f'enem-{args.year}-{args.edition}-{n}'+('-'+language if language else ''),'year':args.year,'edition':args.edition,'day':args.day,'number':n,'language':language,'area':'linguagens'if n<=45 else 'ciencias-humanas'if n<=90 else 'ciencias-natureza'if n<=135 else 'matematica','subject':None,'context':context,'prompt':'Leia a questão original acima e selecione a alternativa.','alternatives':[{'letter':a,'text':f'Alternativa {a}','image':None}for a in'ABCDE'],'answer':answer,'annulled':has_answer and answer is None,'explanation':None,'source':{'originalUrl':source_url,'answerKeyUrl':answers_url,'mirrorUrl':source_url,'sha256':sha,'provider':'PDF importado para revisão','page':m['page']+1,'booklet':args.booklet},'status':'imported','answerVerified':False,'reviewNote':'Conferir recorte, comando, alternativas e gabarito antes da publicação.'+(' OCR utilizado: '+ocr_language+'.'if ocr_language else''),'fingerprint':hashlib.sha256(re.sub(r'QUESTÃO\s+\d+','',text).strip().encode()).hexdigest()}
            questions.append(q)
        expected=95 if args.day==1 else 90
        if len(questions)!=expected:issues.append(f'Contagem {len(questions)}; esperadas {expected} no formato regular com as duas línguas.')
        args.output.parent.mkdir(parents=True,exist_ok=True)
        result={'questions':questions,'report':{'createdAt':datetime.now(timezone.utc).isoformat(),'sourceSha256':sha,'answerKeySha256':gbsha,'identified':len(questions),'expected':expected,'ocr':ocr_language,'issues':issues,'autoPublished':False}}
        args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result['report'],ensure_ascii=False,indent=2));print('Lote para revisão:',args.output)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--exam',type=Path,required=True);p.add_argument('--answers',type=Path,required=True);p.add_argument('--year',type=int,required=True);p.add_argument('--day',type=int,choices=[1,2],required=True);p.add_argument('--edition',default='regular');p.add_argument('--booklet',default='Azul');p.add_argument('--source-url');p.add_argument('--answer-key-url');p.add_argument('--output',type=Path,default=ROOT/'data/staging/import.json');p.add_argument('--ocr',action='store_true');args=p.parse_args()
    if not re.fullmatch('[a-z0-9-]{1,40}',args.edition):p.error('Identificador de edição inválido.')
    try:run(args)
    except (ValueError,RuntimeError,subprocess.SubprocessError)as e:p.exit(1,str(e)+'\n')
