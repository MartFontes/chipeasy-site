"""Download official INEP exam/answer-key PDFs with a manifest and SHA256."""
import argparse,hashlib,json,re
from pathlib import Path
from urllib.request import urlopen
from urllib.parse import urlparse

ROOT=Path(__file__).resolve().parents[1]
def run(year,day,booklet,out):
    out.mkdir(parents=True,exist_ok=True);items=[]
    for kind in ['PV','GB']:
        name=f'{year}_{kind}_impresso_D{day}_CD{booklet}.pdf';url='https://download.inep.gov.br/enem/provas_e_gabaritos/'+name
        with urlopen(url,timeout=45)as r:
            if urlparse(r.geturl()).hostname!='download.inep.gov.br':raise ValueError('O download foi redirecionado para uma origem diferente.')
            data=r.read(60*1024*1024+1)
        if len(data)>60*1024*1024 or not data.startswith(b'%PDF'):raise ValueError('Resposta inválida; confirme o endereço na página de provas do Inep.')
        dest=out/name
        if dest.exists()and dest.read_bytes()!=data:raise ValueError('O arquivo existente difere do download. Preserve-o e revise a nova versão.')
        dest.write_bytes(data);items.append({'file':name,'originalUrl':url,'sha256':hashlib.sha256(data).hexdigest()})
    (out/f'manifest-{year}-{day}-{booklet}.json').write_text(json.dumps(items,indent=2));print(json.dumps(items,indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--year',type=int,required=True);p.add_argument('--day',type=int,choices=[1,2],required=True);p.add_argument('--booklet',type=int,choices=range(1,9),required=True);p.add_argument('--output',type=Path,default=ROOT/'data/raw/official');a=p.parse_args();run(a.year,a.day,a.booklet,a.output)
