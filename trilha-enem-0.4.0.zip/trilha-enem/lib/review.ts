import { z } from "zod";
import type { Question } from "./types";
const letter = z.enum(["A", "B", "C", "D", "E"]);
const https = z
  .string()
  .url()
  .refine((s) => s.startsWith("https://"), "Use uma fonte HTTPS.");
const image = z
  .string()
  .max(500)
  .refine(
    (s) => s.startsWith("/questions/") && !s.includes(".."),
    "A imagem deve pertencer ao acervo.",
  );
export const questionSchema = z
  .object({
    id: z.string().regex(/^[a-z0-9-]{3,120}$/),
    year: z.number().int().min(1998).max(2100),
    edition: z.string().min(1).max(80),
    day: z.number().int().min(1).max(2),
    number: z.number().int().min(1).max(500),
    language: z.enum(["ingles", "espanhol"]).nullable(),
    area: z.enum([
      "linguagens",
      "ciencias-humanas",
      "ciencias-natureza",
      "matematica",
    ]),
    subject: z.string().max(160).nullable(),
    context: z.string().max(60000),
    prompt: z.string().max(10000),
    alternatives: z
      .array(
        z.object({
          letter,
          text: z.string().max(10000),
          image: image.nullable(),
        }),
      )
      .length(5),
    answer: letter.nullable(),
    annulled: z.boolean(),
    explanation: z.string().max(40000).nullable(),
    source: z.object({
      originalUrl: https,
      answerKeyUrl: https,
      mirrorUrl: https,
      sha256: z.string().regex(/^[a-f0-9]{64}$/),
      transcriptionSha256: z
        .string()
        .regex(/^[a-f0-9]{64}$/)
        .optional(),
      provider: z.string().min(1).max(160),
      page: z.number().int().positive().optional(),
      booklet: z.string().max(100).nullable(),
    }),
    status: z.enum(["imported", "reviewed", "published"]),
    answerVerified: z.boolean(),
    reviewNote: z.string().max(6000),
    fingerprint: z.string().regex(/^[a-f0-9]{64}$/),
  })
  .superRefine((q, ctx) => {
    if (new Set(q.alternatives.map((a) => a.letter)).size !== 5)
      ctx.addIssue({ code: "custom", message: "Alternativas repetidas." });
    if (q.annulled && q.answer !== null)
      ctx.addIssue({
        code: "custom",
        message: "Questão anulada deve ter gabarito nulo.",
      });
    if (
      q.status === "published" &&
      (!q.answerVerified ||
        (!q.annulled && !q.answer) ||
        !q.context.trim() ||
        !q.prompt.trim())
    )
      ctx.addIssue({
        code: "custom",
        message: "Para publicar, confira conteúdo e gabarito.",
      });
  });
export const WORKSPACE_KEY = "trilha-enem.review.v1";
export type Workspace = {
  version: 1;
  questions: Question[];
  updatedAt: string;
};
export function readWorkspace(): Workspace {
  try {
    const value = JSON.parse(localStorage.getItem(WORKSPACE_KEY) || "null");
    if (value?.version === 1 && Array.isArray(value.questions))
      return {
        version: 1,
        questions: value.questions.map((q: unknown) => questionSchema.parse(q)),
        updatedAt: value.updatedAt,
      };
  } catch {
    /* preserve the source; invalid edits are not applied */
  }
  return { version: 1, questions: [], updatedAt: new Date().toISOString() };
}
export function mergeCatalog(base: Question[], incoming: Question[]) {
  const map = new Map(base.map((q) => [q.id, q])),
    fingerprints = new Map(base.map((q) => [q.fingerprint, q.id]));
  let added = 0,
    updated = 0,
    duplicates = 0;
  for (const item of incoming) {
    const q = questionSchema.parse(item),
      same = fingerprints.get(q.fingerprint);
    if (same && same !== q.id) {
      duplicates++;
      continue;
    }
    if (map.has(q.id)) updated++;
    else added++;
    map.set(q.id, q);
    fingerprints.set(q.fingerprint, q.id);
  }
  return { questions: [...map.values()], added, updated, duplicates };
}
