import plan from "../data/journey-plan.json";
import { dayKey } from "./study";
import type { Area, Attempt, Progress, Question } from "./types";
import { AREAS } from "./types";

export const XP_PER_LEVEL = 200;
export const WORLDS: Record<
  Area,
  { title: string; subtitle: string; icon: string; color: string }
> = {
  linguagens: {
    title: "O bosque das palavras",
    subtitle: "Leia, interprete e descubra novos sentidos.",
    icon: "book",
    color: AREAS.linguagens.color,
  },
  "ciencias-humanas": {
    title: "Os caminhos da história",
    subtitle: "Entenda as pessoas e o mundo que construímos.",
    icon: "compass",
    color: AREAS["ciencias-humanas"].color,
  },
  "ciencias-natureza": {
    title: "O vale das descobertas",
    subtitle: "Investigue a vida e a natureza ao seu redor.",
    icon: "leaf",
    color: AREAS["ciencias-natureza"].color,
  },
  matematica: {
    title: "A montanha dos desafios",
    subtitle: "Um raciocínio de cada vez, até o próximo topo.",
    icon: "mountain",
    color: AREAS.matematica.color,
  },
};
export type Lesson = {
  id: string;
  area: Area;
  number: number;
  questionIds: string[];
  answered: number;
  correct: number;
  completed: boolean;
  unlocked: boolean;
  stars: number;
};
const ordinal = (day: string) =>
  Math.floor(Date.parse(day + "T00:00:00Z") / 86400000);
export const keyFromOrdinal = (day: number) =>
  new Date(day * 86400000).toISOString().slice(0, 10);

export function activityDays(attempts: Attempt[], now = new Date()) {
  const today = ordinal(dayKey(now)),
    days = [
      ...new Set(
        attempts
          .filter(
            (a) =>
              Number.isFinite(Date.parse(a.answeredAt)) &&
              Date.parse(a.answeredAt) <= now.getTime(),
          )
          .map((a) => ordinal(dayKey(a.answeredAt))),
      ),
    ].sort((a, b) => a - b);
  let best = 0,
    run = 0,
    previous = -Infinity;
  for (const day of days) {
    run = day === previous + 1 ? run + 1 : 1;
    best = Math.max(best, run);
    previous = day;
  }
  let current = 0,
    cursor = days.includes(today) ? today : today - 1;
  const set = new Set(days);
  while (set.has(cursor)) {
    current++;
    cursor--;
  }
  return {
    current,
    best,
    studiedToday: set.has(today),
    days: days.map(keyFromOrdinal),
    week: Array.from({ length: 7 }, (_, i) => ({
      key: keyFromOrdinal(today - 6 + i),
      active: set.has(today - 6 + i),
      today: i === 6,
    })),
    activeThisWeek: days.filter((d) => d >= today - 6).length,
  };
}

export function journeyStats(
  progress: Progress,
  questions: Question[],
  now = new Date(),
) {
  const known = new Map(questions.map((q) => [q.id, q]));
  const attempts = [
    ...new Map(progress.attempts.map((a) => [a.id, a])).values(),
  ]
    .filter(
      (a) =>
        known.has(a.questionId) &&
        Number.isFinite(Date.parse(a.answeredAt)) &&
        Date.parse(a.answeredAt) <= now.getTime(),
    )
    .sort((a, b) => Date.parse(a.answeredAt) - Date.parse(b.answeredAt));
  const answered = new Set<string>(),
    correct = new Set<string>(),
    daily = new Map<string, Set<string>>(),
    dailyCorrect = new Map<string, Set<string>>(),
    dailyAreas = new Map<string, Set<Area>>();
  let xp = 0,
    todayXp = 0,
    weekXp = 0;
  const today = dayKey(now),
    weekStart = ordinal(today) - 6;
  for (const a of attempts) {
    const key = dayKey(a.answeredAt);
    let earned = 0;
    if (!answered.has(a.questionId)) {
      answered.add(a.questionId);
      earned += 10;
    }
    const q = known.get(a.questionId)!;
    if (a.correct === true && !q.annulled && q.answer) {
      if (!correct.has(a.questionId)) {
        correct.add(a.questionId);
        earned += 10;
      }
      if (!dailyCorrect.has(key)) dailyCorrect.set(key, new Set());
      dailyCorrect.get(key)!.add(a.questionId);
    }
    if (!daily.has(key)) daily.set(key, new Set());
    const before = daily.get(key)!.size;
    daily.get(key)!.add(a.questionId);
    if (before < 5 && daily.get(key)!.size >= 5) earned += 30;
    if (!dailyAreas.has(key)) dailyAreas.set(key, new Set());
    dailyAreas.get(key)!.add(q.area);
    xp += earned;
    if (key === today) todayXp += earned;
    if (ordinal(key) >= weekStart) weekXp += earned;
  }
  const streak = activityDays(attempts, now),
    level = Math.floor(xp / XP_PER_LEVEL) + 1,
    levelXp = xp % XP_PER_LEVEL;
  const badges = [
    {
      id: "first",
      title: "Primeiro passo",
      description: "Responda sua primeira questão.",
      earned: answered.size >= 1,
      kind: "footprint",
    },
    {
      id: "five",
      title: "Pegou o ritmo",
      description: "Explore cinco questões diferentes.",
      earned: answered.size >= 5,
      kind: "sparkles",
    },
    {
      id: "three-days",
      title: "Chama acesa",
      description: "Estude por três dias consecutivos.",
      earned: streak.best >= 3,
      kind: "flame",
    },
    {
      id: "week",
      title: "Semana de ouro",
      description: "Alcance sete dias consecutivos de estudo.",
      earned: streak.best >= 7,
      kind: "crown",
    },
    {
      id: "explorer",
      title: "Sem fronteiras",
      description: "Estude nas quatro áreas do conhecimento.",
      earned:
        new Set(attempts.map((a) => known.get(a.questionId)!.area)).size === 4,
      kind: "compass",
    },
    {
      id: "correct-ten",
      title: "Mente afiada",
      description: "Acerte dez questões diferentes.",
      earned: correct.size >= 10,
      kind: "target",
    },
  ];
  return {
    xp,
    todayXp,
    weekXp,
    level,
    levelXp,
    toNextLevel: XP_PER_LEVEL - levelXp,
    levelName:
      level < 3
        ? "Primeiros passos"
        : level < 6
          ? "Explorador"
          : level < 11
            ? "Desbravador"
            : "Farol do conhecimento",
    streak,
    answered,
    correct,
    todayCount: daily.get(today)?.size || 0,
    todayCorrect: dailyCorrect.get(today)?.size || 0,
    todayAreas: dailyAreas.get(today)?.size || 0,
    badges,
  };
}

export function journeyLessons(
  progress: Progress,
  questions: Question[],
  language = "ingles",
  now = new Date(),
): Lesson[] {
  const stats = journeyStats(progress, questions, now),
    known = new Map(questions.map((q) => [q.id, q]));
  return plan.worlds.flatMap((world) => {
    let previousComplete = true;
    return world.lessons.flatMap((raw) => {
      const questionIds = raw.questionIds
        .map((id) =>
          language === "espanhol" ? id.replace(/-ingles$/, "-espanhol") : id,
        )
        .filter((id) => {
          const q = known.get(id);
          return q && !q.annulled && q.answer;
        });
      if (!questionIds.length) return [];
      const answered = questionIds.filter((id) =>
          stats.answered.has(id),
        ).length,
        correct = questionIds.filter((id) => stats.correct.has(id)).length,
        completed = answered === questionIds.length,
        unlocked = previousComplete || completed;
      previousComplete = completed;
      return [
        {
          ...raw,
          area: world.area as Area,
          questionIds,
          answered,
          correct,
          completed,
          unlocked,
          stars: completed
            ? correct === questionIds.length
              ? 3
              : correct / questionIds.length >= 0.6
                ? 2
                : 1
            : 0,
        },
      ];
    });
  });
}
