import "server-only";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { cache } from "react";
import { createClient } from "@supabase/supabase-js";
import { questionSchema } from "./review";
import type { Coverage, Question } from "./types";
export const catalog = cache(
  async (): Promise<{
    questions: Question[];
    coverage: Coverage[];
    importedAt: string;
  }> => {
    const local = JSON.parse(
      await readFile(path.join(process.cwd(), "data/catalog.json"), "utf8"),
    );
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL,
      key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;
    if (!url || !key) return local;
    const db = createClient(url, key, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: {
        fetch: (input, init) => fetch(input, { ...init, cache: "no-store" }),
      },
    });
    const questions: Question[] = [];
    for (let offset = 0; offset < 100000; offset += 500) {
      const { data, error } = await db
        .from("questions")
        .select("data")
        .eq("status", "published")
        .order("id")
        .range(offset, offset + 499);
      if (error)
        throw Error(
          "A biblioteca não pôde ser carregada. Tente novamente em instantes.",
        );
      questions.push(
        ...(data || []).map((row) => questionSchema.parse(row.data)),
      );
      if (!data || data.length < 500) break;
    }
    const years = [...new Set(questions.map((q) => q.year))].sort(
      (a, b) => a - b,
    );
    return {
      questions,
      coverage: years.map((year) => ({
        year,
        edition: "Acervo publicado",
        available: questions.filter((q) => q.year === year).length,
        expected: null,
        reviewed: questions.filter((q) => q.year === year && q.answerVerified)
          .length,
        status: "Publicado pela administração",
        missing: [],
      })),
      importedAt: local.importedAt,
    };
  },
);
