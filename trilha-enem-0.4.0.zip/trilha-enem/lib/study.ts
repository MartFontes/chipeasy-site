import type { Attempt, Filters, Progress, Question } from "./types";
export const EMPTY_FILTERS: Filters = {
  query: "",
  area: "all",
  year: "all",
  language: "all",
  state: "all",
};
export const blankProgress = (): Progress => ({
  version: 1,
  name: "",
  dailyGoal: 10,
  attempts: [],
  favorites: [],
  favoriteChanges: {},
  sessions: [],
  updatedAt: new Date().toISOString(),
});
export const normalized = (s: string) =>
  s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
const dayFormatter = new Intl.DateTimeFormat("sv-SE", {
  timeZone: "America/Sao_Paulo",
});
export const dayKey = (date: string | Date) =>
  dayFormatter.format(new Date(date));
export function latestAttempts(attempts: Attempt[]) {
  const map = new Map<string, Attempt>();
  for (const a of attempts)
    if (
      !map.has(a.questionId) ||
      a.answeredAt >= map.get(a.questionId)!.answeredAt
    )
      map.set(a.questionId, a);
  return map;
}
export function filterQuestions(
  questions: Question[],
  filters: Filters,
  progress: Progress,
) {
  const latest = latestAttempts(progress.attempts),
    query = normalized(filters.query.trim());
  return questions.filter(
    (q) =>
      (filters.area === "all" || q.area === filters.area) &&
      (filters.year === "all" || String(q.year) === filters.year) &&
      (filters.language === "all" ||
        !q.language ||
        q.language === filters.language) &&
      (!query ||
        normalized(
          `${q.context} ${q.prompt} ${q.subject || ""} ${q.year} ${q.number}`,
        ).includes(query)) &&
      (filters.state !== "favorite" || progress.favorites.includes(q.id)) &&
      (filters.state !== "unanswered" || !latest.has(q.id)) &&
      (filters.state !== "wrong" || latest.get(q.id)?.correct === false) &&
      (filters.state !== "correct" || latest.get(q.id)?.correct === true),
  );
}
export function summary(progress: Progress) {
  const latest = [...latestAttempts(progress.attempts).values()],
    scored = latest.filter((a) => a.correct !== null),
    today = dayKey(new Date());
  const todayIds = new Set(
    progress.attempts
      .filter((a) => dayKey(a.answeredAt) === today)
      .map((a) => a.questionId),
  );
  return {
    answered: latest.length,
    accuracy: scored.length
      ? Math.round(
          (100 * scored.filter((a) => a.correct).length) / scored.length,
        )
      : null,
    wrong: latest.filter((a) => a.correct === false).length,
    correct: scored.filter((a) => a.correct).length,
    today: todayIds.size,
  };
}
export function mergeProgress(a: Progress, b: Progress): Progress {
  const attempts = new Map(
    [...a.attempts, ...b.attempts].map((x) => [x.id, x]),
  );
  const sessions = new Map<string, Progress["sessions"][number]>();
  for (const s of [...a.sessions, ...b.sessions]) {
    const old = sessions.get(s.id);
    if (!old || s.finishedAt || !old.finishedAt) sessions.set(s.id, s);
  }
  const changes = { ...(a.favoriteChanges || {}) };
  for (const [key, v] of Object.entries(b.favoriteChanges || {}))
    if (
      !changes[key] ||
      v.at > changes[key].at ||
      (v.at === changes[key].at && !v.saved)
    )
      changes[key] = v;
  const favorites = new Set([...a.favorites, ...b.favorites]);
  for (const [key, v] of Object.entries(changes))
    if (v.saved) favorites.add(key);
    else favorites.delete(key);
  const newer = b.updatedAt > a.updatedAt ? b : a;
  return {
    ...a,
    name: newer.name || a.name || b.name,
    dailyGoal: newer.dailyGoal,
    attempts: [...attempts.values()].sort((x, y) =>
      x.answeredAt.localeCompare(y.answeredAt),
    ),
    favorites: [...favorites],
    favoriteChanges: changes,
    sessions: [...sessions.values()],
    updatedAt: new Date().toISOString(),
  };
}
export function safeProgress(value: unknown): Progress {
  if (!value || typeof value !== "object")
    throw Error("Arquivo de progresso inválido.");
  const p = value as Progress;
  if (
    p.version !== 1 ||
    !Array.isArray(p.attempts) ||
    !Array.isArray(p.favorites) ||
    !Array.isArray(p.sessions) ||
    p.attempts.length > 100000
  )
    throw Error("Formato de progresso inválido.");
  if (
    typeof p.name !== "string" ||
    p.name.length > 80 ||
    !Number.isInteger(p.dailyGoal) ||
    p.dailyGoal < 1 ||
    p.dailyGoal > 200
  )
    throw Error("Perfil de estudo inválido.");
  for (const a of p.attempts)
    if (
      !a ||
      typeof a.id !== "string" ||
      typeof a.questionId !== "string" ||
      !["A", "B", "C", "D", "E"].includes(a.selected) ||
      ![true, false, null].includes(a.correct) ||
      !Number.isFinite(Date.parse(a.answeredAt)) ||
      !Number.isFinite(a.durationMs) ||
      a.durationMs < 0
    )
      throw Error("Há respostas inválidas no arquivo.");
  if (p.favorites.some((x) => typeof x !== "string"))
    throw Error("Favoritos inválidos.");
  if (
    p.favoriteChanges !== undefined &&
    (!p.favoriteChanges ||
      typeof p.favoriteChanges !== "object" ||
      Array.isArray(p.favoriteChanges) ||
      Object.values(p.favoriteChanges).some(
        (v) =>
          !v ||
          typeof v.saved !== "boolean" ||
          !Number.isFinite(Date.parse(v.at)),
      ))
  )
    throw Error("Alterações de favoritos inválidas.");
  if (!Number.isFinite(Date.parse(p.updatedAt)))
    throw Error("Data de progresso inválida.");
  for (const s of p.sessions)
    if (
      !s ||
      typeof s.id !== "string" ||
      typeof s.title !== "string" ||
      !Array.isArray(s.questionIds) ||
      s.questionIds.some((x) => typeof x !== "string") ||
      !Number.isFinite(Date.parse(s.createdAt)) ||
      (s.finishedAt !== null && !Number.isFinite(Date.parse(s.finishedAt)))
    )
      throw Error("Sessões inválidas.");
  return { ...blankProgress(), ...p };
}
export function plainPreview(text: string) {
  return text
    .replace(/!\[[^\]]*\]\([^)]*\)/g, "")
    .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
    .replace(/[*_#`]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}
