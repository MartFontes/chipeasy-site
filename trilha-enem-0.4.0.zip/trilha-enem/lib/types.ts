export const AREAS = {
  linguagens: {
    label: "Linguagens",
    full: "Linguagens, Códigos e suas Tecnologias",
    color: "#7028ef",
    short: "LC",
  },
  "ciencias-humanas": {
    label: "Ciências Humanas",
    full: "Ciências Humanas e suas Tecnologias",
    color: "#2155ef",
    short: "CH",
  },
  "ciencias-natureza": {
    label: "Ciências da Natureza",
    full: "Ciências da Natureza e suas Tecnologias",
    color: "#007c4a",
    short: "CN",
  },
  matematica: {
    label: "Matemática",
    full: "Matemática e suas Tecnologias",
    color: "#cf322f",
    short: "MT",
  },
} as const;
export type Area = keyof typeof AREAS;
export type Letter = "A" | "B" | "C" | "D" | "E";
export type Question = {
  id: string;
  year: number;
  edition: string;
  day: number;
  number: number;
  language: "ingles" | "espanhol" | null;
  area: Area;
  subject: string | null;
  context: string;
  prompt: string;
  alternatives: { letter: Letter; text: string; image: string | null }[];
  answer: Letter | null;
  annulled: boolean;
  explanation: string | null;
  source: {
    originalUrl: string;
    answerKeyUrl: string;
    mirrorUrl: string;
    sha256: string;
    transcriptionSha256?: string;
    provider: string;
    page?: number;
    booklet: string | null;
  };
  status: "imported" | "reviewed" | "published";
  answerVerified: boolean;
  reviewNote: string;
  fingerprint: string;
};
export type Attempt = {
  id: string;
  questionId: string;
  selected: Letter;
  correct: boolean | null;
  answeredAt: string;
  durationMs: number;
  sessionId: string | null;
};
export type StudySession = {
  id: string;
  title: string;
  questionIds: string[];
  createdAt: string;
  finishedAt: string | null;
};
export type Progress = {
  version: 1;
  name: string;
  dailyGoal: number;
  attempts: Attempt[];
  favorites: string[];
  favoriteChanges: Record<string, { saved: boolean; at: string }>;
  sessions: StudySession[];
  updatedAt: string;
};
export type Filters = {
  query: string;
  area: string;
  year: string;
  language: string;
  state: string;
};
export type Coverage = {
  year: number;
  edition: string;
  available: number;
  expected: number | null;
  reviewed: number;
  status: string;
  missing: string[];
};
