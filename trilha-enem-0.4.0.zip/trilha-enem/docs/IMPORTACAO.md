# Importação e proveniência

## Acervo inicial

Foram usadas as transcrições do repositório `yunger7/enem-api`, commit `938c56fbd3b391e03d93316c920a90c3e54842e5`, e os PDFs originais produzidos pelo Inep, preservados no repositório `caue-paiva/ENEM_PDF_PARSER`, commit `99ce99af4f6078817ef462ce8283e28fa848149b`.

O acesso direto aos domínios do Inep estava bloqueado no ambiente; os PDFs foram obtidos desse espelho público. Não foi alegada verificação criptográfica contra um download direto do Inep. O arquivo `data/import-report.json` registra o endereço original, o espelho e o SHA-256 de cada PDF recebido. Cada questão mantém o hash do PDF; quando há transcrição externa, mantém também `transcriptionSha256`.

Os gabaritos e as anulações foram comparados aos documentos preservados. Foram corrigidos 25 metadados de área ou resposta da transcrição. Questões com imagens ou alternativas ausentes e questões sem transcrição foram recuperadas como recortes da prova. Há 370 IDs únicos e duas questões anuladas. Conferência automática de estrutura e gabarito não equivale a revisão integral do texto.

## Importar uma nova prova

1. Obtenha a prova e seu gabarito no [portal do Inep](https://www.gov.br/inep/pt-br/areas-de-atuacao/avaliacao-e-exames-educacionais/enem/provas-e-gabaritos). Registre ano, aplicação, dia e cor do caderno. Evite importar todas as cores como questões novas: elas normalmente repetem questões em outra ordem.
2. Instale o importador com `python3 -m pip install -r requirements.txt`.
3. Gere um lote, por exemplo:

```sh
python3 tools/import_pdf.py \
  --exam public/sources/2023_PV_impresso_D2_CD7.pdf \
  --answers public/sources/2023_GB_impresso_D2_CD7.pdf \
  --year 2023 --day 2 --edition regular --booklet Azul \
  --output data/staging/2023-dia2.json
```

O importador foi verificado nas provas regulares de 2022 e 2023. PDFs com outra diagramação, numeração ou gabarito precisam de adaptação e revisão. Edições anteriores a 2010 são recusadas pelo adaptador inicial. O relatório compara a contagem encontrada com 95 itens no primeiro dia e 90 no segundo, incluindo os dois idiomas, e informa gabaritos não identificados. O conteúdo entra como `imported`, com gabarito ainda não confirmado para publicação.

Para documentos digitalizados, instale Tesseract e o idioma português; acrescente `--ocr`. Na ausência de português, o processo usa inglês e registra isso no relatório. O PDF original é preservado. A saída de OCR exige conferência visual; ela não autoriza publicação automática. O OCR completo de todas as edições não foi validado nesta entrega.

4. Abra `/revisao`, selecione **Importar lote JSON** e envie a saída. Questões já existentes são ignoradas; IDs com conteúdo diferente são preservados para conferência. Um arquivo inválido é recusado antes de gravar as questões do lote.
5. Confira a prova, o recorte, a área, as cinco alternativas e o gabarito. Transcreva o conteúdo das imagens e registre uma resolução quando disponível. Marque a conferência e selecione **Aprovar e publicar**. Em modo local, exporte o acervo após a revisão para guardar ou transferir suas alterações.
6. Inclua as novas imagens de `public/questions` e os PDFs de `public/sources` na próxima publicação do aplicativo. Importar JSON no navegador **não envia esses arquivos automaticamente ao servidor**.

O download opcional `python3 tools/download_official.py --help` usa URLs HTTPS do Inep. Depende de rede autorizada; baixar diretamente do Inep continua não validado neste ambiente. Os domínios foram adicionados ao rascunho de configuração, mas salvar o rascunho não altera por si só a rede em execução.

## Reproduzir a biblioteca inicial

Obtenha os arquivos das duas fontes nos commits acima. Coloque os oito PDFs em `data/raw/official` e copie a lista `pdfSources` de `data/import-report.json` para `data/raw/official/manifest.json`. Confira seus hashes. Com a árvore da API ENEM disponível localmente:

```sh
python3 tools/import_seed.py --source /caminho/enem-api \
  --official data/raw/official --years 2022 2023
```

`data/editorial.json` contém as cinco resoluções revisadas e preservadas na regeneração. A geração confere suas respostas com o gabarito antes de aplicá-las. O importador não executa código do repositório de dados.

## Identidade e repetição

O ID representa ano, aplicação, número e idioma. O fingerprint impede duplicatas com conteúdo exatamente equivalente; ele não resolve sozinho transcrições com redação ou formatação diferentes. Para expandir a várias cores, reaplicações ou PPL, use `editions` e `question_occurrences` para mapear ocorrências da mesma questão após conferência. O painel inicial opera sobre as questões; o relacionamento automático entre cadernos não está implementado.
