# Direção visual — Trilha ENEM 0.4.0

Uma jornada de aprendizado com a energia de um jogo, personalidade brasileira e leitura confortável nas questões do Enem. A referência de interação é o Duolingo; a marca, a Capi e os desenhos são próprios.

## Sistema visual

| Papel               | Cor       | Uso                                            |
| ------------------- | --------- | ---------------------------------------------- |
| Violeta             | `#7028EF` | Marca, jornada, botões principais e Linguagens |
| Azul elétrico       | `#2155EF` | XP, desafios e Ciências Humanas                |
| Dourado             | `#FFD52E` | Ação da jornada, energia, estrelas e baú       |
| Esmeralda           | `#007C4A` | Acerto e Ciências da Natureza                  |
| Coral               | `#CE2540` | Feedback de erro e alertas                     |
| Coral de Matemática | `#CF322F` | Mundo e etiquetas de Matemática                |
| Tinta               | `#29213D` | Títulos e texto principal                      |

As superfícies são brancas, com bordas sólidas de dois pixels, sombras inferiores definidas, cantos arredondados e acentos saturados. A cor da área tem uma fonte de verdade em `lib/types.ts`, reutilizada por `lib/journey.ts`.

Plus Jakarta Sans organiza os títulos; DM Sans cuida da leitura e dos controles. As fontes são locais e passam por `next/font/local`, com pré-carregamento e fallback com métricas ajustadas. Os números usam largura tabular. O espaço da mascote, das métricas e das barras é reservado. `scrollbar-gutter` evita que a página mude de largura ao abrir um diálogo.

## Movimento com propósito

- A Capi é um SVG articulado em `components/capybara.tsx`. Corpo, braço, olhos, boca e estrelas mudam conforme o estado. A jornada permite cumprimentá-la; o leitor reage a acerto e erro; a conclusão recebe sua própria comemoração.
- Todos os botões React compartilham `MotionButton`: escala de 1,02 no hover e 0,98 ao pressionar, com mola. Controles desativados não animam.
- A trilha tem halo suave na etapa atual, conectores SVG em movimento e etapas concluídas em verde. O baú possui tampa articulada e diálogo próprio.
- As barras animam o preenchimento com `scaleX`, mantendo o tamanho do contêiner, e movimentam discretamente o gradiente enquanto há avanço parcial.
- XP flutuante, gemas decorativas, brilhos nas bordas e confetes acompanham os eventos de estudo. Os valores exibidos são os ganhos reais calculados pelas regras existentes.
- O som é opcional, desligado inicialmente, gerado pela Web Audio API e lembrado neste dispositivo. Ele pode ser controlado no cabeçalho, no leitor ou em Meu perfil.

`prefers-reduced-motion` desativa saltos, pulsações, partículas e confetes. Expressões, mensagens, XP e progresso continuam disponíveis. Não há flashes rápidos nem som automático na abertura.

## Componentes e organização

`app/tailwind.css` fornece o tema do Tailwind CSS 4. `app/journey.css` descreve o mapa e sua composição; `app/experience.css` reúne tokens, controles, leitor, efeitos e diálogos. As telas administrativas e a biblioteca preservam seus fluxos e adotam os mesmos controles.

`ExperienceProvider` coordena efeitos temporários e preferência de som. As regras permanentes de XP, sequência, estrelas e missões continuam em `lib/journey.ts`, derivadas do histórico; abrir uma recompensa não grava pontos adicionais. Veja [estados e interações](INTERACOES.md).

## Responsividade e acessibilidade

A composição adapta a jornada ao celular, tablet e computador. No celular, o menu guarda a navegação; os controles de som e perfil permanecem no cabeçalho. Questões e alternativas conservam superfícies brancas e não usam a paleta da mascote sobre gráficos acadêmicos.

Os diálogos possuem nomes, foco inicial, fechamento por Escape e restauração do foco. O leitor torna o restante da aplicação inerte e mantém o foco dentro da atividade. Barras expõem nome e valor para tecnologia assistiva. A validação usa Playwright e axe; os resultados e limites estão em [VALIDACAO.md](VALIDACAO.md).

Os gráficos, fórmulas e figuras das provas continuam preservando o material dos PDFs originais.
