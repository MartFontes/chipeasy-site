# Supabase próprio do Trilha ENEM

O aplicativo funciona sem Supabase. Para ativar contas e uma biblioteca compartilhada, crie **um projeto separado**, dedicado a este produto.

1. Execute `supabase/migrations/202610160001_initial.sql` no SQL Editor do novo projeto. A migração cria perfis, questões, edições, ocorrências e progresso com RLS. Nenhum dado do ChipEasy é utilizado.
2. Execute `supabase/seed.sql`, gerado a partir do catálogo por `python3 tools/build_seed_sql.py`. A carga mantém os estados de revisão: cinco questões publicadas com resolução e as demais aguardando revisão editorial. Quando o Supabase está ativado, o aluno vê somente as questões publicadas; o administrador vê todas no painel de revisão.
3. Copie `.env.example` para `.env.local` e preencha a URL e a **publishable key** pública do novo projeto. Reinicie o servidor; para produção, configure as variáveis na hospedagem **antes da compilação**. Não há necessidade de chave `service_role` no aplicativo.
4. Cadastre sua conta pelo aplicativo. Configure a URL do site, os destinos de confirmação e o serviço de e-mail no Supabase Auth. Para dar administração a uma conta já cadastrada, execute no SQL Editor:

```sql
update public.profiles set role = 'admin'
where id = (select id from auth.users where email = 'SEU_EMAIL');
```

O estudante não tem permissão para alterar seu próprio papel. Esse SQL é executado pelo dono do projeto. Não coloque uma chave administrativa no navegador.

5. Entre novamente e acesse `/revisao`. As aprovações passam a ser gravadas na biblioteca compartilhada. O catálogo do aluno é carregado do banco na abertura da página; recarregue a página após publicar novas questões.
6. Publique o projeto em uma hospedagem compatível com Next.js e Node.js. Comando de compilação: `npm run build`. Para servidor próprio, use `npm exec next start -- --hostname 0.0.0.0 --port 3000` atrás de HTTPS. Os arquivos em `public` e `data` precisam acompanhar o aplicativo. Não é um site puramente estático.

## Progresso e contas

Cada usuário tem seu próprio registro e uma cópia local separada por conta. A função `merge_study_progress` mescla tentativas por ID e registra remoções de favoritos com data, evitando que uma cópia antiga restaure favoritos removidos. A gravação é serializada por usuário. Atualizações de outro dispositivo aparecem ao entrar ou recarregar; não há transmissão em tempo real.

O progresso criado como visitante permanece no perfil local do dispositivo. Para levá-lo à conta, exporte antes de entrar e importe depois. Sair da conta volta ao perfil de visitante. A exportação é uma forma adicional de backup.

## Validação antes de disponibilizar a alunos

Os testes locais verificaram a execução da migração, RLS, permissões administrativas, isolamento entre usuários, mesclagem e repetição da sincronização em PostgreSQL via PGlite. Ainda é necessário verificar no projeto real o cadastro, confirmação por e-mail, entrada, saída, restauração em outro dispositivo e publicação de um lote com imagens.

As imagens iniciais são servidas pelo próprio aplicativo. A migração reserva um bucket `question-media` com escrita administrativa para evolução futura; envio e renderização desse bucket ainda não integram o painel. Neste fluxo, os novos arquivos são publicados em `public/questions`, junto do aplicativo.
