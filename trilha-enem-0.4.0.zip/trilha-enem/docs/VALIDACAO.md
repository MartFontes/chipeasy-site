# Validação da versão 0.4.0

Ambiente de verificação: Node.js 24.19.0, npm 11.9.0, Python 3.12 e Chromium. Os testes de navegador foram executados na compilação otimizada de produção.

| Verificação                                                 | Resultado                                             |
| ----------------------------------------------------------- | ----------------------------------------------------- |
| Tipos de rotas e TypeScript                                 | Sem erros                                             |
| Regras de estudo, jornada e PostgreSQL/PGlite               | 17 testes aprovados                                   |
| Gabaritos, numeração, hashes e fidelidade de figuras ao PDF | 6 testes aprovados                                    |
| Navegador, incluindo interação e acessibilidade             | 30 testes aprovados: 15 no computador e 15 no celular |
| Compilação de produção                                      | Concluída                                             |
| Layouts nas larguras de 320, 393, 768, 1024 e 1440 px       | 85 conferências, sem rolagem horizontal indevida      |
| Erros JavaScript na conferência de layouts                  | Nenhum                                                |
| Requisições externas na conferência de layouts              | Nenhuma                                               |
| Formatação e diferenças                                     | Sem erros                                             |

**Total: 53 testes aprovados.** Os 85 layouts são uma verificação adicional, registrada em [interface-validation.json](interface-validation.json).

## Interações da versão 0.4.0

A suíte nova testa a mascote em SVG reagindo a acerto, erro e cumprimento; preferência de som inicialmente desligada e persistida após recarregar; contagem real de XP; partículas de recompensa; desenho de confetes no canvas; altura estável da área da mascote; proteção contra duplo clique; baú informativo e baú conquistado sem repetir bônus; fechamento por Escape e retorno do foco; barras com valores acessíveis; e movimento reduzido mantendo a informação sem saltos ou partículas.

Os testes verificam erros JavaScript e mensagens de erro do console, incluindo problemas de hidratação. A preferência de movimento mantém o mesmo estado no servidor e na primeira renderização do cliente. A geometria do braço animado é conferida pelo seu ponto de rotação para evitar que se solte visualmente do corpo.

O axe aplica regras automáticas WCAG A/AA à jornada, ao baú, ao leitor, ao feedback e à conclusão, em computador e celular. Não encontrou violações nesses estados. Essa conferência não substitui uma avaliação manual completa de acessibilidade ou testes com usuários.

## Regressões e conteúdo

Os testes existentes cobrem progresso recuperado de versões anteriores, retomada de lições sem duplicar a sessão, liberação de etapas, XP sem multiplicação, escolha de idioma, sequência e recorde, ampliação de figuras, filtros, correção de erros, fórmulas, favoritos, backup, práticas retomáveis e revisão local.

Os testes das regras usam dias de São Paulo, eventos futuros, viradas de mês e ano bissexto, bônus diário único, subida de nível e composição estável das lições. Os testes do banco aplicam os papéis reais de PostgreSQL e RLS, validam isolamento por usuário e mesclagem de progresso, e repetem migração e carga.

Os testes de PDF comparam os 370 gabaritos e anulações às provas preservadas, conferem os hashes dos oito documentos e a fidelidade das 83 regiões recuperadas. A alteração visual não modifica enunciados, figuras ou gabaritos.

## Reproduzir

```sh
npm ci
npm run typecheck
npm test
npm run build
npm start
```

Com a aplicação de produção rodando em outro terminal:

```sh
TEST_BASE_URL=http://127.0.0.1:3100 npm run test:e2e
npm run verify:interface
```

No Windows, use `set TEST_BASE_URL=http://127.0.0.1:3100` no Prompt de Comando antes de executar `npm run test:e2e`. O Chromium deve estar disponível ou ser instalado com `npx playwright install chromium`. Os testes de PDF usam `python -m pip install -r requirements.txt` e `python -m unittest discover -s tests -p 'test_*.py' -v`.

## Limites da verificação

A verificação foi feita em Chromium, incluindo emulação de celular. Não foram executados testes em aparelhos iOS/Android físicos, Safari ou Firefox, nem testes de carga. O som foi acionado no navegador de teste, mas não foi avaliado em alto-falantes de aparelhos reais.

Confirmação de e-mail, SMTP, autenticação e sincronização em Supabase de produção continuam dependendo da configuração desse serviço. O catálogo completo de todas as edições e a revisão editorial integral das transcrições permanecem fora desta atualização de interface.

Capturas reais da versão: [computador](previews/desktop.png), [celular](previews/mobile.png), [leitor](previews/reader-mobile.png), [conclusão](previews/celebration-mobile.png) e [baú](previews/chest-mobile.png).
