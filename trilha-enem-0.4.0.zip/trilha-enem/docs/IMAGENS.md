# Qualidade das imagens — versão 0.2.0

Foram recuperadas **83 imagens a partir dos PDFs originais**: 11 recortes com conteúdo de questões e 72 figuras, incluindo a tabela de salários da questão 137 de 2023. Também foram retirados da exibição **seis fragmentos extras de cabeçalho, rodapé ou abertura de idioma**, sem conteúdo da questão. A continuação legítima das alternativas da questão 44 de 2023 foi preservada.

Os novos arquivos são SVGs: texto e desenhos conservam os vetores do PDF, e fotografias conservam seus pixels de origem. Isso melhora a ampliação de letras, números, tabelas e diagramas. Não foram redesenhados dados da prova nem inventados detalhes ausentes nas fotografias.

Cada figura abre num visualizador dentro da tela de estudo, com ampliação de **100% a 400%**, rolagem, ajuste ao tamanho da janela e fechamento pelo botão ou pela tecla Escape. Fechar a figura mantém a questão aberta. O recurso também funciona em imagens das alternativas.

## Origem e conferência

- `data/media-map.json` relaciona cada caminho antigo ao novo arquivo. Assim, o histórico e as revisões locais que usam os caminhos anteriores continuam compatíveis.
- `data/media-quality.json` registra PDF, página, retângulo e método de localização de cada recuperação.
- `data/media-hidden.json` identifica os seis fragmentos sem conteúdo que deixam de aparecer.
- `data/media-approvals.json` registra as regiões conferidas manualmente da tabela de salários e das cinco figuras de alternativas recuperadas. Ela também recebeu descrição textual dos valores para acessibilidade.

Para figuras de alternativas, a recuperação exige aprovação manual da região e da letra correspondente na página. A comparação automática pode confundir diagramas com pequenas diferenças de símbolos.

Nas demais figuras, OpenCV apenas localiza a imagem já existente dentro da região da questão na prova. A saída vem dos vetores e pixels do PDF. Correspondências incertas foram preservadas no formato anterior para revisão, em vez de trocar uma figura por outra. O visualizador permite ampliá-las, mas não recupera detalhes que não existam nos pixels originais.

Os testes verificam que cada SVG corresponde exatamente ao retângulo registrado no PDF, que os arquivos de prova mantêm seus hashes e que não há scripts ou links remotos nos SVGs. A revisão editorial completa de todas as figuras continua pendente.

## Reproduzir

```sh
python3 -m pip install -r requirements-media.txt
python3 tools/native_media.py --match-figures
```

Para atualizar somente os recortes já catalogados, preservando as figuras localizadas:

```sh
python3 tools/native_media.py --refresh-crops
```

O importador de novas provas também passou a produzir recortes vetoriais, com nomes baseados em hash. As margens excluem cabeçalhos e rodapés e preservam o corpo da prova. PDFs com outra diagramação precisam de conferência antes de serem publicados.
