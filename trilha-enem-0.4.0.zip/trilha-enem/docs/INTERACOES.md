# Estados e recompensas — 0.4.0

## Mascote

`Capybara` recebe `mood` e `reactionKey`. Cada tentativa tem um ID único; o ID reinicia a reação visual somente quando acontece uma nova resposta.

| Estado      | Gatilho                    | Resposta                                      |
| ----------- | -------------------------- | --------------------------------------------- |
| `idle`      | Jornada ou questão aberta  | Respiração suave e piscada periódica          |
| `wave`      | Botão “Dar um oi à Capi”   | Aceno e incentivo; volta ao repouso           |
| `correct`   | Acerto confirmado          | Saltos, sorriso, braço levantado e estrelas   |
| `encourage` | Resposta incorreta         | Inclinação acolhedora e mensagem de incentivo |
| `celebrate` | Lição ou prática concluída | Saltos de comemoração e sorriso               |

O SVG é original e seus membros são animados com Framer Motion. A interface não carrega uma imagem estática da mascote.

## Eventos temporários

`ExperienceProvider.emit` recebe um evento de feedback com tipo, XP real e, quando houver, o novo nível. Ele não modifica o progresso. Um ID sequencial separa os eventos; o estado de feedback é limpo após 2,8 segundos. `RewardEffects` mostra o XP e partículas decorativas, faz o brilho das bordas e aciona `canvas-confetti`. O módulo de confetes é carregado sob demanda; o canvas é limpo ao terminar ou desmontar.

A conclusão e o baú mantêm um canvas dentro de seu próprio diálogo para funcionar na camada superior nativa do navegador. Esses efeitos têm `pointer-events: none` e ficam fora da árvore acessível. As mensagens persistentes de correção e os valores das barras não dependem das partículas.

A função que confirma respostas tem trava síncrona por questão. Mesmo dois cliques recebidos antes do próximo render registram uma única tentativa. A trava é liberada ao abrir outra questão.

## Pontuação e baú

Os cálculos permanecem em `lib/journey.ts`: 10 XP por questão nova, mais 10 no primeiro acerto, e bônus único de 30 XP por cinco questões diferentes no dia. Repetições, cópias de backup e visualização do baú não multiplicam os pontos.

O baú fechado informa o progresso do desafio. Depois da quinta questão, o bônus já está no histórico derivado; abrir a tampa comemora e explica o ganho. Não existe um segundo saldo de moedas ou gemas: as gemas das partículas são decorativas.

Sequência, missões e níveis continuam usando o histórico existente, sem migração ou novo esquema no Supabase. As preferências de área, língua, favoritos e progresso das versões anteriores permanecem compatíveis.

## Som e movimento reduzido

O som começa desligado. `trilha-enem.experience.v1` guarda apenas a preferência local de som. `AudioContext` é criado depois de uma ação explícita; as notas são geradas com osciladores senoidais de volume baixo, envelope finito e desconexão ao terminar. Falhas ou bloqueios de áudio não impedem responder questões.

`MotionConfig` e `useMotionPreference` respeitam `prefers-reduced-motion`. Em modo reduzido, não há animação de corpo, hover, salto, partículas, confetes ou gradiente. A mudança de expressão e o feedback textual continuam imediatos. O som tem seu próprio controle independente. O hook de preferência usa `useSyncExternalStore`, com estado inicial idêntico no servidor e na hidratação, e acompanha mudanças de preferência do sistema.

## Verificação

`tests/e2e/experience.spec.ts` cobre os gatilhos da mascote, persistência do som, ausência da antiga imagem, duplo clique, XP flutuante, desenho real de confetes no canvas, estabilidade do espaço do acompanhante, feedback de erro, baú sem bônus duplicado, Escape, foco, progresso acessível e preferência por movimento reduzido.

O mesmo arquivo aplica regras automáticas WCAG A/AA do axe à jornada, ao baú, ao leitor, à correção e à conclusão. Essa verificação complementa a inspeção visual e os testes de teclado; não equivale a uma certificação de acessibilidade.
