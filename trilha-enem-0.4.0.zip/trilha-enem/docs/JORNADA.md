# Jornada de estudo — versão 0.4.0

O aplicativo abre em **Minha jornada**. São quatro caminhos, um por área do Enem, divididos em **72 lições de até cinco questões**. O aluno escolhe por onde começar. Dentro de cada caminho, concluir uma lição libera a próxima.

## Regras de avanço

- Cada questão diferente respondida rende **10 XP**. O primeiro acerto nessa questão rende mais **10 XP**, inclusive se acontecer numa revisão posterior.
- Responder **cinco questões diferentes no mesmo dia** rende **30 XP adicionais**, uma vez por dia. Repetir a mesma resposta ou importar novamente o mesmo histórico não multiplica os pontos.
- O aluno sobe um nível a cada **200 XP**. XP indica atividade e avanço no aplicativo; não é nota TRI nem medida oficial de proficiência.
- Concluir as questões de uma lição libera a próxima, mesmo que haja erros. A revisão continua disponível no caderno de erros.
- A lição ganha uma estrela pela conclusão, duas quando pelo menos 60% das questões já tiverem sido acertadas e três quando todas tiverem um acerto registrado. As estrelas guardam conquistas de aprendizagem; a taxa de acertos continua considerando a resposta mais recente.
- Há seis conquistas: primeiro passo, cinco questões diferentes, três e sete dias consecutivos, estudo nas quatro áreas e dez questões acertadas.

## Sequência de dias, ou streak

Um dia conta quando há ao menos **uma questão respondida**. Apenas abrir o aplicativo não conta. Os dias seguem o fuso **America/Sao_Paulo**.

A sequência permanece visível quando o último estudo foi ontem: o aluno tem até o fim de hoje para continuar. Ao perder um dia completo, a sequência atual recomeça e o recorde anterior permanece. O calendário mostra os últimos sete dias. A tela se atualiza ao voltar à janela e na virada do dia, sem precisar apagar ou reabrir o progresso.

## Histórico e persistência

XP, sequência, missões, estrelas e conquistas são calculados a partir das respostas existentes. O histórico da versão 0.1.0 já conta, inclusive respostas feitas fora da trilha. Não foi criado um contador paralelo de XP que possa duplicar na sincronização.

Exportação e importação de progresso continuam incluindo os dados que formam essas conquistas. Com Supabase ativado, eles usam a mesma mesclagem por conta já existente. A escolha de caminho e de língua estrangeira é lembrada neste navegador, separadamente por conta.

`data/journey-plan.json` fixa a composição e o ID das lições. Para adicionar novas edições, acrescente etapas; não reorganize as antigas, pois isso mudaria o que uma lição concluída representa. Inglês e espanhol são variantes da mesma etapa de Linguagens; as respostas de cada idioma permanecem distintas.

As regras de avanço e de recompensas pessoais estão centralizadas em `lib/journey.ts`.

## Feedback visual

A jornada inclui a Capi em SVG reativo, baú diário, efeitos de XP e som opcional. O baú apresenta o bônus diário já calculado; abri-lo não concede XP novamente. Os detalhes de implementação e acessibilidade estão em [INTERACOES.md](INTERACOES.md).
