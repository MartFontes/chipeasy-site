import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { activityDays, journeyLessons, journeyStats } from "../lib/journey";
import { blankProgress, mergeProgress } from "../lib/study";
import type { Attempt, Question } from "../lib/types";
const questions: Question[] = JSON.parse(
  readFileSync("data/catalog.json", "utf8"),
).questions;
const now = new Date("2026-10-16T18:00:00Z");
const attempt = (
  id: string,
  qid: string,
  at: string,
  correct = true,
): Attempt => ({
  id,
  questionId: qid,
  selected: "C",
  correct,
  answeredAt: at,
  durationMs: 3000,
  sessionId: null,
});

test("sequência conta estudo em dias de São Paulo, preserva ontem e ignora eventos futuros", () => {
  const a = [
    attempt("a", "q", "2026-10-14T15:00:00Z"),
    attempt("b", "q", "2026-10-15T15:00:00Z"),
    attempt("c", "q", "2026-10-16T02:30:00Z"),
    attempt("future", "q", "2026-10-17T15:00:00Z"),
  ];
  assert.equal(activityDays(a, now).current, 2);
  assert.equal(activityDays(a, now).studiedToday, false);
  a.push(attempt("today", "q", "2026-10-16T15:00:00Z"));
  const result = activityDays(a, now);
  assert.equal(result.current, 3);
  assert.equal(result.best, 3);
  assert.equal(result.week.filter((d) => d.active).length, 3);
  assert.equal(activityDays(a, new Date("2026-10-17T18:00:00Z")).current, 4); // the previously future event is now an actual recorded day
});
test("dia perdido zera a sequência atual, conserva o recorde e atravessa ano bissexto", () => {
  const dates = ["2028-02-28", "2028-02-29", "2028-03-01"];
  const a = dates.map((d, i) => attempt(String(i), "q", d + "T15:00:00Z"));
  assert.equal(activityDays(a, new Date("2028-03-02T15:00:00Z")).current, 3);
  const missed = activityDays(a, new Date("2028-03-03T15:00:00Z"));
  assert.equal(missed.current, 0);
  assert.equal(missed.best, 3);
});
test("XP não multiplica ao repetir respostas, reimportar backup ou corrigir duas vezes", () => {
  const p = blankProgress(),
    q = questions[0];
  p.attempts = [attempt("a", q.id, "2026-10-16T13:00:00Z", false)];
  assert.equal(journeyStats(p, questions, now).xp, 10);
  p.attempts.push(attempt("b", q.id, "2026-10-16T14:00:00Z"));
  assert.equal(journeyStats(p, questions, now).xp, 20);
  p.attempts.push(attempt("c", q.id, "2026-10-16T15:00:00Z"));
  p.attempts.push(p.attempts[0]);
  assert.equal(journeyStats(mergeProgress(p, p), questions, now).xp, 20);
  assert.equal(journeyStats(p, questions, now).todayCount, 1);
});
test("cinco questões dão um único bônus diário, nível avança e histórico antigo já conta", () => {
  const p = blankProgress();
  p.attempts = questions
    .slice(0, 5)
    .map((q, i) => attempt(String(i), q.id, "2026-10-16T13:00:00Z"));
  const first = journeyStats(p, questions, now);
  assert.equal(first.xp, 130);
  assert.equal(first.todayXp, 130);
  assert.equal(first.level, 1);
  assert.equal(first.toNextLevel, 70);
  p.attempts.push(
    ...questions
      .slice(5, 10)
      .map((q, i) => attempt("next" + i, q.id, "2026-10-16T14:00:00Z")),
  );
  const next = journeyStats(p, questions, now);
  assert.equal(next.xp, 230);
  assert.equal(next.level, 2);
  assert.equal(next.levelXp, 30);
  assert.ok(next.badges.find((b) => b.id === "correct-ten")?.earned);
});
test("lição libera a próxima ao concluir, estrelas premiam acertos e a escolha de idioma é respeitada", () => {
  const p = blankProgress(),
    initial = journeyLessons(p, questions, "ingles", now),
    first = initial[0],
    second = initial[1];
  assert.ok(first.unlocked);
  assert.equal(second.unlocked, false);
  p.attempts = first.questionIds
    .slice(0, 4)
    .map((qid, i) => attempt(String(i), qid, "2026-10-16T13:00:00Z"));
  assert.equal(journeyLessons(p, questions, "ingles", now)[1].unlocked, false);
  p.attempts.push(
    attempt("last", first.questionIds[4], "2026-10-16T13:00:00Z"),
  );
  const complete = journeyLessons(p, questions, "ingles", now);
  assert.ok(complete[0].completed);
  assert.equal(complete[0].stars, 3);
  assert.ok(complete[1].unlocked);
  assert.ok(
    journeyLessons(p, questions, "espanhol", now)
      .filter((l) => l.area === "linguagens")
      .every((l) => l.questionIds.every((id) => !id.endsWith("-ingles"))),
  );
  assert.deepEqual(
    journeyLessons(p, [...questions].reverse(), "ingles", now).map(
      (l) => l.questionIds,
    ),
    complete.map((l) => l.questionIds),
  );
});
