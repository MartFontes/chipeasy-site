import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { PGlite } from "@electric-sql/pglite";
import { blankProgress } from "../lib/study";

test("migração, permissões reais de PostgreSQL e mesclagem entre dispositivos", async (t) => {
  const db = new PGlite();
  t.after(() => db.close());
  await db.exec(`
    create role anon;create role authenticated;
    create schema auth;create schema storage;
    create table auth.users(id uuid primary key,email text);
    create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;
    create table storage.buckets(id text primary key,name text,public boolean);
    create table storage.objects(id bigint generated always as identity,bucket_id text,name text);
    alter table storage.objects enable row level security;
    grant usage on schema public,auth,storage to anon,authenticated;
    grant execute on function auth.uid() to anon,authenticated;
  `);
  const migration = readFileSync(
    "supabase/migrations/202610160001_initial.sql",
    "utf8",
  );
  await db.exec(migration);
  await db.exec(migration);
  const alice = "00000000-0000-4000-8000-000000000001",
    bob = "00000000-0000-4000-8000-000000000002";
  await db.query("insert into auth.users(id,email) values($1,$2),($3,$4)", [
    alice,
    "alice@example.test",
    bob,
    "bob@example.test",
  ]);
  const questions = JSON.parse(
    readFileSync("data/catalog.json", "utf8"),
  ).questions;
  const published = questions.find(
      (q: { status: string }) => q.status === "published",
    ),
    draft = questions.find((q: { status: string }) => q.status === "reviewed");
  for (const q of [published, draft])
    await db.query("insert into public.questions(id,data) values($1,$2)", [
      q.id,
      JSON.stringify(q),
    ]);
  const as = async (role: string, uid = "") => {
    await db.exec("reset role");
    await db.query("select set_config('request.jwt.claim.sub',$1,false)", [
      uid,
    ]);
    await db.exec("set role " + role);
  };

  await t.test(
    "visitantes e alunos só veem conteúdo publicado; aluno não vira administrador",
    async () => {
      await as("anon");
      assert.equal(
        (await db.query("select * from public.questions")).rows.length,
        1,
      );
      await as("authenticated", alice);
      assert.equal(
        (await db.query<{ role: string }>("select role from profiles")).rows[0]
          .role,
        "student",
      );
      await assert.rejects(
        db.query("update profiles set role='admin' where id=$1", [alice]),
        /permission denied/,
      );
      await assert.rejects(
        db.query("insert into questions(id,data) values($1,$2)", [
          published.id + "-new",
          JSON.stringify({
            ...published,
            id: published.id + "-new",
            fingerprint: "1".repeat(64),
          }),
        ]),
        /row-level security/,
      );
    },
  );

  await t.test(
    "sincronizar duas vezes não duplica e dispositivo antigo não restaura favorito removido",
    async () => {
      const first = blankProgress();
      first.attempts = [
        {
          id: "a",
          questionId: published.id,
          selected: "A",
          correct: false,
          answeredAt: "2026-10-16T12:00:00.000Z",
          durationMs: 2000,
          sessionId: null,
        },
      ];
      first.favorites = [published.id];
      first.favoriteChanges = {
        [published.id]: { saved: true, at: "2026-10-16T12:00:00.000Z" },
      };
      const sync = async (p: unknown) =>
        (
          await db.query<{ data: typeof first }>(
            "select merge_study_progress($1::jsonb) as data",
            [JSON.stringify(p)],
          )
        ).rows[0].data;
      assert.equal((await sync(first)).attempts.length, 1);
      assert.equal((await sync(first)).attempts.length, 1);
      const newer = {
        ...first,
        favorites: [],
        favoriteChanges: {
          [published.id]: { saved: false, at: "2026-10-16T13:00:00.000Z" },
        },
        attempts: [{ ...first.attempts[0], id: "b", correct: true }],
      };
      await sync(newer);
      const final = await sync(first);
      assert.equal(final.attempts.length, 2);
      assert.deepEqual(final.favorites, []);
      await assert.rejects(
        db.query("select merge_study_progress($1::jsonb)", [
          JSON.stringify({ name: "incomplete" }),
        ]),
        /Progresso inválido/,
      );
      await assert.rejects(
        db.query("select merge_study_progress($1::jsonb)", [
          JSON.stringify({
            ...first,
            favoriteChanges: { x: { saved: "yes", at: first.updatedAt } },
          }),
        ]),
        /Favoritos inválidos/,
      );
    },
  );

  await t.test(
    "cada aluno lê e grava somente o próprio progresso",
    async () => {
      await as("authenticated", bob);
      assert.equal(
        (await db.query("select * from study_progress")).rows.length,
        0,
      );
      await db.query("select merge_study_progress($1::jsonb)", [
        JSON.stringify(blankProgress()),
      ]);
      assert.deepEqual(
        (
          await db.query<{ user_id: string }>(
            "select user_id from study_progress",
          )
        ).rows.map((r) => r.user_id),
        [bob],
      );
      await assert.rejects(
        db.query("update study_progress set data=$1 where user_id=$2", [
          "{}",
          alice,
        ]),
        /permission denied/,
      );
      await as("anon");
      await assert.rejects(
        db.query("select merge_study_progress($1::jsonb)", [
          JSON.stringify(blankProgress()),
        ]),
        /permission denied/,
      );
    },
  );

  await t.test(
    "administrador vê rascunhos e publica; banco rejeita publicação incompleta",
    async () => {
      await as("postgres");
      await db.query("update profiles set role='admin' where id=$1", [alice]);
      await as("authenticated", alice);
      assert.equal((await db.query("select * from questions")).rows.length, 2);
      await db.query("update questions set data=$1 where id=$2", [
        JSON.stringify({ ...draft, status: "published" }),
        draft.id,
      ]);
      await assert.rejects(
        db.query("insert into questions(id,data) values($1,$2)", [
          "bad-data",
          JSON.stringify({ id: "bad-data" }),
        ]),
        /check constraint/,
      );
      await as("anon");
      assert.equal((await db.query("select * from questions")).rows.length, 2);
    },
  );
  await t.test(
    "carga completa pode ser repetida e preserva a revisão já publicada",
    async () => {
      await as("postgres");
      const seed = readFileSync("supabase/seed.sql", "utf8");
      await db.exec(seed);
      await db.exec(seed);
      assert.equal(
        (await db.query("select * from questions")).rows.length,
        370,
      );
      const saved = await db.query<{ status: string }>(
        "select status from questions where id=$1",
        [draft.id],
      );
      assert.equal(saved.rows[0].status, "published");
    },
  );
});
