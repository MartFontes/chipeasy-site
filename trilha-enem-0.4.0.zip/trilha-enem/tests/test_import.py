"""Validate the catalog against the preserved PDFs, not the upstream API."""
import hashlib,json,sys,unittest,tempfile,re
import xml.etree.ElementTree as ET
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from import_seed import markers,answer_key,question_clips,snapshot
from pdf_vectors import vector_region
import fitz

ROOT=Path(__file__).resolve().parents[1]

class OfficialSources(unittest.TestCase):
    def test_answers_and_numbering(self):
        data=json.loads((ROOT/'data/catalog.json').read_text())['questions']
        for year in [2022,2023]:
            for day,booklet,count in [(1,1,95),(2,7,90)]:
                exam=ROOT/f'public/sources/{year}_PV_impresso_D{day}_CD{booklet}.pdf'
                answers=ROOT/f'public/sources/{year}_GB_impresso_D{day}_CD{booklet}.pdf'
                doc,found=markers(exam);keys=answer_key(answers)
                self.assertEqual(len(found),count);self.assertEqual(len(keys),count)
                for q in [q for q in data if q['year']==year and q['day']==day]:
                    self.assertEqual(q['answer'],keys[(q['number'],q['language'])],q['id'])
                    self.assertEqual(q['annulled'],keys[(q['number'],q['language'])] is None)
                doc.close()

    def test_preserved_pdf_hashes(self):
        report=json.loads((ROOT/'data/import-report.json').read_text())
        for source in report['pdfSources']:
            self.assertEqual(hashlib.sha256((ROOT/'public/sources'/source['file']).read_bytes()).hexdigest(),source['sha256'])

    def test_full_width_question_is_not_cut_in_half(self):
        doc,found=markers(ROOT/'public/sources/2023_PV_impresso_D2_CD7.pdf')
        marker=next(m for m in found if m['number']==174)
        self.assertEqual(marker['columns'],1)
        clips=question_clips(doc,found,marker)
        self.assertGreater(clips[0][1].width,doc[marker['page']].rect.width*.8)
        doc.close()

    def test_upgraded_figures_preserve_the_exact_pdf_region(self):
        report=json.loads((ROOT/'data/media-quality.json').read_text());mapping=json.loads((ROOT/'data/media-map.json').read_text());docs={}
        self.assertEqual(report['questionCrops'],11)
        self.assertEqual(len(report['hiddenHeaderFragments']),6)
        self.assertEqual(len(mapping),report['upgraded'])
        for record in report['records']:
            source=record['pdf']
            if source not in docs:docs[source]=fitz.open(ROOT/'public/sources'/source)
            page=docs[source][record['page']-1];clip=fitz.Rect(record['clip']);self.assertTrue(page.rect.contains(clip))
            expected=vector_region(page,clip);actual=(ROOT/'public'/record['new'].lstrip('/')).read_bytes()
            self.assertEqual(hashlib.sha256(actual).hexdigest(),hashlib.sha256(expected).hexdigest(),record['new'])
            root=ET.fromstring(actual)
            self.assertEqual(int(root.attrib['width']),round(clip.width*4))
            self.assertFalse(root.findall('.//{http://www.w3.org/2000/svg}script'))
            for el in root.iter():
                for attr,value in el.attrib.items():
                    if attr.endswith('href'):self.assertTrue(value.startswith(('#','data:image/')),value[:50])
        for doc in docs.values():doc.close()

    def test_new_imports_use_vectors_instead_of_compressed_screenshots(self):
        doc,found=markers(ROOT/'public/sources/2023_PV_impresso_D2_CD7.pdf');marker=next(m for m in found if m['number']==174)
        with tempfile.TemporaryDirectory()as tmp:
            public=Path(tmp);markdown,_=snapshot(public,2023,doc,found,marker)
            path=re.search(r'\]\(([^)]+)\)',markdown).group(1)
            self.assertTrue(path.endswith('.svg'))
            svg=ET.fromstring((public/path.lstrip('/')).read_bytes())
            self.assertGreater(int(svg.attrib['width']),1800)
        doc.close()

    def test_alternative_diagrams_are_reviewed_and_match_their_option_label(self):
        report=json.loads((ROOT/'data/media-quality.json').read_text());questions={q['id']:q for q in json.loads((ROOT/'data/catalog.json').read_text())['questions']}
        checked=0
        for record in report['records']:
            q=questions[record['questionId']];option=next((a for a in q['alternatives']if a['image']==record['old']),None)
            if not option:continue
            self.assertTrue(record.get('manualReview'),record['old']);checked+=1
            with fitz.open(ROOT/'public/sources'/record['pdf'])as doc:
                page=doc[record['page']-1];clip=fitz.Rect(record['clip']);labels=[]
                for block in page.get_text('dict')['blocks']:
                    for line in block.get('lines',[]):
                        text=''.join(s['text']for s in line['spans']).strip();x,y,x2,y2=line['bbox']
                        if text==option['letter']and 0<clip.x0-x<30 and clip.y0<(y+y2)/2<clip.y1:labels.append(text)
                self.assertTrue(labels,f"Recorte não corresponde à alternativa {option['letter']} de {q['id']}")
        self.assertEqual(checked,5)

if __name__=='__main__':unittest.main()
