import { test, expect, type Page } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
import { readFileSync } from "node:fs";
import { blankProgress } from "../../lib/study";
import type { Question } from "../../lib/types";
const questions: Question[] = JSON.parse(
  readFileSync("data/catalog.json", "utf8"),
).questions;
const browserErrors = new WeakMap<Page, string[]>();
test.beforeEach(({ page }) => {
  const errors: string[] = [];
  browserErrors.set(page, errors);
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("console", (message) => {
    if (message.type() === "error") errors.push(message.text());
  });
});
test.afterEach(({ page }) => {
  expect(browserErrors.get(page)).toEqual([]);
});

async function currentQuestion(page: Page) {
  const label = await page.getByRole("dialog").getAttribute("aria-label");
  const match = label!.match(/Questão (\d+) do Enem (\d+)/)!;
  return questions.find(
    (q) =>
      q.number === Number(match[1]) &&
      q.year === Number(match[2]) &&
      q.language !== "espanhol",
  )!;
}
async function attempts(page: Page) {
  return page.evaluate(
    () =>
      JSON.parse(localStorage.getItem("trilha-enem.progress.v1.guest")!)
        .attempts.length,
  );
}

test("Capi reage, som é opt-in e a preferência permanece após recarregar", async ({
  page,
}) => {
  await page.goto("/");
  const sound = page
    .locator(".topbar")
    .getByRole("button", { name: "Sons de recompensa", exact: true });
  await expect(sound).toHaveAttribute("aria-pressed", "false");
  await expect(page.locator('img[src*="capy-explorer"]')).toHaveCount(0);
  await page
    .getByRole("button", { name: "Dar um oi à Capi", exact: true })
    .click();
  await expect(page.locator(".journey-art .capybara")).toHaveAttribute(
    "data-mood",
    "wave",
  );
  await expect(page.locator(".hero-speech")).toContainText(
    "Eu acredito em você",
  );
  await sound.click();
  await expect(sound).toHaveAttribute("aria-pressed", "true");
  await page.reload();
  await expect(sound).toHaveAttribute("aria-pressed", "true");
  await sound.click();
  await expect(sound).toHaveAttribute("aria-pressed", "false");
});

test("feedback reflete acerto e erro; clique duplo não duplica XP ou tentativas", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("/");
  await page
    .getByRole("button", { name: "Começar minha jornada", exact: true })
    .click();
  const boxBefore = await page.locator(".reader-companion").boundingBox();
  const first = await currentQuestion(page);
  await page.keyboard.press(first.answer!.toLowerCase());
  // Two clicks in the same event turn exercise the submission guard before React commits.
  await page
    .getByRole("button", { name: "Conferir resposta", exact: true })
    .evaluate((button: HTMLButtonElement) => {
      button.click();
      button.click();
    });
  await expect(page.locator(".reader-companion .capybara")).toHaveAttribute(
    "data-mood",
    "correct",
  );
  await expect(page.locator(".answer-xp")).toHaveText("+20 XP conquistados");
  // SVG rotation must keep the arm connected to the shoulder throughout the jump.
  await page.waitForTimeout(160);
  const pivotDistance = await page
    .locator('.reader-companion [data-part="arm-wave"]')
    .evaluate((arm: SVGGraphicsElement) => {
      const parent = arm.parentElement as unknown as SVGGraphicsElement;
      const pivot = new DOMPoint(111, 198);
      const local = pivot.matrixTransform(arm.getScreenCTM()!);
      const shoulder = pivot.matrixTransform(parent.getScreenCTM()!);
      return Math.hypot(local.x - shoulder.x, local.y - shoulder.y);
    });
  expect(pivotDistance).toBeLessThan(1);
  await expect(page.getByTestId("floating-xp")).toHaveText("+20 XP");
  await expect.poll(() => attempts(page)).toBe(1);
  await expect
    .poll(() =>
      page.getByTestId("reward-canvas").evaluate((el: HTMLCanvasElement) => {
        const ctx = el.getContext("2d");
        return (
          !!ctx &&
          ctx
            .getImageData(0, 0, el.width, el.height)
            .data.some((value, i) => i % 4 === 3 && value > 0)
        );
      }),
    )
    .toBe(true);
  const boxAfter = await page.locator(".reader-companion").boundingBox();
  expect(Math.abs(boxBefore!.height - boxAfter!.height)).toBeLessThanOrEqual(1);
  await page
    .getByRole("button", { name: "Próxima questão", exact: true })
    .click();
  const second = await currentQuestion(page);
  const wrong = second.answer === "A" ? "B" : "A";
  await page.keyboard.press(wrong.toLowerCase());
  await page
    .getByRole("button", { name: "Conferir resposta", exact: true })
    .click();
  await expect(page.locator(".reader-companion .capybara")).toHaveAttribute(
    "data-mood",
    "encourage",
  );
  await expect(page.locator(".answer-xp")).toHaveText("+10 XP conquistados");
  await expect(page.locator(".answer-feedback.retry")).toContainText(
    "Essa vale uma nova leitura.",
  );
  await expect.poll(() => attempts(page)).toBe(2);
  expect(errors).toEqual([]);
});

test("baú explica o desafio, fecha por Escape e devolve o foco", async ({
  page,
}) => {
  await page.goto("/");
  const chest = page.getByRole("button", {
    name: "Ver desafio do baú diário",
    exact: true,
  });
  await chest.click();
  const dialog = page.getByRole("dialog", {
    name: "Uma descoberta de cada vez.",
    exact: true,
  });
  await expect(dialog).toContainText("0 de 5 questões");
  await expect(dialog.locator(".chest-art")).toHaveAttribute(
    "data-open",
    "false",
  );
  await page.keyboard.press("Escape");
  await expect(dialog).toHaveCount(0);
  await expect(chest).toBeFocused();
  await expect(page.getByTestId("xp-total")).toHaveText("0");
});

test("abrir novamente um baú conquistado não concede o bônus outra vez", async ({
  page,
}) => {
  const progress = blankProgress();
  progress.attempts = questions
    .filter((q) => !q.annulled && q.answer)
    .slice(0, 5)
    .map((q, i) => ({
      id: `chest-${i}`,
      questionId: q.id,
      selected: q.answer!,
      correct: true,
      answeredAt: new Date(Date.now() - 10000).toISOString(),
      durationMs: 2000,
      sessionId: null,
    }));
  await page.addInitScript(
    (p) =>
      localStorage.setItem("trilha-enem.progress.v1.guest", JSON.stringify(p)),
    progress,
  );
  await page.goto("/");
  await expect(page.getByTestId("xp-total")).toHaveText("130");
  for (let i = 0; i < 2; i++) {
    await page
      .getByRole("button", {
        name: "Abrir baú diário, bônus recebido",
        exact: true,
      })
      .click();
    const dialog = page.getByRole("dialog", {
      name: "Tesouro conquistado!",
      exact: true,
    });
    await expect(dialog.locator(".chest-art")).toHaveAttribute(
      "data-open",
      "true",
    );
    await expect(dialog).toContainText("Bônus recebido");
    await dialog
      .getByRole("button", { name: "Continuar estudando", exact: true })
      .click();
    await expect(page.getByTestId("xp-total")).toHaveText("130");
    expect(await attempts(page)).toBe(5);
  }
});

test("movimento reduzido mantém o feedback e suprime partículas e saltos", async ({
  page,
}) => {
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.goto("/");
  await page
    .getByRole("button", { name: "Começar minha jornada", exact: true })
    .click();
  const q = await currentQuestion(page);
  await page.keyboard.press(q.answer!.toLowerCase());
  await page
    .getByRole("button", { name: "Conferir resposta", exact: true })
    .click();
  await expect(page.locator(".answer-feedback")).toContainText("Mais um passo");
  await expect(page.locator(".reader-companion .capybara")).toHaveAttribute(
    "data-mood",
    "correct",
  );
  await expect(page.getByTestId("floating-xp")).toHaveCount(0);
  await expect(page.locator(".reward-effects")).toHaveCount(0);
  await expect(
    page.getByRole("progressbar", { name: "Avanço nesta lição", exact: true }),
  ).toHaveAttribute("aria-valuenow", "20");
  await expect
    .poll(() =>
      page
        .locator(".reader-companion .capybara > g")
        .evaluate((el) => getComputedStyle(el).transform),
    )
    .toBe("none");
});

test("jornada, baú, leitor, feedback e conclusão passam nas regras automáticas de acessibilidade", async ({
  page,
}) => {
  await page.emulateMedia({ reducedMotion: "reduce" });
  const audit = async () => {
    const result = await new AxeBuilder({ page })
      .withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"])
      .analyze();
    expect(
      result.violations.map((v) => ({
        id: v.id,
        targets: v.nodes.map((n) => n.target),
      })),
    ).toEqual([]);
  };
  await page.goto("/");
  await expect(page.getByTestId("xp-total")).toHaveText("0");
  await audit();
  await page
    .getByRole("button", { name: "Ver desafio do baú diário", exact: true })
    .click();
  await audit();
  await page.keyboard.press("Escape");
  await page
    .getByRole("button", { name: "Começar minha jornada", exact: true })
    .click();
  await audit();
  for (let i = 0; i < 5; i++) {
    const q = await currentQuestion(page);
    await page.keyboard.press(q.answer!.toLowerCase());
    await page
      .getByRole("button", { name: "Conferir resposta", exact: true })
      .click();
    if (i === 0) await audit();
    await page
      .getByRole("button", {
        name: i === 4 ? "Concluir lição" : "Próxima questão",
        exact: true,
      })
      .click();
  }
  await expect(
    page.getByRole("dialog", { name: "Lição concluída!", exact: true }),
  ).toBeVisible();
  await audit();
});
