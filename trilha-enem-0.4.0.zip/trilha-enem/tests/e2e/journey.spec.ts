import { test, expect, type Page } from "@playwright/test";
import { readFileSync } from "node:fs";
import { blankProgress } from "../../lib/study";
const questions = JSON.parse(
  readFileSync("data/catalog.json", "utf8"),
).questions;
async function navigate(page: Page, name: string) {
  const menu = page.getByRole("button", { name: "Abrir menu", exact: true });
  if (await menu.isVisible()) await menu.click();
  await page.getByRole("button", { name, exact: true }).click();
}
async function answerCurrent(page: Page) {
  const dialog = page.getByRole("dialog"),
    label = await dialog.getAttribute("aria-label"),
    match = label!.match(/Questão (\d+) do Enem (\d+)/)!;
  const question = questions.find(
    (q: { number: number; year: number; language: string | null }) =>
      q.number === Number(match[1]) &&
      q.year === Number(match[2]) &&
      q.language !== "espanhol",
  );
  await page.keyboard.press(question.answer.toLowerCase());
  await page.getByRole("button", { name: "Conferir resposta" }).click();
}
async function finishLesson(page: Page, total = 5) {
  for (let i = 0; i < total; i++) {
    await answerCurrent(page);
    await page
      .getByRole("button", {
        name: i === total - 1 ? "Concluir lição" : "Próxima questão",
        exact: true,
      })
      .click();
  }
}
test("questões já estudadas contam e a lição parcial retoma sem duplicar a sessão", async ({
  page,
}) => {
  const plan = JSON.parse(readFileSync("data/journey-plan.json", "utf8"));
  const learned = plan.worlds[0].lessons[0].questionIds.slice(0, 2);
  const p = blankProgress();
  p.attempts = learned.map((questionId: string, i: number) => ({
    id: "legacy-" + i,
    questionId,
    selected: questions.find((q: { id: string }) => q.id === questionId).answer,
    correct: true,
    answeredAt: new Date(Date.now() - 60000).toISOString(),
    durationMs: 3000,
    sessionId: null,
  }));
  await page.addInitScript((progress) => {
    if (!localStorage.getItem("trilha-enem.progress.v1.guest"))
      localStorage.setItem(
        "trilha-enem.progress.v1.guest",
        JSON.stringify(progress),
      );
  }, p);
  await page.goto("/");
  await expect(page.getByTestId("xp-total")).toHaveText("40");
  await page
    .getByRole("button", { name: "Continuar minha jornada", exact: true })
    .click();
  await answerCurrent(page);
  await page.getByRole("button", { name: "Fechar questão" }).click();
  await page.reload();
  await page
    .getByRole("button", { name: "Continuar minha jornada", exact: true })
    .click();
  await finishLesson(page, 2);
  const celebration = page.getByRole("dialog", {
    name: "Lição concluída!",
    exact: true,
  });
  await expect(celebration).toContainText("3/3");
  await expect(celebration).toContainText("+70 XP");
  await celebration
    .getByRole("button", { name: "Continuar minha jornada", exact: true })
    .click();
  await expect(page.getByTestId("xp-total")).toHaveText("130");
  await navigate(page, "Meus simulados");
  await expect(page.locator(".session-list>div")).toHaveCount(1);
  await expect(page.locator(".session-list")).toContainText(
    "3 de 3 respondidas · Concluída",
  );
});
test("jornada libera etapas, concede XP uma vez e preserva avanço ao recarregar", async ({
  page,
}, info) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("/");
  await expect(
    page.getByRole("heading", { name: /Cada passo conta/ }),
  ).toBeVisible();
  await expect(page.getByTestId("xp-total")).toHaveText("0");
  await expect(page.getByTestId("streak-count")).toHaveText("0");
  await expect(
    page.getByRole("button", {
      name: "Lição 2 de Linguagens, bloqueada",
      exact: true,
    }),
  ).toBeDisabled();
  await page.screenshot({
    path: `artifacts/journey-${info.project.name}.png`,
    fullPage: true,
  });
  await page
    .getByRole("button", { name: "Começar minha jornada", exact: true })
    .click();
  await finishLesson(page);
  const celebration = page.getByRole("dialog", {
    name: "Lição concluída!",
    exact: true,
  });
  await expect(celebration).toBeVisible();
  await expect(celebration).toContainText("+130 XP");
  await page.screenshot({
    path: `artifacts/celebration-${info.project.name}.png`,
  });
  await celebration
    .getByRole("button", { name: "Continuar minha jornada", exact: true })
    .click();
  await expect(page.getByTestId("xp-total")).toHaveText("130");
  await expect(page.getByTestId("streak-count")).toHaveText("1");
  await expect(
    page.getByRole("button", {
      name: "Lição 2 de Linguagens, disponível",
      exact: true,
    }),
  ).toBeEnabled();
  await page.reload();
  await expect(page.getByTestId("xp-total")).toHaveText("130");
  await page
    .getByRole("button", {
      name: "Lição 1 de Linguagens, concluída",
      exact: true,
    })
    .click();
  await finishLesson(page);
  await expect(
    page.getByRole("dialog", { name: "Lição concluída!", exact: true }),
  ).toContainText("+0 XP");
  await celebration
    .getByRole("button", { name: "Continuar minha jornada", exact: true })
    .click();
  await expect(page.getByTestId("xp-total")).toHaveText("130");
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
  await page.getByRole("button", { name: "Matemática", exact: true }).click();
  await page.getByLabel("Idioma da jornada").selectOption("espanhol");
  await page.reload();
  await expect(
    page.getByRole("button", { name: "Matemática", exact: true }),
  ).toHaveAttribute("aria-pressed", "true");
  await expect(page.getByLabel("Idioma da jornada")).toHaveValue("espanhol");
  expect(errors).toEqual([]);
});
test("histórico recupera sequência e abrir o aplicativo sem estudar não conta novo dia", async ({
  page,
}) => {
  await page.clock.install({ time: new Date("2026-10-16T18:00:00Z") });
  const p = blankProgress();
  p.updatedAt = "2026-10-16T16:00:00Z";
  p.attempts = [14, 15, 16].map((d, i) => ({
    id: "streak-" + i,
    questionId: questions[i].id,
    selected: "A",
    correct: false,
    answeredAt: `2026-10-${d}T15:00:00Z`,
    durationMs: 2000,
    sessionId: null,
  }));
  await page.addInitScript(
    (progress) =>
      localStorage.setItem(
        "trilha-enem.progress.v1.guest",
        JSON.stringify(progress),
      ),
    p,
  );
  await page.goto("/");
  await expect(page.getByTestId("streak-count")).toHaveText("3");
  await expect(page.locator(".streak-record")).toContainText("3 dias");
  await page.clock.setFixedTime(new Date("2026-10-17T18:00:00Z"));
  await page.evaluate(() => window.dispatchEvent(new Event("focus")));
  await expect(page.getByTestId("streak-count")).toHaveText("3");
  await expect(page.locator(".journey-score").first()).toContainText(
    "Estude hoje",
  );
  await page.clock.setFixedTime(new Date("2026-10-18T18:00:00Z"));
  await page.evaluate(() => window.dispatchEvent(new Event("focus")));
  await expect(page.getByTestId("streak-count")).toHaveText("0");
  await expect(page.locator(".streak-record")).toContainText("3 dias");
});
test("figura vetorial abre, amplia e fecha mantendo a questão aberta", async ({
  page,
}, info) => {
  await page.goto("/");
  await navigate(page, "Banco de questões");
  await page.getByLabel("Buscar questões").fill("174");
  await page.getByLabel("Ano", { exact: true }).selectOption("2023");
  await page.getByRole("button", { name: "Resolver", exact: true }).click();
  await page
    .getByRole("link", { name: /Ampliar:/ })
    .first()
    .click();
  const image = page.getByRole("dialog", {
    name: "Imagem ampliada da questão",
    exact: true,
  });
  await expect(image).toBeVisible();
  await expect(image.locator("img")).toHaveAttribute("src", /\.svg$/);
  await image
    .getByRole("button", { name: "Aumentar imagem", exact: true })
    .click();
  await image
    .getByRole("button", { name: "Aumentar imagem", exact: true })
    .click();
  await expect(image.getByLabel("Ampliação")).toHaveText("200%");
  expect(
    await image
      .locator(".image-viewport")
      .evaluate((el) => el.scrollWidth > el.clientWidth),
  ).toBe(true);
  await page.screenshot({
    path: `artifacts/image-zoom-${info.project.name}.png`,
  });
  await page.keyboard.press("Escape");
  await expect(image).toHaveCount(0);
  await expect(page.getByRole("dialog")).toBeVisible();
});
