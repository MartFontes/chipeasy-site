import { test, expect, type Page } from "@playwright/test";
import { readFileSync } from "node:fs";
const catalog = JSON.parse(readFileSync("data/catalog.json", "utf8"));
async function navigate(page: Page, name: string) {
  const menu = page.getByRole("button", { name: "Abrir menu", exact: true });
  if (await menu.isVisible()) await menu.click();
  await page
    .getByRole("button", { name: new RegExp("^" + name + "(?: \\d+)?$") })
    .click();
}
async function weighted(page: Page) {
  await navigate(page, "Banco de questões");
  await page.getByLabel("Buscar questões").fill("média ponderada");
  await page.getByRole("button", { name: "Resolver", exact: true }).click();
  await expect(page.getByRole("dialog")).toBeVisible();
}
test.beforeEach(async ({ page }) => {
  await page.goto("/");
  await expect(
    page.getByRole("heading", { name: /Cada passo conta/ }),
  ).toBeVisible();
});

test("biblioteca, filtros, erro corrigido, favoritos e persistência", async ({
  page,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await navigate(page, "Banco de questões");
  await expect(page.locator(".results-meta")).toContainText("370");
  await page
    .getByLabel("Área do conhecimento", { exact: true })
    .selectOption("matematica");
  await page.getByLabel("Ano", { exact: true }).selectOption("2023");
  await expect(page.locator(".results-meta")).toContainText("45");
  await page.getByLabel("Buscar questões").fill("média ponderada");
  await page.getByRole("button", { name: "Resolver", exact: true }).click();
  const dialog = page.getByRole("dialog");
  await expect
    .poll(() =>
      dialog
        .locator(".question-context img")
        .evaluate((img: HTMLImageElement) => img.naturalWidth),
    )
    .toBeGreaterThan(0);
  await dialog
    .getByRole("button", { name: "Favoritar questão", exact: true })
    .click();
  await dialog
    .locator(".alternative")
    .filter({ has: page.locator('input[value="A"]') })
    .click();
  await dialog.getByRole("button", { name: "Conferir resposta" }).click();
  await expect(dialog).toContainText("Essa vale uma nova leitura.");
  await expect(dialog.locator(".katex").first()).toBeVisible();
  await dialog.getByRole("button", { name: "Fechar questão" }).click();
  await navigate(page, "Caderno de erros");
  await expect(page.locator(".question-card")).toHaveCount(1);
  await page.getByRole("button", { name: "Resolver", exact: true }).click();
  await page.keyboard.press("c");
  await page.getByRole("button", { name: "Conferir resposta" }).click();
  await expect(page.getByRole("dialog")).toContainText("Mais um passo");
  await page.getByRole("button", { name: "Fechar questão" }).click();
  await expect(page.locator(".question-card")).toHaveCount(0);
  await page.reload();
  await navigate(page, "Favoritos");
  await expect(page.locator(".question-card")).toHaveCount(1);
  await navigate(page, "Meu desempenho");
  await expect(
    page.locator(".stat-card").filter({ hasText: "Taxa de acertos" }),
  ).toContainText("100%");
  expect(errors).toEqual([]);
});

test("backup exportado e importação repetida preservam respostas", async ({
  page,
}) => {
  await weighted(page);
  await page.keyboard.press("c");
  await page.getByRole("button", { name: "Conferir resposta" }).click();
  await page.getByRole("button", { name: "Fechar questão" }).click();
  await navigate(page, "Meu perfil");
  await page.getByLabel("Como podemos chamar você?").fill("Estudante");
  const download = page.waitForEvent("download");
  await page.getByRole("button", { name: "Exportar meu progresso" }).click();
  const file = await download;
  const path = await file.path();
  expect(path).toBeTruthy();
  await page.locator("input[type=file]").setInputFiles(path!);
  await expect(page.getByRole("status")).toContainText("Progresso importado");
  await page.reload();
  await navigate(page, "Meu desempenho");
  await expect(
    page.locator(".stat-card").filter({ hasText: "Questões diferentes" }),
  ).toContainText("1 tentativas registradas");
});

test("prática de cinco questões pode ser retomada e concluída", async ({
  page,
}) => {
  await navigate(page, "Meus simulados");
  await page.getByLabel("Quantidade de questões").selectOption("5");
  await page.getByRole("button", { name: "Começar minha prática" }).click();
  await page.keyboard.press("a");
  await page.getByRole("button", { name: "Conferir resposta" }).click();
  await page.getByRole("button", { name: "Fechar questão" }).click();
  await page.reload();
  await navigate(page, "Meus simulados");
  await expect(page.locator(".session-list")).toContainText("1 de 5");
  await page.getByRole("button", { name: "Continuar", exact: true }).click();
  for (let i = 0; i < 4; i++) {
    await page.keyboard.press("a");
    await page.getByRole("button", { name: "Conferir resposta" }).click();
    await page
      .getByRole("button", {
        name: i === 3 ? "Concluir prática" : "Próxima questão",
        exact: true,
      })
      .click();
  }
  await expect(page.locator(".session-list")).toContainText(
    "5 de 5 respondidas · Concluída",
  );
});

test("revisão local publica alteração e ignora duplicata sem sobrescrever", async ({
  page,
}) => {
  await page.goto("/revisao");
  await page.getByLabel("Buscar revisão").fill("enem-2023-regular-137");
  await page.locator(".review-list button").click();
  await page
    .getByRole("textbox", { name: "Resolução comentada", exact: true })
    .fill("Explicação de revisão: média de R$ 3.250,00.");
  await page.getByRole("button", { name: "Aprovar e publicar" }).click();
  await expect(page.getByRole("status")).toContainText("Revisão salva");
  const q = catalog.questions.find(
    (q: { id: string }) => q.id === "enem-2023-regular-137",
  );
  await page.locator("input[type=file]").setInputFiles({
    name: "duplicata.json",
    mimeType: "application/json",
    buffer: Buffer.from(JSON.stringify({ questions: [q] })),
  });
  await expect(page.getByRole("status")).toContainText("1 repetidas ignoradas");
  await page.goto("/");
  await weighted(page);
  await page.keyboard.press("c");
  await page.getByRole("button", { name: "Conferir resposta" }).click();
  await expect(page.getByRole("dialog")).toContainText(
    "Explicação de revisão: média",
  );
});

test("leitura sem rolagem horizontal, imagens recuperadas e navegação por teclado", async ({
  page,
}, info) => {
  await page.screenshot({
    path: `artifacts/dashboard-${info.project.name}.png`,
    fullPage: true,
  });
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
  await navigate(page, "Banco de questões");
  await page.getByLabel("Buscar questões").fill("174");
  await page.getByLabel("Ano", { exact: true }).selectOption("2023");
  await page.getByRole("button", { name: "Resolver", exact: true }).click();
  await expect(page.getByRole("dialog").locator("img").first()).toBeVisible();
  await expect
    .poll(() =>
      page
        .getByRole("dialog")
        .locator("img")
        .first()
        .evaluate((img: HTMLImageElement) => img.naturalWidth),
    )
    .toBeGreaterThan(800);
  expect(
    await page
      .getByRole("dialog")
      .evaluate((el) => el.scrollWidth <= el.clientWidth),
  ).toBe(true);
  await page.screenshot({
    path: `artifacts/question-${info.project.name}.png`,
    fullPage: true,
  });
  await page.keyboard.press("Escape");
  await expect(page.getByRole("dialog")).toHaveCount(0);
});
