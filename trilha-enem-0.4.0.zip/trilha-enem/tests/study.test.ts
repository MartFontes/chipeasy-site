import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync, existsSync } from "node:fs";
import {
  blankProgress,
  dayKey,
  EMPTY_FILTERS,
  filterQuestions,
  mergeProgress,
  safeProgress,
  summary,
} from "../lib/study";
import { mergeCatalog, questionSchema } from "../lib/review";
import type { Attempt, Question } from "../lib/types";

const catalog = JSON.parse(readFileSync("data/catalog.json", "utf8"));
const questions: Question[] = catalog.questions;
const attempt = (
  id: string,
  questionId: string,
  correct: boolean | null,
  answeredAt = "2026-10-16T13:00:00.000Z",
): Attempt => ({
  id,
  questionId,
  correct,
  answeredAt,
  selected: "C",
  durationMs: 2000,
  sessionId: null,
});

test("370 questões válidas, sem IDs ou fingerprints repetidos, com todas as imagens presentes", () => {
  assert.equal(questions.length, 370);
  assert.equal(new Set(questions.map((q) => q.id)).size, 370);
  assert.equal(new Set(questions.map((q) => q.fingerprint)).size, 370);
  for (const year of [2022, 2023])
    assert.equal(questions.filter((q) => q.year === year).length, 185);
  for (const q of questions) {
    questionSchema.parse(q);
    assert.equal(q.answerVerified, true);
    const images = [...q.context.matchAll(/!\[[^\]]*\]\(([^)]+)\)/g)]
      .map((m) => m[1])
      .concat(q.alternatives.flatMap((a) => (a.image ? [a.image] : [])));
    for (const image of images) {
      assert.ok(image.startsWith("/questions/"));
      assert.ok(existsSync("public" + image), image);
    }
  }
  assert.equal(questions.filter((q) => q.annulled).length, 2);
  assert.equal(
    questions.find((q) => q.year === 2022 && q.number === 143)?.answer,
    "D",
  );
});

test("filtros combinados respeitam ano, área, acentos e escolha de idioma", () => {
  const p = blankProgress();
  assert.equal(
    filterQuestions(
      questions,
      { ...EMPTY_FILTERS, year: "2023", area: "matematica" },
      p,
    ).length,
    45,
  );
  assert.equal(
    filterQuestions(
      questions,
      { ...EMPTY_FILTERS, year: "2023", language: "ingles" },
      p,
    ).length,
    180,
  );
  const spanish = filterQuestions(
    questions,
    { ...EMPTY_FILTERS, year: "2023", language: "espanhol" },
    p,
  );
  assert.ok(spanish.every((q) => q.language !== "ingles"));
  assert.equal(
    filterQuestions(
      questions,
      { ...EMPTY_FILTERS, query: "media ponderada" },
      p,
    )[0]?.id,
    "enem-2023-regular-137",
  );
});

test("corrigir um erro atualiza o caderno e anuladas não alteram a taxa de acertos", () => {
  const p = blankProgress(),
    q = questions[0];
  p.attempts = [
    attempt("a", q.id, false),
    attempt("b", q.id, true, "2026-10-16T14:00:00.000Z"),
    attempt("c", "annulled", null),
  ];
  assert.equal(summary(p).answered, 2);
  assert.equal(summary(p).accuracy, 100);
  assert.equal(summary(p).wrong, 0);
  assert.equal(
    filterQuestions(questions, { ...EMPTY_FILTERS, state: "wrong" }, p).length,
    0,
  );
  assert.equal(dayKey("2026-10-16T02:30:00Z"), "2026-10-15");
});

test("mesclar cópias repetidas preserva tentativas, conclusão e remoção de favoritos", () => {
  const a = blankProgress(),
    b = blankProgress();
  a.attempts = [attempt("first", "q1", true)];
  b.attempts = [...a.attempts, attempt("second", "q2", false)];
  a.favorites = ["q1"];
  a.favoriteChanges = { q1: { saved: true, at: "2026-10-16T12:00:00.000Z" } };
  b.favorites = [];
  b.favoriteChanges = { q1: { saved: false, at: "2026-10-16T13:00:00.000Z" } };
  a.sessions = [
    {
      id: "session",
      title: "Treino",
      questionIds: ["q1"],
      createdAt: a.updatedAt,
      finishedAt: a.updatedAt,
    },
  ];
  b.sessions = [{ ...a.sessions[0], finishedAt: null }];
  const merged = mergeProgress(a, b),
    again = mergeProgress(merged, a);
  assert.equal(again.attempts.length, 2);
  assert.deepEqual(again.favorites, []);
  assert.ok(again.sessions[0].finishedAt);
});

test("importação rejeita progresso inválido e mantém compatibilidade com cópias sem eventos de favorito", () => {
  for (const patch of [
    { version: 2 },
    { dailyGoal: 0 },
    { favoriteChanges: null },
    { attempts: [{}] },
    { sessions: [{ id: "s", questionIds: "invalid" }] },
    { updatedAt: "invalid" },
  ])
    assert.throws(() => safeProgress({ ...blankProgress(), ...patch }));
  const old = { ...blankProgress() };
  delete (old as Partial<typeof old>).favoriteChanges;
  assert.deepEqual(safeProgress(old).favoriteChanges, {});
});

test("revisão bloqueia gabarito não conferido, alternativas repetidas e caminho externo de imagem", () => {
  const q = structuredClone(questions[0]);
  assert.equal(
    questionSchema.safeParse({
      ...q,
      status: "published",
      answerVerified: false,
    }).success,
    false,
  );
  assert.equal(
    questionSchema.safeParse({
      ...q,
      alternatives: q.alternatives.map((a) => ({ ...a, letter: "A" })),
    }).success,
    false,
  );
  assert.equal(
    questionSchema.safeParse({
      ...q,
      alternatives: q.alternatives.map((a) => ({
        ...a,
        image: "/questions/../../secret",
      })),
    }).success,
    false,
  );
  const result = mergeCatalog([q], [{ ...q, id: q.id + "-duplicate" }]);
  assert.equal(result.duplicates, 1);
  assert.equal(result.questions.length, 1);
});
