"use client";
import { useMotionPreference } from "./use-motion-preference";

import { motion, type Variants } from "framer-motion";
import { useId } from "react";

export type CapyMood = "idle" | "wave" | "correct" | "encourage" | "celebrate";

/** Original articulated SVG: expressions, arms and body react independently. */
export function Capybara({
  mood = "idle",
  reactionKey = "rest",
  className = "",
}: {
  mood?: CapyMood;
  reactionKey?: string | number;
  className?: string;
}) {
  const reduce = useMotionPreference();
  const id = useId().replace(/:/g, "");
  const happy = mood === "correct" || mood === "celebrate";
  const waving = mood === "wave" || happy;
  const body: Variants = {
    idle: {
      y: [0, -4, 0],
      rotate: [0, 1, 0],
      transition: { duration: 4, repeat: Infinity, ease: "easeInOut" },
    },
    wave: { y: [0, -8, 0], rotate: [0, -4, 0], transition: { duration: 0.8 } },
    correct: {
      y: [0, -27, 0, -13, 0],
      rotate: [0, -6, 4, -2, 0],
      transition: { duration: 1 },
    },
    encourage: {
      y: [0, 5, 0],
      rotate: [0, -5, 0],
      transition: { duration: 0.9 },
    },
    celebrate: {
      y: [0, -30, 0, -18, 0],
      rotate: [0, -7, 7, -3, 0],
      transition: { duration: 1.25, repeat: 1, repeatDelay: 0.4 },
    },
  };
  return (
    <svg
      viewBox="0 0 320 330"
      fill="none"
      className={`capybara ${className}`}
      aria-hidden="true"
      data-mood={mood}
      data-testid="capybara"
    >
      <defs>
        <linearGradient
          id={`${id}-fur`}
          x1="112"
          y1="84"
          x2="232"
          y2="285"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#EFB369" />
          <stop offset="1" stopColor="#D88A43" />
        </linearGradient>
        <linearGradient
          id={`${id}-scarf`}
          x1="111"
          y1="172"
          x2="223"
          y2="207"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#8F5CFF" />
          <stop offset="1" stopColor="#5930DB" />
        </linearGradient>
      </defs>
      <motion.ellipse
        cx="164"
        cy="304"
        rx="79"
        ry="12"
        fill="#26114D"
        opacity="0.17"
        animate={!reduce && happy ? { rx: [79, 57, 79] } : { rx: 79 }}
        transition={{ duration: 0.8 }}
      />
      {happy &&
        [0, 1, 2, 3, 4].map((i) => (
          <motion.path
            key={`${reactionKey}-spark-${i}`}
            d="m0-11 3 8 8 3-8 3-3 8-3-8-8-3 8-3Z"
            fill={i % 2 ? "#61EAB2" : "#FFD52E"}
            initial={
              reduce ? false : { opacity: 0, scale: 0.2, x: 160, y: 150 }
            }
            animate={{
              opacity: reduce ? 1 : [0, 1, 0],
              scale: reduce ? 1 : [0.3, 1.3, 0.8],
              x: [40, 268, 62, 259, 155][i],
              y: [83, 73, 230, 220, 30][i],
              rotate: i * 30,
            }}
            transition={{
              duration: reduce ? 0 : 1.6,
              delay: reduce ? 0 : i * 0.06,
            }}
          />
        ))}
      <motion.g
        key={reactionKey}
        variants={body}
        initial={false}
        animate={reduce ? undefined : mood}
      >
        {/* Backpack and feet remain distinct, tactile pieces. */}
        <path
          d="M99 179c-27-4-40 12-38 45l3 28c1 11 10 17 24 13l27-11 4-61Z"
          fill="#2958EE"
          stroke="#182C85"
          strokeWidth="5"
        />
        <path
          d="m73 205 22-7M77 223l20-7"
          stroke="#709BFF"
          strokeWidth="7"
          strokeLinecap="round"
        />
        <path
          d="M120 258c-13 6-20 22-18 34 2 8 14 11 28 6l22-23M177 267l5 26c2 10 17 10 30 2 9-6 10-13 4-25"
          fill="#BB7439"
          stroke="#693D25"
          strokeWidth="5"
          strokeLinejoin="round"
        />
        <path
          d="m112 291 5-7m78 7 3-8"
          stroke="#693D25"
          strokeWidth="4"
          strokeLinecap="round"
        />
        <path
          d="M124 164c-32 17-38 63-25 93 9 23 51 32 87 24 35-8 50-35 36-69l-15-41Z"
          fill={`url(#${id}-fur)`}
          stroke="#693D25"
          strokeWidth="5"
        />
        <ellipse cx="164" cy="240" rx="35" ry="27" fill="#F7C784" />
        <motion.g
          data-part="arm-wave"
          style={{
            originX: "111px",
            originY: "198px",
            transformBox: "view-box",
          }}
          animate={
            reduce
              ? { rotate: waving ? 105 : 0 }
              : {
                  rotate: waving
                    ? [0, 128, 109, 135, 114, 0]
                    : mood === "encourage"
                      ? [0, 27, 0]
                      : 0,
                }
          }
          transition={{ duration: 1.15, ease: "easeInOut" }}
        >
          <path
            d="M113 191c-13-9-31 5-29 22 2 17 20 32 31 23 8-7 2-18-2-27"
            fill="#DA934E"
            stroke="#693D25"
            strokeWidth="5"
            strokeLinecap="round"
          />
          <path
            d="m94 228 5-5m3 9 4-6"
            stroke="#693D25"
            strokeWidth="3"
            strokeLinecap="round"
          />
        </motion.g>
        <motion.path
          d="M210 195c19-13 32-3 30 11-2 11-18 21-27 17"
          fill="#DA934E"
          stroke="#693D25"
          strokeWidth="5"
          strokeLinecap="round"
          animate={
            reduce ? undefined : { rotate: happy ? [0, -25, 0, -20, 0] : 0 }
          }
          style={{
            originX: "212px",
            originY: "198px",
            transformBox: "view-box",
          }}
          transition={{ duration: 1 }}
        />
        <path
          d="M107 164c25 10 63 17 105 2l6 22c-30 19-78 15-111-2Z"
          fill={`url(#${id}-scarf)`}
          stroke="#432297"
          strokeWidth="4"
        />
        <path
          d="m128 186-9 38 23-8 10 13 7-38"
          fill="#7644F1"
          stroke="#432297"
          strokeWidth="4"
          strokeLinejoin="round"
        />
        <path
          d="M111 181c-18-15-25-44-16-70 7-23 24-42 53-43 26-2 44 6 57 25l31 6c17 3 26 17 26 39 0 22-9 37-26 42-39 11-95 10-125 1Z"
          fill={`url(#${id}-fur)`}
          stroke="#693D25"
          strokeWidth="5"
        />
        <path
          d="M100 110c-21-5-23-22-12-29 9-7 22-1 25 9M144 72c-7-19 7-29 19-22 8 4 10 14 6 23"
          fill="#EAB077"
          stroke="#693D25"
          strokeWidth="5"
          strokeLinecap="round"
        />
        <path
          d="M93 94c0-6 7-6 11 0m47-30c4-6 10-4 11 2"
          stroke="#BA7144"
          strokeWidth="6"
          strokeLinecap="round"
        />
        <path
          d="M192 117c16-10 42-9 56 2 8 16 7 39-6 47-21 11-43 10-55 2"
          fill="#E7A869"
        />
        <ellipse cx="237" cy="125" rx="12" ry="9" fill="#693D25" />
        <ellipse cx="235" cy="122" rx="4" ry="2.5" fill="#9B6641" />
        <motion.g
          style={{
            originX: "160px",
            originY: "127px",
            transformBox: "view-box",
          }}
          animate={reduce || happy ? undefined : { scaleY: [1, 1, 0.1, 1, 1] }}
          transition={{
            duration: 4.8,
            times: [0, 0.84, 0.87, 0.9, 1],
            repeat: Infinity,
          }}
        >
          {happy ? (
            <path
              d="M148 130q10-16 19 0"
              stroke="#492C21"
              strokeWidth="6"
              strokeLinecap="round"
            />
          ) : (
            <>
              <ellipse cx="159" cy="127" rx="5.5" ry="8" fill="#492C21" />
              <circle cx="161" cy="124" r="2" fill="white" />
            </>
          )}
        </motion.g>
        <path
          d={mood === "encourage" ? "M147 109q9-9 18-3" : "M147 106q10-6 17 0"}
          stroke="#8E522D"
          strokeWidth="4"
          strokeLinecap="round"
        />
        <ellipse
          cx="151"
          cy="151"
          rx="12"
          ry="6"
          fill="#EE8C66"
          opacity="0.7"
        />
        <motion.path
          d={
            happy
              ? "M197 154q12 24 25 0Z"
              : mood === "encourage"
                ? "M201 157q9 8 18-1"
                : "M200 156q10 11 20-1"
          }
          fill={happy ? "#633421" : "none"}
          stroke="#693D25"
          strokeWidth="4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {happy && <path d="M203 162q7-4 12 1l-6 5Z" fill="#F09589" />}
        <path
          d="m121 84 4-6m4 7 4-6"
          stroke="#C38246"
          strokeWidth="4"
          strokeLinecap="round"
        />
      </motion.g>
    </svg>
  );
}
