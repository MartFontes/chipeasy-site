"use client";
import { useMotionPreference } from "./use-motion-preference";

import { motion, type HTMLMotionProps } from "framer-motion";

/** Shared tactile behavior, including keyboard focus and disabled controls. */
export function MotionButton({
  children,
  disabled,
  ...props
}: HTMLMotionProps<"button">) {
  const reduce = useMotionPreference();
  return (
    <motion.button
      tabIndex={props.tabIndex ?? 0}
      whileHover={reduce || disabled ? undefined : { scale: 1.02 }}
      whileTap={reduce || disabled ? undefined : { scale: 0.98, y: 2 }}
      transition={{ type: "spring", stiffness: 480, damping: 26 }}
      disabled={disabled}
      {...props}
    >
      {children}
    </motion.button>
  );
}
