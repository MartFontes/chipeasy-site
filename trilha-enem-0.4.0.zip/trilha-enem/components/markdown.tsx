"use client";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import remarkMath from "remark-math";
import rehypeKatex from "rehype-katex";
import { QuestionImage } from "./question-image";
export function Markdown({ children }: { children: string }) {
  return (
    <ReactMarkdown
      remarkPlugins={[remarkGfm, remarkMath]}
      rehypePlugins={[rehypeKatex]}
      components={{
        img: ({ src, alt }) =>
          typeof src === "string" &&
          src.startsWith("/questions/") &&
          !src.includes("..") ? (
            <QuestionImage
              src={src}
              alt={alt || "Figura original da questão"}
            />
          ) : (
            <span className="image-unavailable">
              Imagem disponível no documento de origem.
            </span>
          ),
        a: ({ href, children }) => (
          <a
            href={href?.startsWith("https://") ? href : undefined}
            target="_blank"
            rel="noopener noreferrer"
          >
            {children}
          </a>
        ),
      }}
    >
      {children}
    </ReactMarkdown>
  );
}
