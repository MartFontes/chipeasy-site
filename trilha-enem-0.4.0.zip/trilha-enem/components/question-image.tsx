"use client";
import { MotionButton } from "./motion-button";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Expand, Minus, Plus, X } from "lucide-react";
import upgrades from "@/data/media-map.json";
import captions from "@/data/media-captions.json";
import hidden from "@/data/media-hidden.json";

export function QuestionImage({ src, alt }: { src: string; alt: string }) {
  const [open, setOpen] = useState(false);
  const actual = (upgrades as Record<string, string>)[src] || src;
  const description =
    (captions as Record<string, string>)[src] ||
    alt ||
    "Figura original da questão";
  if ((hidden as string[]).includes(src)) return null;
  return (
    <>
      <a
        href={actual}
        target="_blank"
        rel="noopener noreferrer"
        className="question-image-link"
        aria-label={`Ampliar: ${description}`}
        onClick={(event) => {
          event.preventDefault();
          event.stopPropagation();
          setOpen(true);
        }}
      >
        <img src={actual} alt={description} loading="lazy" />
        <span className="image-zoom-hint">
          <Expand size={13} />
          {actual.endsWith(".svg")
            ? "Figura em alta definição · toque para ampliar"
            : "Toque para ampliar a figura"}
        </span>
      </a>
      {open &&
        createPortal(
          <ImageViewer
            src={actual}
            alt={description}
            onClose={() => setOpen(false)}
          />,
          document.body,
        )}
    </>
  );
}
function ImageViewer({
  src,
  alt,
  onClose,
}: {
  src: string;
  alt: string;
  onClose: () => void;
}) {
  const ref = useRef<HTMLDialogElement>(null),
    viewport = useRef<HTMLDivElement>(null);
  const [zoom, setZoom] = useState(1);
  useEffect(() => {
    ref.current?.showModal();
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = overflow;
    };
  }, []);
  return (
    <dialog
      ref={ref}
      className="image-viewer"
      aria-label="Imagem ampliada da questão"
      onCancel={onClose}
      onClose={onClose}
    >
      <header>
        <div>
          <Expand size={18} />
          <b>Veja cada detalhe</b>
        </div>
        <MotionButton
          className="icon-button"
          aria-label="Fechar imagem"
          onClick={onClose}
        >
          <X size={22} />
        </MotionButton>
      </header>
      <div className="image-viewer-toolbar">
        <div>
          <MotionButton
            aria-label="Diminuir imagem"
            onClick={() => setZoom((z) => Math.max(1, z - 0.5))}
            disabled={zoom === 1}
          >
            <Minus size={18} />
          </MotionButton>
          <output aria-label="Ampliação">{Math.round(zoom * 100)}%</output>
          <MotionButton
            aria-label="Aumentar imagem"
            onClick={() => setZoom((z) => Math.min(4, z + 0.5))}
            disabled={zoom === 4}
          >
            <Plus size={18} />
          </MotionButton>
          <MotionButton
            className="fit-image"
            onClick={() => {
              setZoom(1);
              viewport.current?.scrollTo(0, 0);
            }}
          >
            Encaixar
          </MotionButton>
        </div>
        <span>
          {src.endsWith(".svg")
            ? "Vetores do PDF original"
            : "Figura do acervo"}
        </span>
      </div>
      <div
        className="image-viewport"
        ref={viewport}
        tabIndex={0}
        aria-label="Figura; use a rolagem para explorar quando ampliada"
      >
        <img
          src={src}
          alt={alt || "Figura original da questão"}
          style={{ width: `${zoom * 100}%` }}
        />
      </div>
      <footer>
        <span>Use + para ampliar e role para ver os detalhes.</span>
        <a href={src} target="_blank" rel="noopener noreferrer">
          Abrir arquivo original ↗
        </a>
      </footer>
    </dialog>
  );
}
