"use client";
import { useMotionPreference } from "./use-motion-preference";

import { motion } from "framer-motion";

export function AnimatedProgress({
  value,
  label,
  className = "",
}: {
  value: number;
  label: string;
  className?: string;
}) {
  const reduce = useMotionPreference();
  const safe = Math.min(100, Math.max(0, Number.isFinite(value) ? value : 0));
  return (
    <div
      className={`animated-progress ${className}`}
      role="progressbar"
      aria-label={label}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-valuenow={Math.round(safe)}
    >
      <motion.span
        initial={false}
        animate={{
          scaleX: safe / 100,
          backgroundPosition:
            !reduce && safe > 0 && safe < 100
              ? ["0% 50%", "100% 50%", "0% 50%"]
              : "0% 50%",
        }}
        transition={
          reduce
            ? { duration: 0 }
            : {
                scaleX: { type: "spring", stiffness: 95, damping: 22 },
                backgroundPosition: {
                  duration: 5,
                  repeat: Infinity,
                  ease: "linear",
                },
              }
        }
      >
        <span className="progress-highlight" />
      </motion.span>
    </div>
  );
}
