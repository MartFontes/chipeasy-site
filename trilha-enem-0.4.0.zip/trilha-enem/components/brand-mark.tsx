/** The trail leads from the first step to a new discovery. */
export function BrandMark() {
  return (
    <svg viewBox="0 0 40 40" fill="none" aria-hidden="true">
      <path
        d="M11 29h10a5 5 0 0 0 0-10h-2a5 5 0 0 1 0-10h5"
        stroke="currentColor"
        strokeWidth="3.5"
        strokeLinecap="round"
      />
      <circle cx="11" cy="29" r="3.5" fill="currentColor" />
      <path
        d="m29 5 1.6 3.2 3.5.5-2.5 2.5.6 3.5-3.2-1.6-3.2 1.6.6-3.5-2.5-2.5 3.5-.5L29 5Z"
        fill="#FFDA72"
      />
    </svg>
  );
}
