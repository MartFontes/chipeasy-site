"use client";
import { MotionButton } from "./motion-button";
import { BrandMark } from "@/components/brand-mark";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  ArrowDownToLine,
  ArrowLeft,
  ArrowUpRight,
  BookOpen,
  CheckCircle2,
  FileText,
  Save,
  Search,
  Upload,
} from "lucide-react";
import type { Question } from "@/lib/types";
import { AREAS } from "@/lib/types";
import { normalized } from "@/lib/study";
import {
  mergeCatalog,
  questionSchema,
  readWorkspace,
  WORKSPACE_KEY,
} from "@/lib/review";
import { supabase } from "@/lib/supabase";
import { Markdown } from "./markdown";

export function ReviewApp({ base }: { base: Question[] }) {
  const [items, setItems] = useState(base),
    [selected, setSelected] = useState(base[0]?.id || ""),
    [draft, setDraft] = useState<Question | null>(base[0] || null),
    [query, setQuery] = useState(""),
    [status, setStatus] = useState("all"),
    [message, setMessage] = useState(""),
    [errors, setErrors] = useState<string[]>([]),
    [busy, setBusy] = useState(false),
    [canEdit, setCanEdit] = useState(!supabase),
    [cloud, setCloud] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  useEffect(() => {
    if (!supabase) {
      const merged = mergeCatalog(base, readWorkspace().questions).questions;
      setItems(merged);
      setSelected(merged[0]?.id || "");
      setDraft(merged[0] || null);
      return;
    }
    let cancelled = false;
    (async () => {
      const { data } = await supabase!.auth.getUser();
      if (!data.user) return;
      const { data: profile } = await supabase!
        .from("profiles")
        .select("role")
        .eq("id", data.user.id)
        .single();
      if (cancelled || profile?.role !== "admin") return;
      setCanEdit(true);
      setCloud(true);
      const questions: Question[] = [];
      for (let offset = 0; offset < 100000; offset += 500) {
        const { data: rows, error } = await supabase!
          .from("questions")
          .select("data")
          .order("id")
          .range(offset, offset + 499);
        if (cancelled) return;
        if (error) {
          setMessage("Não foi possível carregar o acervo de revisão.");
          return;
        }
        questions.push(
          ...(rows || []).map((r) => questionSchema.parse(r.data)),
        );
        if (!rows || rows.length < 500) break;
      }
      setItems(questions);
      setSelected(questions[0]?.id || "");
      setDraft(questions[0] || null);
    })().catch(() => {
      if (!cancelled) setMessage("A área de revisão não pôde ser carregada.");
    });
    return () => {
      cancelled = true;
    };
  }, [base]);
  const filtered = items.filter(
    (q) =>
      (status === "all" || q.status === status) &&
      (!query ||
        normalized(`${q.id} ${q.context} ${q.prompt}`).includes(
          normalized(query),
        )),
  );
  function choose(q: Question) {
    setSelected(q.id);
    setDraft(structuredClone(q));
    setErrors([]);
  }
  async function persist(batch: Question[]) {
    if (!canEdit)
      throw Error("Entre com uma conta administradora para editar o acervo.");
    if (cloud && supabase) {
      for (let i = 0; i < batch.length; i += 100) {
        const { error } = await supabase.from("questions").upsert(
          batch.slice(i, i + 100).map((q) => ({ id: q.id, data: q })),
          { onConflict: "id" },
        );
        if (error)
          throw Error(
            "A publicação na biblioteca não foi concluída. Os lotes já salvos serão preservados.",
          );
      }
    } else {
      const questions = mergeCatalog(
        readWorkspace().questions,
        batch,
      ).questions;
      localStorage.setItem(
        WORKSPACE_KEY,
        JSON.stringify({
          version: 1,
          questions,
          updatedAt: new Date().toISOString(),
        }),
      );
      window.dispatchEvent(new Event("trilha-workspace"));
    }
    setItems((current) => mergeCatalog(current, batch).questions);
  }
  async function save(publish = false) {
    if (!draft) return;
    setMessage("");
    setErrors([]);
    const parsed = questionSchema.safeParse({
      ...draft,
      status: publish ? "published" : draft.status,
    });
    if (!parsed.success) {
      setErrors(parsed.error.issues.map((e) => e.message));
      return;
    }
    setBusy(true);
    try {
      await persist([parsed.data]);
      setDraft(parsed.data);
      setMessage(
        cloud
          ? "Questão salva na biblioteca."
          : "Revisão salva neste dispositivo.",
      );
    } catch (e) {
      setErrors([e instanceof Error ? e.message : "Não foi possível salvar."]);
    } finally {
      setBusy(false);
    }
  }
  async function importFile(file: File | undefined) {
    if (!file) return;
    setErrors([]);
    setMessage("");
    setBusy(true);
    try {
      if (file.size > 12 * 1024 * 1024)
        throw Error("O arquivo deve ter até 12 MB.");
      const value = JSON.parse(await file.text()),
        raw = Array.isArray(value) ? value : value.questions;
      if (!Array.isArray(raw) || raw.length > 3000)
        throw Error("O arquivo deve conter uma lista de até 3.000 questões.");
      const parsed = raw.map((q) =>
        questionSchema.parse({ ...q, status: "imported" }),
      );
      const byId = new Map(items.map((q) => [q.id, q])),
        fingerprints = new Set(items.map((q) => q.fingerprint)),
        newItems: Question[] = [],
        conflicts: string[] = [];
      let duplicates = 0;
      for (const q of parsed) {
        const old = byId.get(q.id);
        if (old) {
          if (old.fingerprint === q.fingerprint) duplicates++;
          else conflicts.push(q.id);
          continue;
        }
        if (fingerprints.has(q.fingerprint)) {
          duplicates++;
          continue;
        }
        newItems.push(q);
        byId.set(q.id, q);
        fingerprints.add(q.fingerprint);
      }
      await persist(newItems);
      setMessage(
        `${newItems.length} questões importadas para revisão; ${duplicates} repetidas ignoradas.${conflicts.length ? ` ${conflicts.length} IDs com conteúdo diferente foram preservados para conferência.` : ""}`,
      );
      if (conflicts.length)
        setErrors(
          conflicts.slice(0, 15).map((id) => `Conferir conflito: ${id}`),
        );
      if (newItems[0]) choose(newItems[0]);
    } catch (e) {
      setErrors([e instanceof Error ? e.message : "Arquivo inválido."]);
    } finally {
      setBusy(false);
      if (input.current) input.current.value = "";
    }
  }
  function exportCatalog() {
    const blob = new Blob([JSON.stringify({ questions: items }, null, 2)], {
        type: "application/json",
      }),
      url = URL.createObjectURL(blob),
      a = document.createElement("a");
    a.href = url;
    a.download = "trilha-enem-acervo-revisado.json";
    a.click();
    URL.revokeObjectURL(url);
  }
  return (
    <div className="document-page">
      <header className="document-header">
        <Link className="brand" href="/">
          <span className="brand-icon">
            <BrandMark />
          </span>
          <span>
            trilha<span className="brand-enem">ENEM</span>
          </span>
        </Link>
        <Link className="button secondary" href="/">
          <ArrowLeft size={15} />
          Voltar aos estudos
        </Link>
      </header>
      <div className="eyebrow muted">CONTEÚDO CONFERIDO, ESTUDO MELHOR</div>
      <h1>Revisão do acervo</h1>
      <p className="help-text">
        Confira o texto, as imagens e o gabarito antes da publicação.{" "}
        {cloud
          ? "Sua conta administra a biblioteca compartilhada."
          : supabase
            ? "Entre com uma conta administradora em Meu perfil para publicar alterações."
            : "Nesta edição, as alterações ficam neste navegador e podem ser exportadas. A biblioteca compartilhada usa uma conta administradora."}
      </p>
      <div className="review-toolbar">
        <MotionButton
          className="button primary"
          disabled={!canEdit || busy}
          onClick={() => input.current?.click()}
        >
          <Upload size={16} />
          Importar lote JSON
        </MotionButton>
        <MotionButton className="button secondary" onClick={exportCatalog}>
          <ArrowDownToLine size={16} />
          Exportar acervo
        </MotionButton>
        <input
          type="file"
          ref={input}
          accept=".json,application/json"
          hidden
          onChange={(e) => void importFile(e.target.files?.[0])}
        />
        <p>
          {items.length} questões ·{" "}
          {items.filter((q) => q.status === "published").length} publicadas
        </p>
      </div>
      {message && (
        <div className="info-strip" role="status">
          <CheckCircle2 size={18} />
          <p>{message}</p>
        </div>
      )}
      {errors.length > 0 && (
        <div className="review-errors" role="alert">
          {errors.map((s, i) => (
            <div key={i}>{s}</div>
          ))}
        </div>
      )}
      <div className="filter-bar">
        <label className="search-field">
          <Search size={17} />
          <input
            placeholder="Buscar no acervo de revisão…"
            aria-label="Buscar revisão"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </label>
        <label className="select-field">
          <select
            aria-label="Estado da revisão"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <option value="all">Todas as situações</option>
            <option value="imported">A revisar</option>
            <option value="reviewed">Conferidas</option>
            <option value="published">Publicadas</option>
          </select>
        </label>
      </div>
      <div className="review-layout">
        <aside className="review-list" aria-label="Questões para revisão">
          {filtered.map((q) => (
            <MotionButton
              key={q.id}
              className={q.id === selected ? "active" : ""}
              onClick={() => choose(q)}
            >
              <b>
                ENEM {q.year} · Questão {q.number}
                {q.language ? ` · ${q.language}` : ""}
              </b>
              <small>
                {AREAS[q.area].label} ·{" "}
                {q.status === "published"
                  ? "Publicada"
                  : q.status === "reviewed"
                    ? "Gabarito conferido"
                    : "A revisar"}
              </small>
            </MotionButton>
          ))}
        </aside>
        {draft ? (
          <section className="review-editor">
            <h2>
              ENEM {draft.year} · Questão {draft.number}
            </h2>
            <div className="review-actions">
              <a
                className="button secondary"
                href={`/sources/${draft.source.originalUrl.split("/").pop()}#page=${draft.source.page || 1}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <FileText size={15} />
                PDF do acervo
                <ArrowUpRight size={13} />
              </a>
              <a
                className="button secondary"
                href={draft.source.originalUrl}
                target="_blank"
                rel="noopener noreferrer"
              >
                Origem no Inep
                <ArrowUpRight size={13} />
              </a>
            </div>
            <div className="question-context">
              <Markdown>{draft.context}</Markdown>
            </div>
            <fieldset
              disabled={!canEdit || busy}
              className="review-fields"
              style={{ border: 0, padding: 0, margin: 0 }}
            >
              <label className="review-label">
                Área
                <select
                  value={draft.area}
                  onChange={(e) =>
                    setDraft((d) =>
                      d
                        ? { ...d, area: e.target.value as Question["area"] }
                        : d,
                    )
                  }
                >
                  {Object.entries(AREAS).map(([v, a]) => (
                    <option value={v} key={v}>
                      {a.label}
                    </option>
                  ))}
                </select>
              </label>
              <label className="review-label">
                Assunto
                <input
                  value={draft.subject || ""}
                  onChange={(e) =>
                    setDraft((d) =>
                      d ? { ...d, subject: e.target.value || null } : d,
                    )
                  }
                  placeholder="Ex.: Média ponderada"
                />
              </label>
              <label className="review-label">
                Enunciado / contexto
                <textarea
                  value={draft.context}
                  onChange={(e) =>
                    setDraft((d) => (d ? { ...d, context: e.target.value } : d))
                  }
                />
              </label>
              <label className="review-label">
                Comando da questão
                <textarea
                  value={draft.prompt}
                  onChange={(e) =>
                    setDraft((d) => (d ? { ...d, prompt: e.target.value } : d))
                  }
                />
              </label>
              {draft.alternatives.map((a, i) => (
                <label className="review-label" key={a.letter}>
                  Alternativa {a.letter}
                  <textarea
                    value={a.text}
                    onChange={(e) =>
                      setDraft((d) =>
                        d
                          ? {
                              ...d,
                              alternatives: d.alternatives.map((x, j) =>
                                j === i ? { ...x, text: e.target.value } : x,
                              ),
                            }
                          : d,
                      )
                    }
                  />
                </label>
              ))}
              <label className="review-label">
                Gabarito
                <select
                  value={
                    draft.annulled ? "annulled" : draft.answer || "pending"
                  }
                  onChange={(e) =>
                    setDraft((d) =>
                      d
                        ? {
                            ...d,
                            answer: ["A", "B", "C", "D", "E"].includes(
                              e.target.value,
                            )
                              ? (e.target.value as Question["answer"])
                              : null,
                            annulled: e.target.value === "annulled",
                          }
                        : d,
                    )
                  }
                >
                  <option value="pending">A conferir</option>
                  {["A", "B", "C", "D", "E"].map((a) => (
                    <option key={a}>{a}</option>
                  ))}
                  <option value="annulled">Anulada</option>
                </select>
              </label>
              <label className="review-check">
                <input
                  type="checkbox"
                  checked={draft.answerVerified}
                  onChange={(e) =>
                    setDraft((d) =>
                      d ? { ...d, answerVerified: e.target.checked } : d,
                    )
                  }
                />
                Conferi o gabarito no documento de origem
              </label>
              <label className="review-label">
                Resolução comentada
                <textarea
                  value={draft.explanation || ""}
                  onChange={(e) =>
                    setDraft((d) =>
                      d ? { ...d, explanation: e.target.value || null } : d,
                    )
                  }
                  placeholder="Registre o raciocínio e a justificativa da resposta…"
                />
              </label>
              <label className="review-label">
                Notas de revisão
                <textarea
                  value={draft.reviewNote}
                  onChange={(e) =>
                    setDraft((d) =>
                      d ? { ...d, reviewNote: e.target.value } : d,
                    )
                  }
                />
              </label>
            </fieldset>
            <div className="review-actions">
              <MotionButton
                className="button secondary"
                disabled={!canEdit || busy}
                onClick={() => void save()}
              >
                <Save size={16} />
                Salvar revisão
              </MotionButton>
              <MotionButton
                className="button primary"
                disabled={!canEdit || busy}
                onClick={() => void save(true)}
              >
                <CheckCircle2 size={16} />
                Aprovar e publicar
              </MotionButton>
            </div>
          </section>
        ) : (
          <div className="empty-state">
            <BookOpen size={25} />
            <p>Selecione uma questão ou importe o primeiro lote.</p>
          </div>
        )}
      </div>
    </div>
  );
}
