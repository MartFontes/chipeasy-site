"use client";
import { useMotionPreference } from "./use-motion-preference";

import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Check, LockKeyhole, Sparkles, X, Zap } from "lucide-react";
import { AnimatedProgress } from "./animated-progress";
import { MotionButton } from "./motion-button";
import { RewardCanvas, useExperience } from "./experience-provider";

function Chest({ open = false }: { open?: boolean }) {
  const reduce = useMotionPreference();
  return (
    <svg
      viewBox="0 0 160 136"
      fill="none"
      aria-hidden="true"
      className="chest-art"
      data-open={open}
    >
      <ellipse cx="80" cy="120" rx="57" ry="9" fill="#4B290B" opacity="0.12" />
      {open && (
        <motion.path
          d="m80 16 8 35 25-26-13 35 40-7-34 24 29 22-43-9-12 31-11-31-40 8 28-23-32-24 39 8-12-35 23 24Z"
          fill="#FFD52E"
          initial={{ opacity: 0, scale: 0.4 }}
          animate={{ opacity: 0.6, scale: 1 }}
          style={{ transformOrigin: "80px 70px", transformBox: "view-box" }}
          transition={{ duration: reduce ? 0 : 0.4 }}
        />
      )}
      <path
        d="M26 63h108v45c0 9-10 13-20 13H46c-10 0-20-4-20-13Z"
        fill="#F7AD17"
        stroke="#9E5810"
        strokeWidth="4"
      />
      <path
        d="M37 73h86v31H37Z"
        fill="#BF6B15"
        stroke="#9E5810"
        strokeWidth="3"
      />
      <motion.g
        animate={{ rotate: open ? -27 : 0, y: open ? -16 : 0 }}
        style={{ originX: "28px", originY: "63px", transformBox: "view-box" }}
        transition={
          reduce
            ? { duration: 0 }
            : { type: "spring", stiffness: 150, damping: 14 }
        }
      >
        <path
          d="M26 64V48c0-20 17-31 35-31h38c18 0 35 11 35 31v16Z"
          fill="#FFD52E"
          stroke="#9E5810"
          strokeWidth="4"
        />
        <path
          d="M43 56V46c0-11 8-17 18-17h38c10 0 18 6 18 17v10Z"
          fill="#E99313"
          stroke="#B66912"
          strokeWidth="3"
        />
        <path d="M55 22v39m50-39v39" stroke="#FFE786" strokeWidth="10" />
        <path d="M26 61h108" stroke="#9E5810" strokeWidth="5" />
      </motion.g>
      <path d="M55 71v43m50-43v43" stroke="#FFDC56" strokeWidth="10" />
      <rect
        x="65"
        y="57"
        width="30"
        height="30"
        rx="7"
        fill="#FFE477"
        stroke="#9E5810"
        strokeWidth="4"
      />
      <path d="m80 63 3 6 7 1-5 5 1 6-6-3-6 3 1-6-5-5 7-1Z" fill="#B56913" />
      <path
        d="m35 40 7-7m75 59h5"
        stroke="#FFF1AD"
        strokeWidth="4"
        strokeLinecap="round"
      />
    </svg>
  );
}

export function DailyChest({ count }: { count: number }) {
  const [open, setOpen] = useState(false);
  const ready = count >= 5;
  const { emit, feedback } = useExperience();
  return (
    <>
      <section className={`daily-chest ${ready ? "ready" : ""}`}>
        <div className="chest-card-heading">
          <Sparkles size={19} />
          <span>UM BAÚ POR DIA</span>
        </div>
        <MotionButton
          className="chest-button"
          aria-label={
            ready
              ? "Abrir baú diário, bônus recebido"
              : "Ver desafio do baú diário"
          }
          onClick={() => {
            setOpen(true);
            if (ready) emit({ kind: "chest", xp: 0 });
          }}
        >
          <Chest />
          <span className="chest-status">
            {ready ? <Check size={16} /> : <LockKeyhole size={15} />}
            {ready
              ? "Bônus desbloqueado!"
              : `${Math.min(count, 5)}/5 questões hoje`}
          </span>
        </MotionButton>
        <h2>{ready ? "Esse tesouro é seu." : "Seu próximo tesouro."}</h2>
        <p>
          {ready
            ? "Você concluiu o desafio diário. +30 XP já estão na sua conta!"
            : "Explore 5 questões diferentes hoje e conquiste +30 XP de bônus."}
        </p>
        <AnimatedProgress
          value={count * 20}
          label="Desafio do baú diário"
          className="gold"
        />
      </section>
      {open && (
        <ChestDialog
          ready={ready}
          count={count}
          onClose={() => setOpen(false)}
          event={ready && feedback?.kind === "chest" ? feedback : null}
        />
      )}
    </>
  );
}

function ChestDialog({
  ready,
  count,
  onClose,
  event,
}: {
  ready: boolean;
  count: number;
  onClose: () => void;
  event: Parameters<typeof RewardCanvas>[0]["event"];
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const reduce = useMotionPreference();
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const element = dialog.current;
    const overflow = document.body.style.overflow;
    element?.showModal();
    document.body.style.overflow = "hidden";
    return () => {
      element?.close();
      document.body.style.overflow = overflow;
      if (previous?.isConnected) previous.focus();
    };
  }, []);
  return (
    <dialog
      ref={dialog}
      className="reward-dialog"
      aria-labelledby="chest-dialog-title"
      onCancel={(e) => {
        e.preventDefault();
        onClose();
      }}
    >
      <RewardCanvas event={event} />
      <MotionButton
        className="icon-button reward-dialog-close"
        aria-label="Fechar baú"
        onClick={onClose}
        autoFocus
      >
        <X size={20} />
      </MotionButton>
      <motion.div
        initial={reduce ? false : { opacity: 0, y: 15, scale: 0.94 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
      >
        <div className="dialog-chest-art">
          <Chest open={ready} />
        </div>
        <div className="eyebrow">
          {ready ? "DESAFIO DIÁRIO CONCLUÍDO" : "FALTA POUCO PARA ABRIR"}
        </div>
        <h2 id="chest-dialog-title">
          {ready ? "Tesouro conquistado!" : "Uma descoberta de cada vez."}
        </h2>
        <p>
          {ready
            ? "Você explorou cinco questões diferentes hoje. O bônus já está incluído no seu total de XP."
            : `Você já explorou ${count} de 5 questões hoje. Continue sua jornada para conquistar o bônus diário.`}
        </p>
        <div className="chest-bonus">
          <Zap size={25} fill="currentColor" />
          <strong>+30 XP</strong>
          <span>{ready ? "Bônus recebido" : "Ao concluir o desafio"}</span>
        </div>
        <MotionButton className="button primary" onClick={onClose}>
          Continuar estudando
        </MotionButton>
      </motion.div>
    </dialog>
  );
}
