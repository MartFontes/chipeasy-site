"use client";
import { useMotionPreference } from "./use-motion-preference";

import { useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import {
  ArrowRight,
  BookOpen,
  Check,
  ChevronDown,
  Compass,
  Crown,
  Flame,
  Footprints,
  Leaf,
  LockKeyhole,
  Mountain,
  Play,
  Sparkles,
  Star,
  Target,
  Trophy,
  Zap,
} from "lucide-react";
import type { Area, Progress, Question } from "@/lib/types";
import { AREAS } from "@/lib/types";
import { dayKey } from "@/lib/study";
import {
  journeyLessons,
  journeyStats,
  WORLDS,
  XP_PER_LEVEL,
  type Lesson,
} from "@/lib/journey";
import { MotionButton } from "./motion-button";
import { AnimatedProgress } from "./animated-progress";
import { Capybara } from "./capybara";
import { DailyChest } from "./reward-chest";

const worldIcons = {
  book: BookOpen,
  compass: Compass,
  leaf: Leaf,
  mountain: Mountain,
};
const badgeIcons: Record<string, typeof Flame> = {
  footprint: Footprints,
  sparkles: Sparkles,
  flame: Flame,
  crown: Crown,
  compass: Compass,
  target: Target,
};
const offsets = [0, 52, 82, 52, 0, -42];

export function JourneyPanel({
  progress,
  questions,
  language,
  area,
  onArea,
  onLanguage,
  onStart,
  onPractice,
}: {
  progress: Progress;
  questions: Question[];
  language: string;
  area: Area;
  onArea: (area: Area) => void;
  onLanguage: (language: string) => void;
  onStart: (lesson: Lesson) => void;
  onPractice: () => void;
}) {
  const reduce = useMotionPreference();
  const [expanded, setExpanded] = useState(false);
  const [greeting, setGreeting] = useState(0);
  const [today, setToday] = useState(() => dayKey(new Date()));
  const waveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    const update = () => setToday(dayKey(new Date()));
    const timer = setInterval(update, 60000);
    window.addEventListener("focus", update);
    return () => {
      clearInterval(timer);
      window.removeEventListener("focus", update);
      if (waveTimer.current) clearTimeout(waveTimer.current);
    };
  }, []);
  const stats = useMemo(
    () => journeyStats(progress, questions),
    [progress, questions, today],
  );
  const lessons = useMemo(
    () => journeyLessons(progress, questions, language),
    [progress, questions, language, today],
  );
  const world = WORLDS[area];
  const Icon = worldIcons[world.icon as keyof typeof worldIcons];
  const own = lessons.filter((l) => l.area === area);
  const complete = own.filter((l) => l.completed).length;
  const next = own.find((l) => !l.completed && l.unlocked);
  const visible = expanded
    ? own
    : own.slice(
        Math.max(0, (next?.number || 1) - 3),
        Math.max(6, (next?.number || 1) + 3),
      );
  const weekdays = ["dom", "seg", "ter", "qua", "qui", "sex", "sáb"];
  const missions = [
    {
      title: "Mantenha a chama acesa",
      subtitle: "Responda uma questão hoje.",
      count: stats.todayCount,
      target: 1,
      Icon: Flame,
    },
    {
      title: "Faça seu desafio diário",
      subtitle: "5 questões diferentes · +30 XP",
      count: stats.todayCount,
      target: 5,
      Icon: Zap,
    },
    {
      title: "Treine seu olhar",
      subtitle: "Acerte 3 questões hoje.",
      count: stats.todayCorrect,
      target: 3,
      Icon: Target,
    },
  ];
  const entrance = reduce
    ? {}
    : {
        initial: { opacity: 1, y: 12 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.38 },
      };

  return (
    <motion.div className="journey-page" {...entrance}>
      <section className="journey-hero">
        <div className="journey-hero-copy">
          <div className="journey-eyebrow">
            <span className="hero-live-dot" /> SEU FUTURO TEM UM CAMINHO
          </div>
          <h1>
            Cada passo conta.
            <br />
            <em>O próximo é seu.</em>
          </h1>
          <p>
            {progress.name ? `${progress.name}, vamos` : "Vamos"} transformar
            pequenas descobertas em grandes conquistas? Sua aventura até o ENEM
            começa aqui.
          </p>
          <MotionButton
            className="button journey-cta"
            disabled={!own.length}
            onClick={() => {
              const lesson = next || own[0];
              if (lesson) onStart(lesson);
            }}
          >
            <Play size={18} fill="currentColor" />
            {own.some((lesson) => lesson.answered > 0)
              ? next
                ? "Continuar minha jornada"
                : "Revisitar esta jornada"
              : "Começar minha jornada"}
            <ArrowRight size={19} />
          </MotionButton>
          <span className="hero-footnote">
            <Check size={15} /> Lições curtas. Grandes descobertas.
          </span>
        </div>
        <div className="journey-art">
          <div className="hero-art-grid" aria-hidden="true" />
          <motion.span
            className="hero-orbit-star orbit-one"
            aria-hidden="true"
            animate={reduce ? undefined : { y: [0, -8, 0], rotate: [0, 10, 0] }}
            transition={{ duration: 4.5, repeat: Infinity }}
          >
            <Sparkles size={31} />
          </motion.span>
          <motion.span
            className="hero-orbit-star orbit-two"
            aria-hidden="true"
            animate={reduce ? undefined : { y: [0, 8, 0], rotate: [0, -10, 0] }}
            transition={{ duration: 5, repeat: Infinity }}
          >
            <Star size={22} fill="currentColor" />
          </motion.span>
          <div className="hero-speech" aria-live="polite">
            {greeting
              ? "Bora! Eu acredito em você."
              : "Seu próximo acerto está logo ali!"}
          </div>
          <div className="hero-platform" aria-hidden="true">
            <span />
            <span />
            <span />
          </div>
          <MotionButton
            className="mascot-greeting"
            aria-label="Dar um oi à Capi"
            onClick={() => {
              if (waveTimer.current) clearTimeout(waveTimer.current);
              setGreeting((n) => n + 1);
              waveTimer.current = setTimeout(() => setGreeting(0), 1800);
            }}
          >
            <Capybara
              mood={greeting ? "wave" : "idle"}
              reactionKey={greeting}
            />
          </MotionButton>
          <motion.div
            className="hero-achievement"
            aria-hidden="true"
            animate={reduce ? undefined : { y: [0, -5, 0] }}
            transition={{ duration: 4, repeat: Infinity }}
          >
            <span>
              <Zap size={23} fill="currentColor" />
            </span>
            <div>
              PEQUENAS VITÓRIAS<b>Grandes possibilidades.</b>
            </div>
          </motion.div>
          <span className="mascot-name">CAPI, SUA PARCEIRA DE JORNADA</span>
        </div>
      </section>

      <section
        className="journey-scoreboard"
        aria-label="Seu avanço na jornada"
      >
        <motion.div className="journey-score streak-score" {...entrance}>
          <span className="score-icon flame">
            <Flame size={29} fill="currentColor" />
          </span>
          <div>
            <strong data-testid="streak-count">{stats.streak.current}</strong>
            <span>
              {stats.streak.current === 1
                ? "dia de sequência"
                : "dias de sequência"}
            </span>
          </div>
          <small>
            {stats.streak.studiedToday
              ? "Chama acesa hoje!"
              : stats.streak.current
                ? "Estude hoje para continuar."
                : "Sua sequência começa hoje."}
          </small>
          <Flame className="score-watermark" size={70} aria-hidden="true" />
        </motion.div>
        <motion.div className="journey-score xp-score" {...entrance}>
          <span className="score-icon energy">
            <Zap size={29} fill="currentColor" />
          </span>
          <div>
            <strong data-testid="xp-total">
              {stats.xp.toLocaleString("pt-BR")}
            </strong>
            <span>XP conquistados</span>
          </div>
          <small>
            <span className="xp-today-dot" /> +{stats.todayXp} XP hoje
          </small>
          <Sparkles className="score-watermark" size={72} aria-hidden="true" />
        </motion.div>
        <motion.div className="journey-score level-score" {...entrance}>
          <span className="level-emblem">
            <Crown size={15} />
            <b>{stats.level}</b>
          </span>
          <div>
            <strong>Nível {stats.level}</strong>
            <span>{stats.levelName}</span>
          </div>
          <AnimatedProgress
            className="level-progress"
            value={(stats.levelXp / XP_PER_LEVEL) * 100}
            label="Avanço para o próximo nível"
          />
          <small>Faltam {stats.toNextLevel} XP para o próximo nível.</small>
        </motion.div>
      </section>

      <div className="journey-layout">
        <section className="journey-route">
          <div className="section-heading">
            <div>
              <div className="eyebrow muted">
                QUATRO MUNDOS. UM GRANDE OBJETIVO.
              </div>
              <h2>
                Seu mapa de descobertas<span className="heading-dot">.</span>
              </h2>
            </div>
            <label className="journey-language">
              <span>Língua estrangeira</span>
              <select
                aria-label="Idioma da jornada"
                value={language}
                onChange={(e) => onLanguage(e.target.value)}
              >
                <option value="ingles">Inglês</option>
                <option value="espanhol">Espanhol</option>
              </select>
            </label>
          </div>
          <div
            className="world-picker"
            role="group"
            aria-label="Caminhos de estudo"
          >
            {Object.entries(WORLDS).map(([key, w]) => {
              const W = worldIcons[w.icon as keyof typeof worldIcons];
              return (
                <MotionButton
                  key={key}
                  className={area === key ? "selected" : ""}
                  aria-pressed={area === key}
                  onClick={() => {
                    onArea(key as Area);
                    setExpanded(false);
                  }}
                  style={{ "--world": w.color } as React.CSSProperties}
                >
                  <span className="world-picker-icon">
                    <W size={22} />
                  </span>
                  <span>{AREAS[key as Area].label}</span>
                </MotionButton>
              );
            })}
          </div>
          <div
            className="world-map"
            style={{ "--world": world.color } as React.CSSProperties}
          >
            <div className="world-card">
              <span className="world-icon">
                <Icon size={25} />
              </span>
              <div>
                <span className="world-chapter">
                  SEU CAMINHO EM {AREAS[area].label.toUpperCase()}
                </span>
                <h3>{world.title}</h3>
                <p>{world.subtitle}</p>
              </div>
              <span className="world-count">
                {complete}/{own.length}
                <small>lições concluídas</small>
              </span>
            </div>
            {own.length ? (
              <>
                <div
                  className="lesson-path"
                  role="group"
                  aria-label={`Etapas de ${AREAS[area].label}`}
                >
                  {visible.map((lesson, index) => {
                    const current = next?.id === lesson.id;
                    const delta = offsets[(index + 1) % 6] - offsets[index % 6];
                    const path = `M43 75 C43 108 ${43 + delta} 100 ${43 + delta} 145`;
                    return (
                      <div
                        className={`lesson-stop ${lesson.completed ? "complete" : current ? "current" : "locked"}`}
                        key={lesson.id}
                        style={
                          {
                            "--shift": `${offsets[index % 6]}px`,
                          } as React.CSSProperties
                        }
                      >
                        <div className="lesson-node-wrap">
                          {index < visible.length - 1 && (
                            <svg
                              className="lesson-connector"
                              viewBox="0 0 200 150"
                              aria-hidden="true"
                            >
                              <path d={path} />
                              {(lesson.completed || current) && (
                                <motion.path
                                  className={`path-energy ${current ? "path-current" : ""}`}
                                  d={path}
                                  initial={false}
                                  animate={
                                    reduce
                                      ? undefined
                                      : { strokeDashoffset: [0, -32] }
                                  }
                                  transition={{
                                    duration: 3,
                                    repeat: Infinity,
                                    ease: "linear",
                                  }}
                                />
                              )}
                            </svg>
                          )}
                          {current && (
                            <span className="lesson-callout">
                              {lesson.answered
                                ? "CONTINUE AQUI"
                                : "SEU PRÓXIMO PASSO"}
                              <ChevronDown size={12} />
                            </span>
                          )}
                          {current && (
                            <motion.span
                              className="node-halo"
                              aria-hidden="true"
                              animate={
                                reduce
                                  ? undefined
                                  : {
                                      scale: [1, 1.13, 1],
                                      opacity: [0.55, 0.2, 0.55],
                                    }
                              }
                              transition={{ duration: 2.6, repeat: Infinity }}
                            />
                          )}
                          <MotionButton
                            className="lesson-node"
                            aria-label={`Lição ${lesson.number} de ${AREAS[area].label}${lesson.completed ? ", concluída" : lesson.unlocked ? ", disponível" : ", bloqueada"}`}
                            disabled={!lesson.unlocked}
                            onClick={() => onStart(lesson)}
                          >
                            {lesson.completed ? (
                              <Check size={31} strokeWidth={3.5} />
                            ) : current ? (
                              <Star size={31} fill="currentColor" />
                            ) : (
                              <LockKeyhole size={24} />
                            )}
                          </MotionButton>
                          <div
                            className="lesson-stars"
                            role="img"
                            aria-label={`${lesson.stars} de 3 estrelas`}
                          >
                            {[1, 2, 3].map((n) => (
                              <Star
                                key={n}
                                size={15}
                                fill={
                                  lesson.stars >= n ? "currentColor" : "none"
                                }
                                className={lesson.stars >= n ? "earned" : ""}
                              />
                            ))}
                          </div>
                        </div>
                        <div className="lesson-description">
                          <span>LIÇÃO {lesson.number}</span>
                          <h4>
                            {lesson.number % 4 === 0
                              ? "Mais um topo alcançado"
                              : lesson.number % 4 === 1
                                ? "Um novo começo"
                                : lesson.number % 4 === 2
                                  ? "Conectando ideias"
                                  : "Expandindo horizontes"}
                          </h4>
                          <p>
                            {lesson.completed
                              ? `${lesson.correct}/${lesson.questionIds.length} acertos conquistados`
                              : lesson.answered
                                ? `${lesson.answered} de ${lesson.questionIds.length} questões exploradas`
                                : `${lesson.questionIds.length} questões · até ${lesson.questionIds.length * 20} XP`}
                          </p>
                          {current && (
                            <AnimatedProgress
                              className="lesson-mini-progress"
                              value={
                                (lesson.answered / lesson.questionIds.length) *
                                100
                              }
                              label={`Avanço na lição ${lesson.number}`}
                            />
                          )}
                        </div>
                      </div>
                    );
                  })}
                  <div className="path-destination">
                    <span>
                      <Trophy size={28} />
                    </span>
                    <b>
                      {complete === own.length
                        ? "Um mundo inteiro de descobertas!"
                        : "Seu futuro está em construção."}
                    </b>
                    <p>
                      {complete === own.length
                        ? "Você explorou todo este caminho!"
                        : "Um pequeno passo hoje faz toda a diferença."}
                    </p>
                  </div>
                </div>
                {!expanded && visible.length < own.length && (
                  <MotionButton
                    className="button secondary expand-path"
                    onClick={() => setExpanded(true)}
                  >
                    Ver todas as {own.length} etapas
                    <ChevronDown size={16} />
                  </MotionButton>
                )}
              </>
            ) : (
              <div className="empty-state">
                <BookOpen size={26} />
                <p>
                  As lições deste caminho aguardam a publicação de questões.
                </p>
              </div>
            )}
          </div>
          <div className="journey-rules">
            <Sparkles size={18} />
            <p>
              Ganhe 10 XP ao explorar uma questão nova e mais 10 no primeiro
              acerto. Repetir a mesma resposta não acumula XP. Conclua a lição
              para liberar a próxima etapa e revise para conquistar mais
              estrelas.
            </p>
          </div>
        </section>

        <aside className="journey-aside">
          <section className="streak-card">
            <div className="journey-card-heading">
              <Flame size={21} fill="currentColor" />
              <h2>Sua chama diária</h2>
              <span className="card-mini-tag">CONSTÂNCIA</span>
            </div>
            <div className="streak-headline">
              <strong>{stats.streak.current}</strong>
              <span>
                {stats.streak.current === 1 ? "dia" : "dias"}
                <br />
                {stats.streak.current === 1 ? "consecutivo" : "consecutivos"}
              </span>
              <motion.div
                className="streak-big-flame"
                animate={
                  !reduce && stats.streak.studiedToday
                    ? { scale: [1, 1.08, 1], rotate: [0, -4, 0] }
                    : undefined
                }
                transition={{ duration: 2.2, repeat: Infinity }}
              >
                <Flame
                  size={59}
                  fill="currentColor"
                  className={stats.streak.studiedToday ? "lit" : ""}
                />
              </motion.div>
            </div>
            <div className="streak-calendar">
              {stats.streak.week.map((d) => (
                <div key={d.key}>
                  <span>
                    {weekdays[new Date(d.key + "T12:00:00Z").getUTCDay()]}
                  </span>
                  <b
                    role="img"
                    className={`${d.active ? "active" : ""} ${d.today ? "today" : ""}`}
                    aria-label={`${d.key}${d.today ? ", hoje" : ""}: ${d.active ? "estudou" : "sem estudo"}`}
                  >
                    {d.active ? (
                      <Flame size={17} fill="currentColor" />
                    ) : d.today ? (
                      <span />
                    ) : (
                      "·"
                    )}
                  </b>
                </div>
              ))}
            </div>
            <p>Uma questão hoje já mantém sua chama acesa. Vamos nessa?</p>
            <div className="streak-record">
              <Trophy size={15} />
              Seu recorde: <b>{stats.streak.best} dias</b>
            </div>
          </section>
          <DailyChest count={stats.todayCount} />
          <section className="missions-card">
            <div className="journey-card-heading">
              <Target size={21} />
              <h2>Missões de hoje</h2>
            </div>
            {missions.map((m) => (
              <div
                className={`daily-mission ${m.count >= m.target ? "done" : ""}`}
                key={m.title}
              >
                <span className="mission-icon">
                  {m.count >= m.target ? (
                    <Check size={19} />
                  ) : (
                    <m.Icon size={19} />
                  )}
                </span>
                <div>
                  <h3>{m.title}</h3>
                  <p>{m.subtitle}</p>
                  <AnimatedProgress
                    value={(m.count / m.target) * 100}
                    label={m.title}
                  />
                </div>
                <b>
                  {Math.min(m.count, m.target)}/{m.target}
                </b>
              </div>
            ))}
          </section>
          <section className="badges-card">
            <div className="journey-card-heading">
              <Trophy size={21} />
              <h2>Suas conquistas</h2>
              <small>
                {stats.badges.filter((b) => b.earned).length}/
                {stats.badges.length}
              </small>
            </div>
            <div className="badge-grid">
              {stats.badges.map((b) => {
                const B = badgeIcons[b.kind];
                return (
                  <motion.div
                    className={`journey-badge ${b.earned ? "earned" : ""}`}
                    role="group"
                    key={b.id}
                    title={b.description}
                    aria-label={`${b.title}: ${b.earned ? "conquistado" : "a conquistar"}. ${b.description}`}
                    whileHover={reduce ? undefined : { y: -3 }}
                  >
                    <span>
                      <B size={24} />
                    </span>
                    <b>{b.title}</b>
                    <small>{b.earned ? "Conquistado" : b.description}</small>
                  </motion.div>
                );
              })}
            </div>
          </section>
          <section className="week-challenge">
            <Crown size={27} />
            <div className="eyebrow">SEU DESAFIO DA SEMANA</div>
            <h3>Constância leva longe.</h3>
            <p>
              Você estudou em{" "}
              <b>{stats.streak.activeThisWeek} dos últimos 7 dias</b> e
              conquistou {stats.weekXp} XP nesse período.
            </p>
            <MotionButton className="text-button" onClick={onPractice}>
              Montar uma prática
              <ArrowRight size={16} />
            </MotionButton>
          </section>
        </aside>
      </div>
    </motion.div>
  );
}
