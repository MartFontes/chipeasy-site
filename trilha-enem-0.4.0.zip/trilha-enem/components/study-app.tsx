"use client";
import { useMotionPreference } from "./use-motion-preference";
import { BrandMark } from "@/components/brand-mark";
import { AnimatePresence, motion } from "framer-motion";
import { MotionButton } from "./motion-button";
import { AnimatedProgress } from "./animated-progress";
import { Capybara } from "./capybara";
import {
  ExperienceSettings,
  SoundToggle,
  useExperience,
} from "./experience-provider";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowDownToLine,
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  BookOpen,
  Bookmark,
  Check,
  CheckCircle2,
  ChevronDown,
  CircleHelp,
  Clock3,
  FileCheck2,
  FileText,
  Flag,
  GraduationCap,
  LayoutDashboard,
  Map as MapIcon,
  Leaf,
  ListFilter,
  LogOut,
  Menu,
  Plus,
  RotateCcw,
  Search,
  Settings2,
  ShieldCheck,
  Sparkles,
  Star,
  Target,
  Trophy,
  Upload,
  UserRound,
  X,
  Zap,
} from "lucide-react";
import type { User } from "@supabase/supabase-js";
import type {
  Area,
  Attempt,
  Coverage,
  Filters,
  Letter,
  Progress,
  Question,
  StudySession,
} from "@/lib/types";
import { AREAS } from "@/lib/types";
import {
  blankProgress,
  dayKey,
  EMPTY_FILTERS,
  filterQuestions,
  latestAttempts,
  mergeProgress,
  plainPreview,
  safeProgress,
  summary,
} from "@/lib/study";
import { supabase } from "@/lib/supabase";
import { Markdown } from "./markdown";
import { mergeCatalog, readWorkspace, WORKSPACE_KEY } from "@/lib/review";
import { journeyStats, type Lesson } from "@/lib/journey";
import { JourneyPanel } from "./journey-panel";
import { LessonCelebration, type Completion } from "./lesson-celebration";
import { QuestionImage } from "./question-image";

type Tab =
  | "home"
  | "overview"
  | "library"
  | "favorites"
  | "errors"
  | "simulations"
  | "progress"
  | "account";
const STORAGE = "trilha-enem.progress.v1";
const nav = [
  ["home", "Minha jornada", MapIcon],
  ["overview", "Meu espaço", LayoutDashboard],
  ["library", "Banco de questões", BookOpen],
  ["simulations", "Meus simulados", FileText],
  ["errors", "Caderno de erros", RotateCcw],
  ["favorites", "Favoritos", Bookmark],
  ["progress", "Meu desempenho", BarChart3],
] as const;
const id = () => crypto.randomUUID();
const fmt = (n: number) => n.toLocaleString("pt-BR");
const percent = (n: number | null) => (n === null ? "—" : `${n}%`);

export function StudyApp({
  questions: initialQuestions,
  coverage,
}: {
  questions: Question[];
  coverage: Coverage[];
}) {
  const { emit, feedback } = useExperience();
  const reduce = useMotionPreference();
  const answerLock = useRef(false);
  const questionOpener = useRef<HTMLElement | null>(null);
  const [questions, setQuestions] = useState(initialQuestions);
  useEffect(() => {
    if (supabase) return;
    const load = () => {
      setQuestions(
        mergeCatalog(initialQuestions, readWorkspace().questions).questions,
      );
    };
    load();
    const onStorage = (e: StorageEvent) => {
      if (e.key === WORKSPACE_KEY) load();
    };
    window.addEventListener("storage", onStorage);
    window.addEventListener("trilha-workspace", load);
    return () => {
      window.removeEventListener("storage", onStorage);
      window.removeEventListener("trilha-workspace", load);
    };
  }, [initialQuestions]);
  const [tab, setTab] = useState<Tab>("home"),
    [filters, setFilters] = useState<Filters>(EMPTY_FILTERS),
    [progress, setProgress] = useState<Progress>(blankProgress),
    [ready, setReady] = useState(false);
  const [active, setActive] = useState<string | null>(null),
    [selected, setSelected] = useState<Letter | null>(null),
    [result, setResult] = useState<Attempt | null>(null),
    [queue, setQueue] = useState<string[]>([]),
    [sessionId, setSessionId] = useState<string | null>(null);
  const [menu, setMenu] = useState(false),
    [notice, setNotice] = useState(""),
    [page, setPage] = useState(1),
    [search, setSearch] = useState("");
  const [sessionSize, setSessionSize] = useState(10),
    [sessionArea, setSessionArea] = useState("all"),
    [sessionLanguage, setSessionLanguage] = useState("ingles");
  const [scope, setScope] = useState("guest");
  const [journeyArea, setJourneyArea] = useState<Area>("linguagens");
  useEffect(() => {
    if (!ready || scope !== (user?.id || "guest")) return;
    try {
      const value = JSON.parse(
        localStorage.getItem(STORAGE + "." + scope + ".journey") || "null",
      );
      setSessionLanguage(
        value?.language === "espanhol" ? "espanhol" : "ingles",
      );
      setJourneyArea(
        Object.keys(AREAS).includes(value?.area) ? value.area : "linguagens",
      );
    } catch {}
  }, [ready, scope]);
  const [earnedXp, setEarnedXp] = useState(0),
    [activityXpBase, setActivityXpBase] = useState(0),
    [completion, setCompletion] = useState<Completion | null>(null);
  const [user, setUser] = useState<User | null>(null),
    [authBusy, setAuthBusy] = useState(false),
    [authMode, setAuthMode] = useState<"login" | "signup">("login"),
    [email, setEmail] = useState(""),
    [password, setPassword] = useState("");
  const [syncState, setSyncState] = useState(""),
    started = useRef(Date.now()),
    fileRef = useRef<HTMLInputElement>(null),
    syncTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const progressRef = useRef(progress),
    accountGeneration = useRef(0),
    cloudReady = useRef(false),
    [cloudLoaded, setCloudLoaded] = useState(false);
  useEffect(() => {
    progressRef.current = progress;
  }, [progress]);
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE + ".guest");
      if (raw) setProgress(safeProgress(JSON.parse(raw)));
    } catch {
      try {
        const raw = localStorage.getItem(STORAGE + ".guest");
        if (raw) localStorage.setItem(STORAGE + ".recovery." + Date.now(), raw);
      } catch {}
      setNotice(
        "Não foi possível ler o progresso salvo. Exporte uma cópia em Meu perfil para guardar seus novos estudos.",
      );
    }
    setReady(true);
    if ("serviceWorker" in navigator)
      navigator.serviceWorker.register("/sw.js").catch(() => {});
  }, []);
  useEffect(() => {
    if (ready && scope === (user?.id || "guest"))
      try {
        localStorage.setItem(STORAGE + "." + scope, JSON.stringify(progress));
      } catch {
        setNotice(
          "O navegador não conseguiu salvar. Exporte seu progresso em Meu perfil.",
        );
      }
  }, [progress, ready, scope, user?.id]);
  useEffect(() => {
    if (!supabase) return;
    let cancelled = false;
    supabase.auth.getUser().then(({ data }) => {
      if (!cancelled) setUser(data.user);
    });
    const { data } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user || null);
    });
    return () => {
      cancelled = true;
      data.subscription.unsubscribe();
    };
  }, []);
  useEffect(() => {
    const generation = ++accountGeneration.current;
    cloudReady.current = false;
    setCloudLoaded(false);
    if (!ready) return;
    const nextScope = user?.id || "guest";
    if (nextScope !== scope) {
      let stored = blankProgress();
      try {
        const raw = localStorage.getItem(STORAGE + "." + nextScope);
        if (raw) stored = safeProgress(JSON.parse(raw));
      } catch {
        setNotice("O progresso desta conta precisa ser conferido.");
      }
      setScope(nextScope);
      setProgress(stored);
    }
    if (!supabase || !user) return;
    setSyncState("Carregando seu progresso…");
    supabase
      .from("study_progress")
      .select("data")
      .eq("user_id", user.id)
      .maybeSingle()
      .then(({ data, error }) => {
        if (generation !== accountGeneration.current) return;
        if (error) {
          setSyncState(
            "Seu progresso está salvo neste dispositivo. A sincronização está indisponível.",
          );
          return;
        }
        try {
          if (data?.data)
            setProgress((p) => mergeProgress(p, safeProgress(data.data)));
          cloudReady.current = true;
          setCloudLoaded(true);
          setSyncState("Conta conectada");
        } catch {
          setSyncState(
            "O progresso da conta precisa ser conferido. A cópia deste dispositivo foi preservada.",
          );
        }
      });
  }, [user?.id, ready]);
  useEffect(() => {
    if (
      !supabase ||
      !user ||
      scope !== user.id ||
      !ready ||
      !cloudLoaded ||
      !cloudReady.current
    )
      return;
    const generation = accountGeneration.current;
    if (syncTimer.current) clearTimeout(syncTimer.current);
    syncTimer.current = setTimeout(async () => {
      const { error } = await supabase!.rpc("merge_study_progress", {
        payload: progress,
      });
      if (generation === accountGeneration.current)
        setSyncState(
          error
            ? "Salvo neste dispositivo. Tentaremos sincronizar na próxima alteração."
            : "Progresso sincronizado",
        );
    }, 800);
    return () => {
      if (syncTimer.current) clearTimeout(syncTimer.current);
    };
  }, [progress, user?.id, ready, cloudLoaded, scope]);
  useEffect(() => {
    if (notice) {
      const timer = setTimeout(() => setNotice(""), 6500);
      return () => clearTimeout(timer);
    }
  }, [notice]);
  useEffect(() => {
    setPage(1);
  }, [filters, tab]);
  useEffect(() => {
    if (!active) return;
    const previous = questionOpener.current,
      oldOverflow = document.body.style.overflow;
    const dialog = document.querySelector<HTMLElement>('[role="dialog"]');
    dialog?.scrollTo({ top: 0, behavior: "instant" });
    const focusable = () =>
      Array.from(
        dialog?.querySelectorAll<HTMLElement>(
          'button:not(:disabled),a[href],input:not(:disabled),select,textarea,[tabindex="0"]',
        ) || [],
      );
    focusable()[0]?.focus();
    document.body.style.overflow = "hidden";
    const trap = (e: KeyboardEvent) => {
      if (document.querySelector("dialog[open]")) return;
      if (e.key !== "Tab") return;
      const nodes = focusable(),
        first = nodes[0],
        last = nodes[nodes.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last?.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first?.focus();
      }
    };
    document.addEventListener("keydown", trap);
    return () => {
      document.body.style.overflow = oldOverflow;
      document.removeEventListener("keydown", trap);
      previous?.focus();
    };
  }, [active]);
  useEffect(() => {
    if (!active) return;
    const handler = (event: KeyboardEvent) => {
      if (document.querySelector("dialog[open]")) return;
      if (event.key === "Escape") {
        setActive(null);
        return;
      }
      if (
        ["INPUT", "TEXTAREA", "SELECT"].includes(
          (event.target as HTMLElement).tagName,
        )
      )
        return;
      if (!result && /^[a-e]$/i.test(event.key))
        setSelected(event.key.toUpperCase() as Letter);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [active, result]);

  const stats = useMemo(() => summary(progress), [progress]),
    latest = useMemo(
      () => latestAttempts(progress.attempts),
      [progress.attempts],
    );
  const byId = useMemo(
    () => new Map(questions.map((q) => [q.id, q])),
    [questions],
  );
  const effectiveFilters = {
    ...filters,
    state:
      tab === "favorites"
        ? "favorite"
        : tab === "errors"
          ? "wrong"
          : filters.state,
  };
  const filtered = useMemo(
    () => filterQuestions(questions, effectiveFilters, progress),
    [questions, filters, tab, progress],
  );
  const current = active ? byId.get(active) : null,
    visible = filtered.slice((page - 1) * 12, page * 12),
    pages = Math.max(1, Math.ceil(filtered.length / 12));
  const areaStats = Object.entries(AREAS).map(([key, area]) => {
    const qs = questions.filter((q) => q.area === key),
      attempts = qs.flatMap((q) =>
        latest.get(q.id) ? [latest.get(q.id)!] : [],
      ),
      scored = attempts.filter((a) => a.correct !== null);
    return {
      ...area,
      key,
      total: qs.length,
      answered: attempts.length,
      accuracy: scored.length
        ? Math.round(
            (100 * scored.filter((a) => a.correct).length) / scored.length,
          )
        : null,
    };
  });
  const availableCount = questions.length;
  function update(fn: (p: Progress) => Progress) {
    setProgress((p) => ({ ...fn(p), updatedAt: new Date().toISOString() }));
  }
  function navigate(next: Tab) {
    window.scrollTo({ top: 0, behavior: "instant" });
    setTab(next);
    setMenu(false);
    setActive(null);
    setFilters(EMPTY_FILTERS);
    setPage(1);
  }
  function chooseJourneyArea(area: Area) {
    setJourneyArea(area);
    saveJourneyPreferences(area, sessionLanguage);
  }
  function chooseJourneyLanguage(language: string) {
    setSessionLanguage(language);
    saveJourneyPreferences(journeyArea, language);
  }
  function saveJourneyPreferences(area: Area, language: string) {
    if (scope !== (user?.id || "guest")) return;
    try {
      localStorage.setItem(
        STORAGE + "." + scope + ".journey",
        JSON.stringify({ area, language }),
      );
    } catch {}
  }
  function favorite(qid: string) {
    update((p) => {
      const saved = !p.favorites.includes(qid);
      return {
        ...p,
        favorites: saved
          ? [...p.favorites, qid]
          : p.favorites.filter((x) => x !== qid),
        favoriteChanges: {
          ...(p.favoriteChanges || {}),
          [qid]: { saved, at: new Date().toISOString() },
        },
      };
    });
  }
  function openQuestion(
    qid: string,
    ids: string[] = [],
    sid: string | null = null,
  ) {
    answerLock.current = false;
    if (!active)
      questionOpener.current = document.activeElement as HTMLElement | null;
    if (sid && (!active || sid !== sessionId))
      setActivityXpBase(journeyStats(progress, questions).xp);
    setQueue(ids.length ? ids : [qid]);
    setSessionId(sid);
    setActive(qid);
    setSelected(null);
    setResult(null);
    setEarnedXp(0);
    started.current = Date.now();
  }
  function answer() {
    if (!current || !selected || result || answerLock.current) return;
    answerLock.current = true;
    const a: Attempt = {
      id: id(),
      questionId: current.id,
      selected,
      correct:
        current.annulled || !current.answer
          ? null
          : selected === current.answer,
      answeredAt: new Date().toISOString(),
      durationMs: Math.max(0, Date.now() - started.current),
      sessionId,
    };
    const before = journeyStats(progress, questions);
    const after = journeyStats(
      { ...progress, attempts: [...progress.attempts, a] },
      questions,
    );
    const xp = after.xp - before.xp;
    setEarnedXp(xp);
    emit({
      kind:
        a.correct === true
          ? "correct"
          : a.correct === false
            ? "encourage"
            : "neutral",
      xp,
      levelUp: after.level > before.level ? after.level : undefined,
    });
    update((p) => ({ ...p, attempts: [...p.attempts, a] }));
    setResult(a);
  }
  function nextQuestion() {
    if (!current) return;
    const index = queue.indexOf(current.id);
    if (index < queue.length - 1) {
      openQuestion(queue[index + 1], queue, sessionId);
      return;
    }
    if (sessionId) {
      update((p) => ({
        ...p,
        sessions: p.sessions.map((s) =>
          s.id === sessionId
            ? { ...s, finishedAt: new Date().toISOString() }
            : s,
        ),
      }));
      const session = progress.sessions.find((s) => s.id === sessionId),
        isJourney = sessionId.startsWith("journey-"),
        ids = session?.questionIds || queue;
      const answers = latestAttempts(
        progress.attempts.filter((a) =>
          isJourney ? ids.includes(a.questionId) : a.sessionId === sessionId,
        ),
      );
      const game = journeyStats(progress, questions);
      setCompletion({
        title: session?.title || "Prática",
        total: ids.length,
        correct: ids.filter((qid) => answers.get(qid)?.correct === true).length,
        xp: Math.max(0, game.xp - activityXpBase),
        streak: game.streak.current,
        journey: isJourney,
      });
      emit({ kind: "complete", xp: Math.max(0, game.xp - activityXpBase) });
      if (isJourney) setTab("home");
    }
    setActive(null);
  }
  function startLesson(lesson: Lesson) {
    if (!lesson.unlocked) return;
    const prefix = `journey-${sessionLanguage}-${lesson.id}-`;
    const existing = progress.sessions.find(
      (s) => s.id.startsWith(prefix) && !s.finishedAt,
    );
    if (existing) {
      const done = new Set(
        progress.attempts
          .filter((a) => a.sessionId === existing.id)
          .map((a) => a.questionId),
      );
      const pending = existing.questionIds.filter((qid) => !done.has(qid));
      if (pending.length) {
        openQuestion(pending[0], pending, existing.id);
        return;
      }
    }
    const sid = prefix + id(),
      remaining = lesson.questionIds.filter((qid) => !latest.has(qid)),
      ids = remaining.length ? remaining : lesson.questionIds;
    const s: StudySession = {
      id: sid,
      title: `Trilha · ${AREAS[lesson.area].label} · Lição ${lesson.number}`,
      questionIds: ids,
      createdAt: new Date().toISOString(),
      finishedAt: null,
    };
    update((p) => ({
      ...p,
      sessions: [
        s,
        ...p.sessions.map((old) =>
          old.id === existing?.id
            ? { ...old, finishedAt: new Date().toISOString() }
            : old,
        ),
      ],
    }));
    openQuestion(ids[0], ids, sid);
  }
  function startSession() {
    const pool = filterQuestions(
      questions,
      { ...EMPTY_FILTERS, area: sessionArea, language: sessionLanguage },
      progress,
    ).filter((q) => !q.annulled && q.answer);
    if (!pool.length) {
      setNotice("Não há questões para esta seleção.");
      return;
    }
    const mixed = [...pool];
    for (let i = mixed.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [mixed[i], mixed[j]] = [mixed[j], mixed[i]];
    }
    const selected = mixed.slice(0, sessionSize).map((q) => q.id),
      s: StudySession = {
        id: id(),
        title: `${sessionArea === "all" ? "Prática mista" : AREAS[sessionArea as Area].label} · ${selected.length} questões`,
        questionIds: selected,
        createdAt: new Date().toISOString(),
        finishedAt: null,
      };
    update((p) => ({ ...p, sessions: [s, ...p.sessions] }));
    openQuestion(selected[0], selected, s.id);
  }
  function exportProgress() {
    const blob = new Blob([JSON.stringify(progress, null, 2)], {
        type: "application/json",
      }),
      url = URL.createObjectURL(blob),
      a = document.createElement("a");
    a.href = url;
    a.download = `trilha-enem-progresso-${dayKey(new Date())}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setNotice("Seu progresso foi exportado.");
  }
  async function importProgress(file: File | undefined) {
    if (!file) return;
    try {
      if (file.size > 8 * 1024 * 1024) throw Error("Arquivo muito grande.");
      const data = safeProgress(JSON.parse(await file.text()));
      update((p) => mergeProgress(p, data));
      setNotice("Progresso importado sem apagar suas respostas atuais.");
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "Arquivo inválido.");
    }
    if (fileRef.current) fileRef.current.value = "";
  }
  async function authenticate(event: React.FormEvent) {
    event.preventDefault();
    if (!supabase) return;
    setAuthBusy(true);
    const { error } =
      authMode === "signup"
        ? await supabase.auth.signUp({ email, password })
        : await supabase.auth.signInWithPassword({ email, password });
    setAuthBusy(false);
    if (error) {
      setNotice(error.message);
      return;
    }
    setPassword("");
    setNotice(
      authMode === "signup"
        ? "Confira seu e-mail para confirmar o cadastro."
        : "Você entrou na sua conta.",
    );
  }
  const weekdays = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    const key = dayKey(d),
      n = new Set(
        progress.attempts
          .filter((a) => dayKey(a.answeredAt) === key)
          .map((a) => a.questionId),
      ).size;
    return {
      label: new Intl.DateTimeFormat("pt-BR", {
        weekday: "short",
        timeZone: "America/Sao_Paulo",
      })
        .format(d)
        .slice(0, 3),
      n,
      key,
    };
  });
  const toolbar = (
    <div className="filter-bar">
      <label className="search-field">
        <Search size={18} />
        <input
          aria-label="Buscar questões"
          placeholder="Busque um tema, palavra ou questão…"
          value={filters.query}
          onChange={(e) => setFilters((f) => ({ ...f, query: e.target.value }))}
        />
        {filters.query && (
          <MotionButton
            aria-label="Limpar busca"
            onClick={() => setFilters((f) => ({ ...f, query: "" }))}
          >
            <X size={15} />
          </MotionButton>
        )}
      </label>
      <label className="select-field">
        <span className="sr-only">Área do conhecimento</span>
        <select
          aria-label="Área do conhecimento"
          value={filters.area}
          onChange={(e) => setFilters((f) => ({ ...f, area: e.target.value }))}
        >
          <option value="all">Todas as áreas</option>
          {Object.entries(AREAS).map(([v, a]) => (
            <option value={v} key={v}>
              {a.label}
            </option>
          ))}
        </select>
        <ChevronDown size={15} />
      </label>
      <label className="select-field">
        <span className="sr-only">Ano</span>
        <select
          aria-label="Ano"
          value={filters.year}
          onChange={(e) => setFilters((f) => ({ ...f, year: e.target.value }))}
        >
          <option value="all">Todos os anos</option>
          {[...new Set(questions.map((q) => q.year))]
            .sort((a, b) => b - a)
            .map((y) => (
              <option key={y}>{y}</option>
            ))}
        </select>
        <ChevronDown size={15} />
      </label>
      <label className="select-field">
        <span className="sr-only">Língua estrangeira</span>
        <select
          aria-label="Língua estrangeira"
          value={filters.language}
          onChange={(e) =>
            setFilters((f) => ({ ...f, language: e.target.value }))
          }
        >
          <option value="all">Inglês e espanhol</option>
          <option value="ingles">Inglês</option>
          <option value="espanhol">Espanhol</option>
        </select>
        <ChevronDown size={15} />
      </label>
      {tab === "library" && (
        <label className="select-field">
          <span className="sr-only">Situação</span>
          <select
            aria-label="Situação"
            value={filters.state}
            onChange={(e) =>
              setFilters((f) => ({ ...f, state: e.target.value }))
            }
          >
            <option value="all">Todas as questões</option>
            <option value="unanswered">Não respondidas</option>
            <option value="wrong">Para revisar</option>
            <option value="correct">Já acertei</option>
          </select>
          <ChevronDown size={15} />
        </label>
      )}
    </div>
  );
  function questionCard(q: Question) {
    const a = latest.get(q.id),
      area = AREAS[q.area];
    return (
      <motion.article
        className="question-card"
        key={q.id}
        whileHover={reduce ? undefined : { y: -3 }}
      >
        <div className="question-card-top">
          <span
            className="area-tag"
            style={{ "--area": area.color } as React.CSSProperties}
          >
            <span />
            {area.label}
          </span>
          <MotionButton
            className={`icon-button favorite ${progress.favorites.includes(q.id) ? "saved" : ""}`}
            aria-label={`${progress.favorites.includes(q.id) ? "Remover dos" : "Adicionar aos"} favoritos: questão ${q.number}`}
            onClick={() => favorite(q.id)}
          >
            <Bookmark
              size={18}
              fill={progress.favorites.includes(q.id) ? "currentColor" : "none"}
            />
          </MotionButton>
        </div>
        <div className="question-origin">
          ENEM {q.year} <span>·</span> Questão {q.number}
          {q.language && (
            <>
              <span>·</span>
              {q.language === "ingles" ? "Inglês" : "Espanhol"}
            </>
          )}
        </div>
        <MotionButton
          className="question-card-text"
          onClick={() =>
            openQuestion(
              q.id,
              filtered.map((x) => x.id),
            )
          }
        >
          <h3>{q.subject || q.prompt || `Questão ${q.number}`}</h3>
          <p>
            {plainPreview(q.context) ||
              "Questão com imagem. Abra para ler o conteúdo completo."}
          </p>
        </MotionButton>
        <div className="question-card-bottom">
          <span
            className={
              a?.correct === true
                ? "status correct"
                : a?.correct === false
                  ? "status wrong"
                  : "status"
            }
          >
            {a?.correct === true ? (
              <CheckCircle2 size={14} />
            ) : a?.correct === false ? (
              <RotateCcw size={14} />
            ) : (
              <span className="status-dot" />
            )}
            {a
              ? a.correct === null
                ? "Sem pontuação"
                : a.correct
                  ? "Você acertou"
                  : "Revisar depois"
              : "Ainda não respondida"}
          </span>
          <MotionButton
            className="text-button"
            onClick={() =>
              openQuestion(
                q.id,
                filtered.map((x) => x.id),
              )
            }
          >
            Resolver <ArrowRight size={16} />
          </MotionButton>
        </div>
      </motion.article>
    );
  }
  return (
    <div className="app-shell">
      <a href="#main-content" className="skip-link">
        Pular para o conteúdo
      </a>
      {menu && (
        <MotionButton
          className="menu-overlay"
          aria-label="Fechar menu"
          onClick={() => setMenu(false)}
        />
      )}
      <aside className={`sidebar ${menu ? "open" : ""}`} inert={!!current}>
        <a className="brand" href="/" aria-label="Trilha ENEM, início">
          <span className="brand-icon">
            <BrandMark />
          </span>
          <span>
            trilha<span className="brand-enem">ENEM</span>
          </span>
        </a>
        <div className="sidebar-label">SEU ESPAÇO PARA IR ALÉM</div>
        <nav>
          {nav.map(([key, label, Icon]) => (
            <MotionButton
              key={key}
              onClick={() => navigate(key)}
              className={tab === key ? "nav-item active" : "nav-item"}
              aria-current={tab === key ? "page" : undefined}
            >
              <Icon size={19} />
              <span>{label}</span>
              {key === "errors" && stats.wrong > 0 && <b>{stats.wrong}</b>}
            </MotionButton>
          ))}
        </nav>
        <div className="sidebar-tip">
          <div>
            <Leaf size={20} />
            <span>Seu sonho merece esse passo.</span>
          </div>
          <p>
            Pequenas vitórias, todo dia.
            <br />
            Vamos conquistar a próxima?
          </p>
          <MotionButton
            onClick={() => {
              setTab("simulations");
              setMenu(false);
            }}
          >
            Começar uma prática <ArrowUpRight size={16} />
          </MotionButton>
        </div>
        <div className="sidebar-bottom">
          <a href="/revisao">
            <FileCheck2 size={18} />
            Revisão do acervo
            <ArrowUpRight size={13} />
          </a>
          <MotionButton onClick={() => navigate("account")}>
            <Settings2 size={18} />
            Meu perfil
          </MotionButton>
          <small>Feito para o seu próximo passo.</small>
        </div>
      </aside>
      <div className="main-column" inert={!!current}>
        <header className="topbar">
          <div className="topbar-left">
            <MotionButton
              className="mobile-menu icon-button"
              aria-label="Abrir menu"
              onClick={() => setMenu(true)}
            >
              <Menu size={23} />
            </MotionButton>
            <a
              className="mobile-brand"
              href="/"
              aria-label="Trilha ENEM, início"
            >
              <span className="brand-icon">
                <BrandMark />
              </span>
              <strong>
                trilha<span>ENEM</span>
              </strong>
            </a>
            <span className="breadcrumb">
              Seu espaço de estudos <span>/</span>{" "}
              <b>{nav.find((x) => x[0] === tab)?.[1] || "Meu perfil"}</b>
            </span>
          </div>
          <div className="topbar-actions">
            <SoundToggle />
            <span className="local-indicator">
              <span />
              {user ? "Conta conectada" : "Neste dispositivo"}
            </span>
            <MotionButton
              className="avatar"
              aria-label="Abrir meu perfil"
              onClick={() => navigate("account")}
            >
              {(progress.name || user?.email || "E").slice(0, 1).toUpperCase()}
            </MotionButton>
          </div>
        </header>
        <motion.main
          key={tab}
          id="main-content"
          tabIndex={-1}
          initial={false}
          animate={{ opacity: 1 }}
          transition={{ duration: reduce ? 0 : 0.18 }}
        >
          {tab === "home" && (
            <JourneyPanel
              progress={progress}
              questions={questions}
              language={sessionLanguage}
              area={journeyArea}
              onArea={chooseJourneyArea}
              onLanguage={chooseJourneyLanguage}
              onStart={startLesson}
              onPractice={() => navigate("simulations")}
            />
          )}
          {tab === "overview" && (
            <>
              <section className="welcome">
                <div>
                  <div className="eyebrow">
                    <span />
                    UM ACERTO DE CADA VEZ
                  </div>
                  <h1>
                    Seu próximo passo
                    <br /> começa <em>aqui.</em>
                  </h1>
                  <p>
                    {progress.name ? `${progress.name}, seu` : "Seu"} caminho
                    até o Enem fica mais claro com prática.
                    <br className="desktop-break" /> Escolha uma área e continue
                    de onde parou.
                  </p>
                  <MotionButton
                    className="button primary"
                    onClick={() => navigate("library")}
                  >
                    Explorar questões <ArrowRight size={18} />
                  </MotionButton>
                </div>
                <div className="goal-card">
                  <div className="goal-header">
                    <span className="mini-icon">
                      <Target size={20} />
                    </span>
                    <span>UM POUCO, TODOS OS DIAS</span>
                  </div>
                  <div className="goal-value">
                    <strong>{stats.today}</strong>
                    <span>/ {progress.dailyGoal} questões</span>
                  </div>
                  <p>Sua meta de hoje</p>
                  <div className="progress-track">
                    <span
                      style={{
                        width: `${Math.min(100, (100 * stats.today) / progress.dailyGoal)}%`,
                      }}
                    />
                  </div>
                  <div className="week-days">
                    {weekdays.map((d) => (
                      <div
                        key={d.key}
                        className={
                          d.n
                            ? "done"
                            : d.key === dayKey(new Date())
                              ? "today"
                              : ""
                        }
                      >
                        <span>{d.n ? <Check size={12} /> : <span />}</span>
                        <small>{d.label}</small>
                      </div>
                    ))}
                  </div>
                  <div className="goal-footer">
                    <Sparkles size={15} />
                    {stats.today >= progress.dailyGoal
                      ? "Meta cumprida. Você avançou hoje!"
                      : "Cada questão é um passo a mais."}
                  </div>
                </div>
              </section>
              <section className="stats-grid" aria-label="Seu resumo">
                <div className="stat-card">
                  <span className="stat-icon green">
                    <CheckCircle2 size={20} />
                  </span>
                  <div>
                    <p>Questões resolvidas</p>
                    <strong>{fmt(stats.answered)}</strong>
                    <small>no seu ritmo</small>
                  </div>
                </div>
                <div className="stat-card">
                  <span className="stat-icon amber">
                    <Target size={21} />
                  </span>
                  <div>
                    <p>Taxa de acertos</p>
                    <strong>{percent(stats.accuracy)}</strong>
                    <small>
                      {stats.answered
                        ? "das questões com gabarito"
                        : "comece para acompanhar"}
                    </small>
                  </div>
                </div>
                <div className="stat-card">
                  <span className="stat-icon lavender">
                    <Bookmark size={20} />
                  </span>
                  <div>
                    <p>Questões favoritas</p>
                    <strong>{fmt(progress.favorites.length)}</strong>
                    <small>para voltar quando quiser</small>
                  </div>
                </div>
                <div className="stat-card">
                  <span className="stat-icon coral">
                    <RotateCcw size={20} />
                  </span>
                  <div>
                    <p>Para revisar</p>
                    <strong>{fmt(stats.wrong)}</strong>
                    <small>uma nova chance de aprender</small>
                  </div>
                </div>
              </section>
              <section>
                <div className="section-heading">
                  <div>
                    <div className="eyebrow muted">ESCOLHA SEU FOCO</div>
                    <h2>Uma área de cada vez.</h2>
                  </div>
                  <MotionButton
                    className="text-button"
                    onClick={() => navigate("library")}
                  >
                    Ver todas as questões <ArrowRight size={16} />
                  </MotionButton>
                </div>
                <div className="areas-grid">
                  {areaStats.map((a) => (
                    <MotionButton
                      className="area-card"
                      key={a.key}
                      style={{ "--area": a.color } as React.CSSProperties}
                      onClick={() => {
                        navigate("library");
                        setFilters({ ...EMPTY_FILTERS, area: a.key });
                      }}
                    >
                      <div className="area-card-head">
                        <span className="area-monogram">{a.short}</span>
                        <ArrowUpRight size={20} />
                      </div>
                      <h3>{a.label}</h3>
                      <p>{fmt(a.total)} questões para explorar</p>
                      <div className="area-card-progress">
                        <span
                          style={{
                            width: `${a.total ? (100 * a.answered) / a.total : 0}%`,
                          }}
                        />
                      </div>
                      <div className="area-card-footer">
                        <span>{a.answered} resolvidas</span>
                        <b>
                          {percent(a.accuracy)} <small>de acertos</small>
                        </b>
                      </div>
                    </MotionButton>
                  ))}
                </div>
              </section>
              <section className="home-bottom">
                <div>
                  <div className="section-heading">
                    <div>
                      <div className="eyebrow muted">MANTENHA O MOVIMENTO</div>
                      <h2>
                        {progress.attempts.length
                          ? "Continue sua trilha"
                          : "Que tal começar por aqui?"}
                      </h2>
                    </div>
                  </div>
                  <div className="suggested-list">
                    {questions
                      .filter((q) => !latest.has(q.id))
                      .slice(0, 3)
                      .map((q) => (
                        <MotionButton
                          key={q.id}
                          onClick={() =>
                            openQuestion(
                              q.id,
                              questions
                                .filter((x) => !latest.has(x.id))
                                .slice(0, 10)
                                .map((x) => x.id),
                            )
                          }
                        >
                          <span
                            className="small-area"
                            style={{
                              color: AREAS[q.area].color,
                              background: `${AREAS[q.area].color}12`,
                            }}
                          >
                            {AREAS[q.area].short}
                          </span>
                          <span>
                            <b>{q.prompt || `Questão ${q.number}`}</b>
                            <small>
                              ENEM {q.year} · Questão {q.number} ·{" "}
                              {AREAS[q.area].label}
                            </small>
                          </span>
                          <ArrowUpRight size={19} />
                        </MotionButton>
                      ))}
                  </div>
                </div>
                <div className="practice-banner">
                  <span className="practice-art">
                    <GraduationCap size={38} strokeWidth={1.5} />
                  </span>
                  <div className="eyebrow">DO SEU JEITO</div>
                  <h3>
                    Transforme a prática
                    <br />
                    em preparação.
                  </h3>
                  <p>Monte uma lista com as áreas que você quer fortalecer.</p>
                  <MotionButton
                    className="button"
                    onClick={() => navigate("simulations")}
                  >
                    Montar minha prática <ArrowRight size={16} />
                  </MotionButton>
                </div>
              </section>
            </>
          )}

          {(["library", "favorites", "errors"] as Tab[]).includes(tab) && (
            <>
              <div className="page-heading">
                <div>
                  <div className="eyebrow muted">
                    {tab === "library"
                      ? "EXPLORE. PRATIQUE. AVANCE."
                      : "O SEU ACERVO PESSOAL"}
                  </div>
                  <h1>
                    {tab === "favorites"
                      ? "Favoritos"
                      : tab === "errors"
                        ? "Cada erro, uma descoberta."
                        : "Banco de questões"}
                  </h1>
                  <p>
                    {tab === "errors"
                      ? "Retome as questões que você errou. Um novo acerto tira a questão deste caderno."
                      : tab === "favorites"
                        ? "As questões que você separou para voltar com calma."
                        : `${fmt(availableCount)} questões reais para construir sua preparação.`}
                  </p>
                </div>
                <span className="collection-pill">
                  <BookOpen size={16} />
                  {[...new Set(questions.map((q) => q.year))]
                    .sort()
                    .join(" · ")}
                </span>
              </div>
              {toolbar}
              <div className="results-meta">
                <span>
                  <b>{fmt(filtered.length)}</b> questões encontradas
                </span>
                <MotionButton
                  className="text-button subtle"
                  onClick={() => setFilters(EMPTY_FILTERS)}
                >
                  <RotateCcw size={14} />
                  Limpar filtros
                </MotionButton>
              </div>
              {visible.length ? (
                <>
                  <div className="questions-grid">
                    {visible.map(questionCard)}
                  </div>
                  <div className="pagination">
                    <MotionButton
                      className="button secondary"
                      disabled={page === 1}
                      onClick={() => setPage((p) => p - 1)}
                    >
                      <ArrowLeft size={16} />
                      Anterior
                    </MotionButton>
                    <span>
                      Página {page} de {pages}
                    </span>
                    <MotionButton
                      className="button secondary"
                      disabled={page >= pages}
                      onClick={() => setPage((p) => p + 1)}
                    >
                      Próxima
                      <ArrowRight size={16} />
                    </MotionButton>
                  </div>
                </>
              ) : (
                <div className="empty-state">
                  <BookOpen size={32} />
                  <h2>
                    {tab === "errors"
                      ? "Seu caderno está livre por aqui."
                      : tab === "favorites"
                        ? "Guarde as questões que merecem outra leitura."
                        : "Nenhuma questão com esses filtros."}
                  </h2>
                  <p>
                    {tab === "errors"
                      ? "As questões que você errar aparecerão aqui para uma nova tentativa."
                      : tab === "favorites"
                        ? "Toque no marcador ao lado de uma questão para encontrá-la aqui."
                        : "Experimente mudar a busca, o ano ou a área."}
                  </p>
                  <MotionButton
                    className="button primary"
                    onClick={() => navigate("library")}
                  >
                    Explorar a biblioteca
                    <ArrowRight size={16} />
                  </MotionButton>
                </div>
              )}
            </>
          )}

          {tab === "simulations" && (
            <>
              <div className="page-heading">
                <div>
                  <div className="eyebrow muted">PRÁTICA COM INTENÇÃO</div>
                  <h1>Seu treino, seu ritmo.</h1>
                  <p>
                    Escolha o foco e monte uma lista de questões reais. Seu
                    progresso é salvo a cada resposta.
                  </p>
                </div>
              </div>
              <div className="two-columns">
                <section className="panel">
                  <div className="panel-heading">
                    <span className="mini-icon">
                      <Plus size={20} />
                    </span>
                    <h2>Uma nova prática</h2>
                  </div>
                  <div className="form-stack">
                    <label>
                      Área do conhecimento
                      <select
                        value={sessionArea}
                        onChange={(e) => setSessionArea(e.target.value)}
                      >
                        <option value="all">Todas as áreas</option>
                        {Object.entries(AREAS).map(([v, a]) => (
                          <option value={v} key={v}>
                            {a.label}
                          </option>
                        ))}
                      </select>
                    </label>
                    <label>
                      Quantidade de questões
                      <select
                        value={sessionSize}
                        onChange={(e) => setSessionSize(+e.target.value)}
                      >
                        {[5, 10, 20, 45, 90, 180].map((n) => (
                          <option key={n} value={n}>
                            {n} questões
                          </option>
                        ))}
                      </select>
                    </label>
                    <label>
                      Língua estrangeira
                      <select
                        value={sessionLanguage}
                        onChange={(e) => setSessionLanguage(e.target.value)}
                      >
                        <option value="ingles">Inglês</option>
                        <option value="espanhol">Espanhol</option>
                      </select>
                    </label>
                    <p className="help-text">
                      As questões são sorteadas sem repetição. Práticas longas
                      usam quantas questões estiverem disponíveis no filtro
                      escolhido.
                    </p>
                    <MotionButton
                      className="button primary"
                      onClick={startSession}
                    >
                      Começar minha prática
                      <ArrowRight size={18} />
                    </MotionButton>
                  </div>
                </section>
                <section className="panel">
                  <h2>Suas práticas</h2>
                  {progress.sessions.length ? (
                    <div className="session-list">
                      {progress.sessions.map((s) => {
                        const done = new Set(
                          progress.attempts
                            .filter((a) => a.sessionId === s.id)
                            .map((a) => a.questionId),
                        );
                        return (
                          <div key={s.id}>
                            <span className="mini-icon">
                              <FileText size={19} />
                            </span>
                            <div>
                              <b>{s.title}</b>
                              <small>
                                {done.size} de {s.questionIds.length}{" "}
                                respondidas ·{" "}
                                {s.finishedAt ? "Concluída" : "Em andamento"}
                              </small>
                            </div>
                            <MotionButton
                              className="text-button"
                              onClick={() => {
                                const next =
                                  s.questionIds.find((x) => !done.has(x)) ||
                                  s.questionIds[0];
                                openQuestion(next, s.questionIds, s.id);
                              }}
                            >
                              {s.finishedAt ? "Rever" : "Continuar"}
                              <ArrowRight size={15} />
                            </MotionButton>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="empty-state compact">
                      <FileText size={28} />
                      <p>
                        Sua primeira prática começa ao lado.
                        <br />
                        Ela ficará salva aqui para você continuar.
                      </p>
                    </div>
                  )}
                </section>
              </div>
              <div className="info-strip">
                <CircleHelp size={17} />
                <p>
                  O desempenho mostra seus acertos nas questões. A nota oficial
                  do Enem utiliza a TRI e não é calculada por este treino.
                </p>
              </div>
            </>
          )}

          {tab === "progress" && (
            <>
              <div className="page-heading">
                <div>
                  <div className="eyebrow muted">VEJA O CAMINHO PERCORRIDO</div>
                  <h1>Pequenos passos. Progresso real.</h1>
                  <p>
                    Cada resposta ajuda você a entender onde está e o que vale
                    revisar.
                  </p>
                </div>
              </div>
              <div className="stats-grid">
                <div className="stat-card">
                  <span className="stat-icon green">
                    <BookOpen size={22} />
                  </span>
                  <div>
                    <p>Questões diferentes</p>
                    <strong>{stats.answered}</strong>
                    <small>
                      {progress.attempts.length} tentativas registradas
                    </small>
                  </div>
                </div>
                <div className="stat-card">
                  <span className="stat-icon amber">
                    <Trophy size={22} />
                  </span>
                  <div>
                    <p>Taxa de acertos</p>
                    <strong>{percent(stats.accuracy)}</strong>
                    <small>considerando sua última resposta</small>
                  </div>
                </div>
                <div className="stat-card">
                  <span className="stat-icon coral">
                    <RotateCcw size={22} />
                  </span>
                  <div>
                    <p>Para retomar</p>
                    <strong>{stats.wrong}</strong>
                    <small>questões no caderno de erros</small>
                  </div>
                </div>
                <div className="stat-card">
                  <span className="stat-icon lavender">
                    <Clock3 size={22} />
                  </span>
                  <div>
                    <p>Tempo de prática</p>
                    <strong>
                      {Math.round(
                        progress.attempts.reduce(
                          (s, a) => s + a.durationMs,
                          0,
                        ) / 60000,
                      )}{" "}
                      <small>min</small>
                    </strong>
                    <small>nas suas respostas</small>
                  </div>
                </div>
              </div>
              <div className="two-columns">
                <section className="panel">
                  <h2>Seu foco em cada área</h2>
                  <div className="area-performance">
                    {areaStats.map((a) => (
                      <div key={a.key}>
                        <div>
                          <span style={{ background: a.color }} />
                          {a.label}
                          <b>{percent(a.accuracy)}</b>
                        </div>
                        <div className="progress-track">
                          <span
                            style={{
                              background: a.color,
                              width: `${a.accuracy || 0}%`,
                            }}
                          />
                        </div>
                        <small>{a.answered} questões respondidas</small>
                      </div>
                    ))}
                  </div>
                </section>
                <section className="panel">
                  <h2>Sua prática nesta semana</h2>
                  <div className="activity-chart">
                    {weekdays.map((d) => (
                      <div key={d.key}>
                        <span>{d.n}</span>
                        <div>
                          <i
                            style={{
                              height: `${Math.max(3, (140 * d.n) / Math.max(1, ...weekdays.map((x) => x.n)))}px`,
                            }}
                          />
                        </div>
                        <small>{d.label}</small>
                      </div>
                    ))}
                  </div>
                  <p className="help-text">
                    Questões diferentes respondidas por dia, no horário de
                    Brasília.
                  </p>
                </section>
              </div>
              <div className="section-heading">
                <h2>Suas últimas respostas</h2>
              </div>
              {progress.attempts.length ? (
                <div className="panel history-list">
                  {progress.attempts
                    .slice(-12)
                    .reverse()
                    .map((a) => {
                      const q = byId.get(a.questionId);
                      return (
                        <MotionButton
                          key={a.id}
                          onClick={() => {
                            if (q) openQuestion(q.id);
                          }}
                        >
                          <span
                            className={`result-icon ${a.correct === false ? "bad" : ""}`}
                          >
                            {a.correct === true ? (
                              <Check size={17} />
                            ) : a.correct === false ? (
                              <X size={17} />
                            ) : (
                              <Flag size={17} />
                            )}
                          </span>
                          <div>
                            <b>
                              {q
                                ? `ENEM ${q.year} · Questão ${q.number}`
                                : "Questão de outro acervo"}
                            </b>
                            <small>
                              {q ? AREAS[q.area].label : ""} ·{" "}
                              {new Date(a.answeredAt).toLocaleString("pt-BR")}
                            </small>
                          </div>
                          <span>
                            {a.correct === true
                              ? "Acertou"
                              : a.correct === false
                                ? "Revisar"
                                : "Sem pontuação"}
                          </span>
                          <ArrowUpRight size={17} />
                        </MotionButton>
                      );
                    })}
                </div>
              ) : (
                <div className="empty-state">
                  <BarChart3 size={30} />
                  <h2>Seu progresso começa na primeira questão.</h2>
                  <p>
                    Explore o banco de questões e faça sua primeira tentativa.
                  </p>
                  <MotionButton
                    className="button primary"
                    onClick={() => navigate("library")}
                  >
                    Vamos começar
                    <ArrowRight size={17} />
                  </MotionButton>
                </div>
              )}
            </>
          )}

          {tab === "account" && (
            <>
              <div className="page-heading">
                <div>
                  <div className="eyebrow muted">DO SEU JEITO</div>
                  <h1>Seu espaço, suas metas.</h1>
                  <p>
                    Personalize a prática e mantenha uma cópia do que você já
                    construiu.
                  </p>
                </div>
              </div>
              <div className="two-columns">
                <section className="panel">
                  <h2>Meu perfil de estudos</h2>
                  <div className="form-stack">
                    <label>
                      Como podemos chamar você?
                      <input
                        maxLength={80}
                        value={progress.name}
                        placeholder="Seu primeiro nome"
                        onChange={(e) =>
                          update((p) => ({ ...p, name: e.target.value }))
                        }
                      />
                    </label>
                    <label>
                      Meta diária
                      <select
                        value={progress.dailyGoal}
                        onChange={(e) =>
                          update((p) => ({ ...p, dailyGoal: +e.target.value }))
                        }
                      >
                        {[5, 10, 15, 20, 30, 45, 60, 100, 200].map((n) => (
                          <option key={n} value={n}>
                            {n} questões por dia
                          </option>
                        ))}
                      </select>
                    </label>
                    <div className="info-box">
                      <ShieldCheck size={22} />
                      <p>
                        Seu progresso é salvo neste navegador. Exporte uma cópia
                        para guardar ou levar a outro dispositivo.
                      </p>
                    </div>
                    <ExperienceSettings />
                    <MotionButton
                      className="button secondary"
                      onClick={exportProgress}
                    >
                      <ArrowDownToLine size={17} />
                      Exportar meu progresso
                    </MotionButton>
                    <MotionButton
                      className="button secondary"
                      onClick={() => fileRef.current?.click()}
                    >
                      <Upload size={17} />
                      Importar progresso
                    </MotionButton>
                    <input
                      type="file"
                      ref={fileRef}
                      accept="application/json,.json"
                      hidden
                      onChange={(e) => void importProgress(e.target.files?.[0])}
                    />
                  </div>
                </section>
                <section className="panel">
                  <h2>{user ? "Sua conta" : "Continue de qualquer lugar"}</h2>
                  {supabase ? (
                    user ? (
                      <div className="form-stack">
                        <p className="account-email">
                          <UserRound size={20} />
                          {user.email}
                        </p>
                        <p className="help-text" role="status">
                          {syncState}
                        </p>
                        <MotionButton
                          className="button secondary"
                          onClick={async () => {
                            const { error } = await supabase!.auth.signOut();
                            if (error)
                              setNotice(
                                "Não foi possível sair. Tente novamente.",
                              );
                            else
                              setNotice(
                                "Você saiu da conta. O progresso da conta foi preservado.",
                              );
                          }}
                        >
                          <LogOut size={17} />
                          Sair da conta
                        </MotionButton>
                      </div>
                    ) : (
                      <form className="form-stack" onSubmit={authenticate}>
                        <p className="help-text">
                          Entre para sincronizar seus estudos entre
                          dispositivos.
                        </p>
                        <label>
                          E-mail
                          <input
                            type="email"
                            required
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            autoComplete="email"
                          />
                        </label>
                        <label>
                          Senha
                          <input
                            type="password"
                            required
                            minLength={8}
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            autoComplete={
                              authMode === "login"
                                ? "current-password"
                                : "new-password"
                            }
                          />
                        </label>
                        <MotionButton
                          className="button primary"
                          disabled={authBusy}
                        >
                          {authBusy
                            ? "Aguarde…"
                            : authMode === "login"
                              ? "Entrar na minha conta"
                              : "Criar conta"}
                        </MotionButton>
                        <MotionButton
                          type="button"
                          className="text-button"
                          onClick={() =>
                            setAuthMode((m) =>
                              m === "login" ? "signup" : "login",
                            )
                          }
                        >
                          {authMode === "login"
                            ? "Ainda não tenho uma conta"
                            : "Já tenho uma conta"}
                        </MotionButton>
                      </form>
                    )
                  ) : (
                    <div className="local-account">
                      <span className="large-icon">
                        <BookOpen size={32} />
                      </span>
                      <h3>Seu estudo já tem um lugar.</h3>
                      <p>
                        Nesta edição, você pode estudar sem criar conta. Suas
                        respostas e favoritos ficam neste dispositivo.
                      </p>
                      <p>
                        Para continuar em outro aparelho, exporte seu progresso
                        e importe a cópia por lá.
                      </p>
                      <span className="collection-pill">
                        <span className="status-dot" />
                        Modo neste dispositivo
                      </span>
                    </div>
                  )}
                </section>
              </div>
            </>
          )}
          <footer className="main-footer">
            <span>
              trilha<span>ENEM</span> <i>·</i> Um acerto de cada vez.
            </span>
            <a href="/acervo">
              Fontes e cobertura do acervo
              <ArrowUpRight size={13} />
            </a>
          </footer>
        </motion.main>
      </div>

      <AnimatePresence>
        {current && (
          <motion.div
            key="question-reader"
            initial={reduce ? false : { opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: reduce ? 0 : 0.18 }}
            className="question-overlay"
            role="dialog"
            aria-modal="true"
            aria-label={`Questão ${current.number} do Enem ${current.year}`}
          >
            <div className="question-reader">
              <header>
                <MotionButton
                  className="text-button"
                  onClick={() => setActive(null)}
                >
                  <ArrowLeft size={17} />
                  Voltar aos estudos
                </MotionButton>
                <div>
                  <SoundToggle />
                  <MotionButton
                    className={`icon-button ${progress.favorites.includes(current.id) ? "saved" : ""}`}
                    onClick={() => favorite(current.id)}
                    aria-label="Favoritar questão"
                  >
                    <Bookmark
                      size={20}
                      fill={
                        progress.favorites.includes(current.id)
                          ? "currentColor"
                          : "none"
                      }
                    />
                  </MotionButton>
                  <MotionButton
                    className="icon-button"
                    onClick={() => setActive(null)}
                    aria-label="Fechar questão"
                  >
                    <X size={23} />
                  </MotionButton>
                </div>
              </header>
              <div className="reader-content">
                <div
                  className={`reader-companion ${result?.correct === true ? "is-correct" : result?.correct === false ? "is-encouraging" : ""}`}
                >
                  <Capybara
                    mood={
                      result?.correct === true
                        ? "correct"
                        : result?.correct === false
                          ? "encourage"
                          : "idle"
                    }
                    reactionKey={result?.id || current.id}
                  />
                  <div>
                    <span className="eyebrow">
                      {feedback?.levelUp
                        ? `NÍVEL ${feedback.levelUp} DESBLOQUEADO!`
                        : "CAPI ESTÁ COM VOCÊ"}
                    </span>
                    <p aria-live="polite">
                      {result?.correct === true
                        ? "Mandou bem! Mais uma descoberta."
                        : result?.correct === false
                          ? "Tudo bem. Aprender também é tentar de novo."
                          : "Respira, lê com calma e confia no seu raciocínio."}
                    </p>
                  </div>
                  {result && earnedXp > 0 && (
                    <motion.span
                      className="companion-xp"
                      initial={reduce ? false : { scale: 0.7 }}
                      animate={{ scale: 1 }}
                    >
                      <Zap size={16} fill="currentColor" />+{earnedXp} XP
                    </motion.span>
                  )}
                </div>
                {sessionId?.startsWith("journey-") && (
                  <div className="lesson-reader-progress">
                    <span>
                      <Star size={16} />
                      Uma descoberta de cada vez
                    </span>
                    <AnimatedProgress
                      value={
                        ((queue.indexOf(current.id) + (result ? 1 : 0)) /
                          queue.length) *
                        100
                      }
                      label="Avanço nesta lição"
                    />
                  </div>
                )}
                <div className="reader-meta">
                  <span
                    className="area-tag"
                    style={
                      {
                        "--area": AREAS[current.area].color,
                      } as React.CSSProperties
                    }
                  >
                    <span />
                    {AREAS[current.area].label}
                  </span>
                  <span>
                    ENEM {current.year} · Questão {current.number}
                    {current.language
                      ? ` · ${current.language === "ingles" ? "Inglês" : "Espanhol"}`
                      : ""}
                  </span>
                  <span className="queue-count">
                    {queue.indexOf(current.id) + 1} / {queue.length}
                  </span>
                </div>
                <div className="question-context">
                  <Markdown>{current.context}</Markdown>
                </div>
                <h1 className="question-prompt">
                  {current.prompt || `Responda à questão ${current.number}.`}
                </h1>
                <fieldset className="alternatives">
                  <legend className="sr-only">Alternativas da questão</legend>
                  {current.alternatives.map((a) => {
                    const good = !!result && a.letter === current.answer,
                      bad =
                        !!result &&
                        a.letter === selected &&
                        selected !== current.answer;
                    return (
                      <motion.label
                        key={a.letter}
                        tabIndex={-1}
                        whileHover={reduce || result ? undefined : { x: 2 }}
                        whileTap={
                          reduce || result ? undefined : { scale: 0.995 }
                        }
                        className={`alternative ${selected === a.letter ? "chosen" : ""} ${good ? "right" : ""} ${bad ? "incorrect" : ""}`}
                      >
                        <input
                          type="radio"
                          name="answer"
                          value={a.letter}
                          checked={selected === a.letter}
                          disabled={!!result}
                          onChange={() => setSelected(a.letter)}
                        />
                        <span className="alternative-letter">
                          {good ? (
                            <Check size={19} />
                          ) : bad ? (
                            <X size={19} />
                          ) : (
                            a.letter
                          )}
                        </span>
                        <div>
                          {a.text && <Markdown>{a.text}</Markdown>}
                          {a.image && (
                            <QuestionImage
                              src={a.image}
                              alt={`Imagem da alternativa ${a.letter}`}
                            />
                          )}
                        </div>
                      </motion.label>
                    );
                  })}
                </fieldset>
                {result && (
                  <motion.section
                    initial={reduce ? false : { opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`answer-feedback ${result.correct === false ? "retry" : result.correct === null ? "unscored" : ""}`}
                    aria-live="polite"
                  >
                    <div className="feedback-title">
                      {result.correct === true ? (
                        <CheckCircle2 size={23} />
                      ) : result.correct === false ? (
                        <RotateCcw size={23} />
                      ) : (
                        <Flag size={23} />
                      )}
                      <h2>
                        {result.correct === true
                          ? "Mais um passo na direção certa."
                          : result.correct === false
                            ? "Essa vale uma nova leitura."
                            : "Questão sem pontuação."}
                      </h2>
                    </div>
                    <div className="answer-xp">
                      <Zap size={17} />
                      {earnedXp > 0
                        ? `+${earnedXp} XP conquistados`
                        : "Revisar fortalece o que você aprendeu."}
                    </div>
                    <p>
                      {current.annulled
                        ? "Esta questão foi anulada e não entra na sua taxa de acertos."
                        : !current.answer
                          ? "O gabarito ainda está em revisão. Sua tentativa foi salva sem pontuação."
                          : `Resposta: alternativa ${current.answer}. ${result.correct === false ? "Ela ficou no seu caderno de erros para você retomar depois." : ""}`}
                    </p>
                    {current.explanation ? (
                      <div className="explanation">
                        <h3>Entenda a resposta</h3>
                        <Markdown>{current.explanation}</Markdown>
                      </div>
                    ) : (
                      <p className="help-text">
                        A resolução comentada desta questão ainda está em
                        revisão.
                      </p>
                    )}
                    {!current.answerVerified && (
                      <p className="source-note">
                        O gabarito desta transcrição está em conferência. Você
                        pode consultar o documento de origem abaixo.
                      </p>
                    )}
                  </motion.section>
                )}
                <div className="reader-bottom">
                  <span>
                    <CircleHelp size={15} />
                    Use A–E para selecionar uma alternativa.
                  </span>
                  {result ? (
                    <MotionButton
                      className="button primary"
                      onClick={nextQuestion}
                    >
                      {queue.indexOf(current.id) < queue.length - 1
                        ? "Próxima questão"
                        : sessionId
                          ? sessionId.startsWith("journey-")
                            ? "Concluir lição"
                            : "Concluir prática"
                          : "Voltar à biblioteca"}
                      <ArrowRight size={17} />
                    </MotionButton>
                  ) : (
                    <MotionButton
                      className="button primary"
                      disabled={!selected}
                      onClick={answer}
                    >
                      Conferir resposta
                      <Check size={17} />
                    </MotionButton>
                  )}
                </div>
                <div className="question-source">
                  <span>
                    Fonte: Inep · Transcrição: {current.source.provider}
                  </span>
                  <a
                    href={current.source.originalUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Prova original
                    <ArrowUpRight size={13} />
                  </a>
                  <a
                    href={current.source.answerKeyUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Gabarito
                    <ArrowUpRight size={13} />
                  </a>
                </div>
                <MotionButton
                  className="report-link"
                  onClick={() => {
                    const text = `Questão ${current.id}\nOrigem: ${current.source.originalUrl}`;
                    navigator.clipboard?.writeText(text).then(
                      () =>
                        setNotice(
                          "Referência copiada. Envie-a ao responsável pelo acervo para revisão.",
                        ),
                      () => setNotice(`Referência da questão: ${current.id}`),
                    );
                  }}
                >
                  <Flag size={13} />
                  Copiar referência para revisão
                </MotionButton>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      {completion && (
        <LessonCelebration
          result={completion}
          onClose={() => setCompletion(null)}
        />
      )}
      {notice && (
        <div className="toast" role="status">
          {notice}
          <MotionButton onClick={() => setNotice("")} aria-label="Fechar aviso">
            <X size={17} />
          </MotionButton>
        </div>
      )}
    </div>
  );
}
