"use client";
import { useMotionPreference } from "./use-motion-preference";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { AnimatePresence, MotionConfig, motion } from "framer-motion";
import { Gem, Sparkles, Volume2, VolumeX, Zap } from "lucide-react";
import { MotionButton } from "./motion-button";

type RewardKind = "correct" | "encourage" | "neutral" | "complete" | "chest";
export type RewardEvent = {
  id: number;
  kind: RewardKind;
  xp: number;
  levelUp?: number;
};
type Experience = {
  feedback: RewardEvent | null;
  emit: (reward: Omit<RewardEvent, "id">) => void;
  sound: boolean;
  toggleSound: () => void;
};
const ExperienceContext = createContext<Experience | null>(null);
const SETTINGS_KEY = "trilha-enem.experience.v1";

export function ExperienceProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [feedback, setFeedback] = useState<RewardEvent | null>(null);
  const [sound, setSound] = useState(false);
  const soundEnabled = useRef(false);
  const audio = useRef<AudioContext | null>(null);
  const sequence = useRef(0);

  useEffect(() => {
    try {
      const settings = JSON.parse(localStorage.getItem(SETTINGS_KEY) || "null");
      soundEnabled.current = settings?.sound === true;
      setSound(soundEnabled.current);
    } catch {}
    return () => {
      void audio.current?.close().catch(() => {});
    };
  }, []);

  const play = useCallback((kind: RewardKind) => {
    if (!soundEnabled.current || typeof window.AudioContext !== "function")
      return;
    try {
      const context = audio.current || new window.AudioContext();
      audio.current = context;
      const start = () => {
        // A quiet, finite melody. An error uses a warm rising interval, never a buzzer.
        const notes =
          kind === "encourage"
            ? [293.66, 349.23]
            : kind === "complete"
              ? [523.25, 659.25, 783.99, 1046.5]
              : [659.25, 783.99, 1046.5];
        notes.forEach((frequency, i) => {
          const oscillator = context.createOscillator();
          const gain = context.createGain();
          const at = context.currentTime + i * 0.095;
          oscillator.type = "sine";
          oscillator.frequency.value = frequency;
          gain.gain.setValueAtTime(0, at);
          gain.gain.linearRampToValueAtTime(0.045, at + 0.012);
          gain.gain.exponentialRampToValueAtTime(0.001, at + 0.23);
          oscillator.connect(gain);
          gain.connect(context.destination);
          oscillator.start(at);
          oscillator.stop(at + 0.25);
          oscillator.onended = () => {
            oscillator.disconnect();
            gain.disconnect();
          };
        });
      };
      if (context.state === "suspended")
        void context
          .resume()
          .then(start)
          .catch(() => {});
      else if (context.state === "running") start();
    } catch {
      // Sound is progressive enhancement and must never interrupt studying.
    }
  }, []);

  const emit = useCallback(
    (reward: Omit<RewardEvent, "id">) => {
      const xp = Number.isFinite(reward.xp)
        ? Math.max(0, Math.round(reward.xp))
        : 0;
      setFeedback({ ...reward, xp, id: ++sequence.current });
      play(reward.kind);
    },
    [play],
  );

  useEffect(() => {
    if (!feedback) return;
    const timer = window.setTimeout(() => setFeedback(null), 2800);
    return () => window.clearTimeout(timer);
  }, [feedback]);

  const toggleSound = useCallback(() => {
    const enabled = !soundEnabled.current;
    soundEnabled.current = enabled;
    setSound(enabled);
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify({ sound: enabled }));
    } catch {}
    if (enabled) play("correct");
    else if (audio.current?.state === "running")
      void audio.current.suspend().catch(() => {});
  }, [play]);

  const value = useMemo(
    () => ({ feedback, emit, sound, toggleSound }),
    [feedback, emit, sound, toggleSound],
  );
  return (
    <MotionConfig
      reducedMotion="user"
      transition={{ type: "spring", stiffness: 340, damping: 28 }}
    >
      <ExperienceContext.Provider value={value}>
        {children}
        <RewardEffects />
      </ExperienceContext.Provider>
    </MotionConfig>
  );
}

export function useExperience() {
  const context = useContext(ExperienceContext);
  if (!context) throw new Error("ExperienceProvider is required.");
  return context;
}

export function SoundToggle() {
  const { sound, toggleSound } = useExperience();
  return (
    <MotionButton
      type="button"
      className={`sound-toggle icon-button ${sound ? "enabled" : ""}`}
      aria-label="Sons de recompensa"
      aria-pressed={sound}
      title={sound ? "Desativar sons" : "Ativar sons"}
      onClick={toggleSound}
    >
      {sound ? <Volume2 size={19} /> : <VolumeX size={19} />}
    </MotionButton>
  );
}

export function ExperienceSettings() {
  return (
    <div className="flex items-center justify-between gap-4 rounded-xl border-2 border-solid border-slate-200 bg-white p-4">
      <div className="min-w-0">
        <strong className="block text-xs font-extrabold text-slate-800">
          Uma jornada com som
        </strong>
        <p className="mt-2 text-[11px] leading-relaxed text-slate-600">
          Ative sons suaves para comemorar seus acertos. As animações respeitam
          a preferência de movimento do dispositivo.
        </p>
      </div>
      <SoundToggle />
    </div>
  );
}

/** A local canvas also works inside the browser's dialog top layer. */
export function RewardCanvas({ event }: { event: RewardEvent | null }) {
  const ref = useRef<HTMLCanvasElement>(null);
  const reduce = useMotionPreference();
  useEffect(() => {
    if (
      !event ||
      reduce ||
      !["correct", "complete", "chest"].includes(event.kind)
    )
      return;
    let cancelled = false;
    let reset = () => {};
    void import("canvas-confetti")
      .then(({ default: confetti }) => {
        if (cancelled || !ref.current) return;
        const burst = confetti.create(ref.current, {
          resize: true,
          useWorker: false,
        });
        reset = () => burst.reset();
        void burst({
          particleCount: event.kind === "complete" ? 100 : 32,
          spread: event.kind === "complete" ? 95 : 65,
          startVelocity: 30,
          gravity: 1.1,
          ticks: 145,
          scalar: 0.9,
          origin: { x: 0.5, y: event.kind === "complete" ? 0.36 : 0.65 },
          colors: ["#FFD52E", "#7028EF", "#21B881", "#2155EF", "#FF5670"],
          disableForReducedMotion: true,
        });
      })
      .catch(() => {});
    return () => {
      cancelled = true;
      reset();
    };
  }, [event?.id, reduce]);
  return (
    <canvas
      ref={ref}
      className="reward-canvas"
      aria-hidden="true"
      data-testid="reward-canvas"
    />
  );
}

function RewardEffects() {
  const { feedback } = useExperience();
  const reduce = useMotionPreference();
  const event =
    feedback && feedback.kind !== "complete" && feedback.kind !== "chest"
      ? feedback
      : null;
  return (
    <>
      <AnimatePresence>
        {event && !reduce && (
          <motion.div
            key={event.id}
            className={`reward-effects ${event.kind}`}
            aria-hidden="true"
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="screen-reaction"
              initial={{ opacity: 0 }}
              animate={{ opacity: [0, 0.75, 0] }}
              transition={{ duration: 1.2 }}
            />
            {event.xp > 0 && (
              <>
                <motion.div
                  className="floating-xp"
                  data-testid="floating-xp"
                  initial={{ opacity: 0, y: 20, scale: 0.65 }}
                  animate={{
                    opacity: [0, 1, 1, 0],
                    y: [20, -25, -80, -130],
                    scale: [0.65, 1.1, 1, 1],
                  }}
                  transition={{ duration: 2.1, times: [0, 0.2, 0.7, 1] }}
                >
                  <Zap size={23} fill="currentColor" />+{event.xp} XP
                </motion.div>
                {Array.from({ length: 7 }, (_, i) => (
                  <motion.span
                    className={`reward-particle particle-${i % 3}`}
                    key={i}
                    initial={{ x: 0, y: 10, opacity: 0, scale: 0.3 }}
                    animate={{
                      x: (i - 3) * 32,
                      y: -100 - (i % 3) * 27,
                      opacity: [0, 1, 1, 0],
                      scale: [0.3, 1, 0.9],
                      rotate: (i - 3) * 23,
                    }}
                    transition={{ duration: 1.6, delay: i * 0.045 }}
                  >
                    {i % 2 ? (
                      <Gem size={20} fill="currentColor" />
                    ) : (
                      <Sparkles size={20} />
                    )}
                  </motion.span>
                ))}
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
      <RewardCanvas event={event} />
      <div className="sr-only" aria-live="polite" aria-atomic="true">
        {feedback?.levelUp
          ? `Novo nível desbloqueado: nível ${feedback.levelUp}!`
          : ""}
      </div>
    </>
  );
}
