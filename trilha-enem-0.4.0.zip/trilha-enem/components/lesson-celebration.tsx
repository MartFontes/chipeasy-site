"use client";
import { useMotionPreference } from "./use-motion-preference";

import { useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Flame, Star, X, Zap } from "lucide-react";
import { Capybara } from "./capybara";
import { MotionButton } from "./motion-button";
import { RewardCanvas, useExperience } from "./experience-provider";

export type Completion = {
  title: string;
  total: number;
  correct: number;
  xp: number;
  streak: number;
  journey: boolean;
};

export function LessonCelebration({
  result,
  onClose,
}: {
  result: Completion;
  onClose: () => void;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const reduce = useMotionPreference();
  const { feedback } = useExperience();
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const element = ref.current;
    const overflow = document.body.style.overflow;
    element?.showModal();
    document.body.style.overflow = "hidden";
    return () => {
      element?.close();
      document.body.style.overflow = overflow;
      if (previous?.isConnected) previous.focus();
    };
  }, []);
  const stars =
    result.correct === result.total
      ? 3
      : result.correct / result.total >= 0.6
        ? 2
        : 1;
  return (
    <dialog
      ref={ref}
      className="lesson-celebration reward-dialog"
      onCancel={(e) => {
        e.preventDefault();
        onClose();
      }}
      aria-labelledby="celebration-title"
      aria-describedby="celebration-description"
    >
      <RewardCanvas event={feedback?.kind === "complete" ? feedback : null} />
      <MotionButton
        className="icon-button reward-dialog-close"
        aria-label="Fechar celebração"
        onClick={onClose}
        autoFocus
      >
        <X size={20} />
      </MotionButton>
      <motion.div
        initial={reduce ? false : { opacity: 0, y: 18, scale: 0.93 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
      >
        <div className="celebration-trophy">
          <Capybara mood="celebrate" reactionKey={result.title} />
        </div>
        <div
          className="celebration-stars"
          role="img"
          aria-label={`${stars} de 3 estrelas`}
        >
          {[1, 2, 3].map((n) => (
            <motion.span
              key={n}
              initial={reduce ? false : { opacity: 0, scale: 0, rotate: -35 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              transition={{
                type: "spring",
                stiffness: 240,
                damping: 14,
                delay: reduce ? 0 : 0.15 + n * 0.11,
              }}
            >
              <Star
                size={32}
                fill={n <= stars ? "currentColor" : "none"}
                className={n <= stars ? "earned" : ""}
              />
            </motion.span>
          ))}
        </div>
        <div className="eyebrow">MAIS UM PASSO NA SUA HISTÓRIA</div>
        <h2 id="celebration-title">
          {result.journey ? "Lição concluída!" : "Prática concluída!"}
        </h2>
        <p id="celebration-description">
          Você reservou um tempo para o seu futuro.
          <br />
          Isso merece uma comemoração.
        </p>
        <div className="celebration-results">
          <div>
            <Zap size={21} fill="currentColor" />
            <strong>+{result.xp} XP</strong>
            <span>nesta atividade</span>
          </div>
          <div>
            <Star size={21} />
            <strong>
              {result.correct}/{result.total}
            </strong>
            <span>respostas certas</span>
          </div>
          <div>
            <Flame size={21} fill="currentColor" />
            <strong>
              {result.streak} {result.streak === 1 ? "dia" : "dias"}
            </strong>
            <span>de sequência</span>
          </div>
        </div>
        <p className="celebration-hint">
          {result.correct === result.total
            ? "Uma lição perfeita. Continue descobrindo!"
            : "Cada erro mostra um novo caminho para aprender. Você pode revisar quando quiser."}
        </p>
        <MotionButton className="button primary" onClick={onClose}>
          {result.journey ? "Continuar minha jornada" : "Continuar estudando"}
          <ArrowRight size={18} />
        </MotionButton>
      </motion.div>
    </dialog>
  );
}
