-- Trilha ENEM: executar num projeto próprio. Não usa as tabelas do ChipEasy.
begin;
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 role text not null default 'student' check(role in ('student','admin')),
 created_at timestamptz not null default now());
create or replace function public.trilha_new_user() returns trigger
language plpgsql security definer set search_path='' as $$begin
 insert into public.profiles(id) values(new.id) on conflict do nothing;return new;
end$$;
revoke all on function public.trilha_new_user() from public,anon,authenticated;
drop trigger if exists trilha_auth_user on auth.users;
create trigger trilha_auth_user after insert on auth.users for each row execute function public.trilha_new_user();
insert into public.profiles(id) select id from auth.users on conflict do nothing;
create or replace function public.trilha_is_admin() returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.profiles where id=auth.uid() and role='admin')
$$;
revoke all on function public.trilha_is_admin() from public,anon;
grant execute on function public.trilha_is_admin() to authenticated;

create table if not exists public.questions(
 id text primary key,
 data jsonb not null check(jsonb_typeof(data)='object'),
 year integer generated always as ((data->>'year')::integer) stored,
 area text generated always as (data->>'area') stored,
 status text generated always as (data->>'status') stored,
 fingerprint text generated always as (data->>'fingerprint') stored,
 updated_at timestamptz not null default now(),
 check((id=data->>'id') is true),check(length(id) between 3 and 120),
 check((year between 1998 and 2100) is true),check((area in('linguagens','ciencias-humanas','ciencias-natureza','matematica')) is true),
 check((status in('imported','reviewed','published')) is true),check((fingerprint ~ '^[a-f0-9]{64}$') is true),
 check((jsonb_typeof(data->'alternatives')='array' and jsonb_array_length(data->'alternatives')=5) is true),
 check((status<>'published' or(data->>'answerVerified'='true' and (data->>'annulled'='true' or data->>'answer' in('A','B','C','D','E')))) is true));
create unique index if not exists trilha_question_fingerprint on public.questions(fingerprint);
create index if not exists trilha_question_filters on public.questions(status,year,area);
create table if not exists public.editions(
 id text primary key,year integer not null check(year between 1998 and 2100),application text not null,
 day smallint not null check(day in(1,2)),booklet text not null,source_url text not null,source_sha256 text not null,
 expected_questions integer,unique(year,application,day,booklet));
create table if not exists public.question_occurrences(
 id bigint generated always as identity primary key,question_id text not null references public.questions(id) on delete cascade,
 edition_id text not null references public.editions(id) on delete cascade,number integer not null,language text not null default '',
 unique(edition_id,number,language));
create table if not exists public.study_progress(
 user_id uuid primary key references auth.users(id) on delete cascade,
 data jsonb not null check(jsonb_typeof(data)='object'),updated_at timestamptz not null default now());

alter table public.profiles enable row level security;
alter table public.questions enable row level security;
alter table public.editions enable row level security;
alter table public.question_occurrences enable row level security;
alter table public.study_progress enable row level security;
revoke all on public.profiles,public.questions,public.editions,public.question_occurrences,public.study_progress from public,anon,authenticated;
grant select on public.profiles to authenticated;
grant select on public.questions,public.editions,public.question_occurrences to anon,authenticated;
grant insert,update,delete on public.questions,public.editions,public.question_occurrences to authenticated;
grant usage,select on sequence public.question_occurrences_id_seq to authenticated;
grant select on public.study_progress to authenticated;
drop policy if exists trilha_profile_self on public.profiles;
create policy trilha_profile_self on public.profiles for select to authenticated using(id=auth.uid());
drop policy if exists trilha_questions_public on public.questions;
create policy trilha_questions_public on public.questions for select to anon,authenticated using(status='published');
drop policy if exists trilha_questions_admin on public.questions;
create policy trilha_questions_admin on public.questions for all to authenticated using(public.trilha_is_admin()) with check(public.trilha_is_admin());
drop policy if exists trilha_editions_read on public.editions;
create policy trilha_editions_read on public.editions for select to anon,authenticated using(true);
drop policy if exists trilha_editions_admin on public.editions;
create policy trilha_editions_admin on public.editions for all to authenticated using(public.trilha_is_admin()) with check(public.trilha_is_admin());
drop policy if exists trilha_occurrences_read on public.question_occurrences;
create policy trilha_occurrences_read on public.question_occurrences for select to anon,authenticated using(exists(select 1 from public.questions q where q.id=question_id and q.status='published'));
drop policy if exists trilha_occurrences_admin on public.question_occurrences;
create policy trilha_occurrences_admin on public.question_occurrences for all to authenticated using(public.trilha_is_admin()) with check(public.trilha_is_admin());
drop policy if exists trilha_progress_self on public.study_progress;
create policy trilha_progress_self on public.study_progress for select to authenticated using(user_id=auth.uid());

-- Merge under a row lock: repeated sync does not duplicate attempts; per-question
-- favorite events include removals, so older devices do not restore deleted favorites.
create or replace function public.merge_study_progress(payload jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare uid uuid:=auth.uid();old jsonb;combined jsonb;attempts jsonb;sessions jsonb;events jsonb;favorites jsonb;newer jsonb;
begin
 if uid is null then raise exception 'Entre na sua conta.' using errcode='42501';end if;
 if payload is null or jsonb_typeof(payload) is distinct from 'object' or length(payload::text)>8000000
  or payload->>'version' is distinct from '1' or jsonb_typeof(payload->'attempts') is distinct from 'array' or jsonb_typeof(payload->'favorites') is distinct from 'array' or jsonb_typeof(payload->'sessions') is distinct from 'array'
  or jsonb_typeof(payload->'name') is distinct from 'string' or length(payload->>'name')>80 or coalesce(payload->>'dailyGoal','')!~'^[0-9]{1,3}$'
 then raise exception 'Progresso inválido.' using errcode='22023';end if;
 if (payload->>'dailyGoal')::int not between 1 and 200 or coalesce(payload->>'updatedAt','')='' then raise exception 'Perfil inválido.' using errcode='22023';end if;
 perform (payload->>'updatedAt')::timestamptz;
 if jsonb_array_length(payload->'attempts')>100000 or jsonb_array_length(payload->'favorites')>20000 or jsonb_array_length(payload->'sessions')>10000
  or exists(select 1 from jsonb_array_elements(payload->'attempts')a where jsonb_typeof(a)<>'object' or coalesce(a->>'id','')='' or coalesce(a->>'questionId','')='' or coalesce(a->>'selected','')not in('A','B','C','D','E') or coalesce(jsonb_typeof(a->'correct'),'')not in('boolean','null') or coalesce(a->>'answeredAt','')='' or jsonb_typeof(a->'durationMs') is distinct from 'number')
  or exists(select 1 from jsonb_array_elements(payload->'favorites')f where jsonb_typeof(f) is distinct from 'string')
  or exists(select 1 from jsonb_array_elements(payload->'sessions')s where coalesce(s->>'id','')='' or jsonb_typeof(s->'questionIds') is distinct from 'array' or coalesce(s->>'createdAt','')='')
 then raise exception 'Respostas inválidas.' using errcode='22023';end if;
 perform (a->>'answeredAt')::timestamptz from jsonb_array_elements(payload->'attempts')a;
 if payload ? 'favoriteChanges' and jsonb_typeof(payload->'favoriteChanges') is distinct from 'object' then raise exception 'Favoritos inválidos.' using errcode='22023';end if;
 if exists(select 1 from jsonb_each(coalesce(payload->'favoriteChanges','{}')) where jsonb_typeof(value->'saved') is distinct from 'boolean' or coalesce(value->>'at','')='') then raise exception 'Favoritos inválidos.' using errcode='22023';end if;
 perform (value->>'at')::timestamptz from jsonb_each(coalesce(payload->'favoriteChanges','{}'));
 insert into public.study_progress(user_id,data)values(uid,'{}')on conflict do nothing;
 select data into old from public.study_progress where user_id=uid for update;
 select coalesce(jsonb_agg(x.a order by x.a->>'answeredAt'),'[]') into attempts from(
  select distinct on(a->>'id')a from jsonb_array_elements(coalesce(old->'attempts','[]')||(payload->'attempts'))a order by a->>'id',a->>'answeredAt' desc
 )x;
 select coalesce(jsonb_agg(x.s),'[]')into sessions from(
  select distinct on(s->>'id')s from jsonb_array_elements(coalesce(old->'sessions','[]')||(payload->'sessions'))s order by s->>'id',s->>'finishedAt' desc nulls last
 )x;
 select coalesce(jsonb_object_agg(key,value),'{}')into events from(
  select distinct on(key)key,value from(
   select * from jsonb_each(coalesce(old->'favoriteChanges','{}'))union all select * from jsonb_each(coalesce(payload->'favoriteChanges','{}'))
  )e order by key,value->>'at' desc,value->>'saved' asc
 )x;
 select coalesce(jsonb_agg(x.key order by x.key),'[]')into favorites from(
  select distinct f#>>'{}' key from jsonb_array_elements(coalesce(old->'favorites','[]')||(payload->'favorites'))f
  union select key from jsonb_each(events)where value->>'saved'='true'
 )x where coalesce(events->x.key->>'saved','true')='true';
 newer:=case when coalesce(payload->>'updatedAt','')>=coalesce(old->>'updatedAt','')then payload else old end;
 combined:=jsonb_build_object('version',1,'name',coalesce(newer->>'name',''),'dailyGoal',coalesce((newer->>'dailyGoal')::int,10),'attempts',attempts,'favorites',favorites,'favoriteChanges',events,'sessions',sessions,'updatedAt',to_char(now() at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'));
 update public.study_progress set data=combined,updated_at=now()where user_id=uid;return combined;
end$$;
revoke all on function public.merge_study_progress(jsonb) from public,anon;
grant execute on function public.merge_study_progress(jsonb) to authenticated;

-- Media are public exam material. Only administrators may upload/replace them.
insert into storage.buckets(id,name,public)values('question-media','question-media',true)on conflict(id)do nothing;
drop policy if exists trilha_media_read on storage.objects;
create policy trilha_media_read on storage.objects for select to anon,authenticated using(bucket_id='question-media');
drop policy if exists trilha_media_admin on storage.objects;
create policy trilha_media_admin on storage.objects for all to authenticated using(bucket_id='question-media' and public.trilha_is_admin())with check(bucket_id='question-media' and public.trilha_is_admin());
notify pgrst,'reload schema';
commit;
