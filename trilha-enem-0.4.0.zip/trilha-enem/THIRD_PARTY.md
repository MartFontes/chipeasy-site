# Fontes e licenças

## Questões e PDFs

Provas e gabaritos produzidos pelo **Instituto Nacional de Estudos e Pesquisas Educacionais Anísio Teixeira (Inep)**. Fonte oficial: <https://www.gov.br/inep/pt-br/areas-de-atuacao/avaliacao-e-exames-educacionais/enem/provas-e-gabaritos>.

As provas incluem textos e imagens de seus respectivos autores, conforme créditos nos documentos originais preservados em `public/sources`. Não há afiliação do aplicativo ao Inep.

## Transcrição inicial

- Projeto: **API ENEM**, por yunger7 e colaboradores.
- Repositório: <https://github.com/yunger7/enem-api>.
- Commit utilizado: `938c56fbd3b391e03d93316c920a90c3e54842e5`.
- Licença declarada no repositório: **GPL-2.0**, preservada integralmente em [third-party/API-ENEM-LICENSE.txt](third-party/API-ENEM-LICENSE.txt).
- Uso: dados de questões e imagens de 2022/2023. Nenhum serviço remoto é necessário para consultar o acervo incluído. As modificações locais incluem normalização de metadados, conferência de respostas, caminhos de mídia e recuperação de conteúdo a partir dos PDFs.

## Espelho dos PDFs

- Repositório: <https://github.com/caue-paiva/ENEM_PDF_PARSER>.
- Commit: `99ce99af4f6078817ef462ce8283e28fa848149b`.
- Uso: cópias das provas e gabaritos originais do Inep. Não foi incorporado código desse parser.
- Os endereços originais, os arquivos e os SHA-256 estão em `data/import-report.json`.

## Dependências

OpenCV e NumPy são usados pela ferramenta opcional de localização de figuras nos PDFs, com versões fixadas em `requirements-media.txt`. A recuperação preserva os vetores e pixels do documento de origem.

Next.js, React, Supabase JS, Lucide, Framer Motion, canvas-confetti, Tailwind CSS, axe-core, react-markdown, remark, KaTeX, Zod e as ferramentas de desenvolvimento mantêm suas próprias licenças, distribuídas com os pacotes fixados no `package-lock.json`. A importação de PDFs usa PyMuPDF sob sua licença própria. A presença de conteúdo neste acervo não transfere direitos sobre obras de terceiros.

## Fontes e identidade visual

DM Sans e Plus Jakarta Sans são distribuídas localmente, em WOFF2, sob a SIL Open Font License 1.1. As licenças estão preservadas em `public/fonts/*-OFL.txt`. As telas não dependem de solicitações ao Google Fonts.

A Capi utilizada na interface a partir da versão 0.4.0 é um desenho próprio em SVG articulado e animado. A arte WebP da versão anterior, preservada no histórico, foi gerada para o projeto com a ferramenta de geração de imagens da OpenAI. O símbolo da Trilha e o baú são SVGs próprios. Figuras, gráficos e textos das provas continuam vindo dos documentos de origem.
