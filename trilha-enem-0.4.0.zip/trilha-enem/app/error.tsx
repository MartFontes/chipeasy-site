"use client";
import { BookOpen, RotateCcw } from "lucide-react";
import { MotionButton } from "@/components/motion-button";
export default function ErrorPage({
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <main className="document-page">
      <div className="empty-state">
        <BookOpen size={36} />
        <h1>Vamos retomar seus estudos.</h1>
        <p>
          A biblioteca não pôde ser carregada agora. Seu progresso salvo neste
          dispositivo foi preservado.
        </p>
        <MotionButton className="button primary" onClick={reset}>
          <RotateCcw size={17} />
          Tentar novamente
        </MotionButton>
      </div>
    </main>
  );
}
