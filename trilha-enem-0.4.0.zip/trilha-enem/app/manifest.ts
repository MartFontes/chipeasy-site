import type { MetadataRoute } from "next";
export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Trilha ENEM",
    short_name: "Trilha",
    description: "Um acerto de cada vez.",
    start_url: "/",
    display: "standalone",
    background_color: "#f7f8fc",
    theme_color: "#7028ef",
    lang: "pt-BR",
    icons: [
      { src: "/icon.svg", sizes: "any", type: "image/svg+xml", purpose: "any" },
    ],
  };
}
