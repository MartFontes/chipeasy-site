import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import { ExperienceProvider } from "@/components/experience-provider";
import "./tailwind.css";
import "./globals.css";
import "./journey.css";
import "./image-viewer.css";
import "./design-system.css";
import "./experience.css";
import "katex/dist/katex.min.css";
const dmSans = localFont({
  src: "../public/fonts/dm-sans-latin.woff2",
  variable: "--font-dm",
  display: "swap",
  weight: "400 800",
  adjustFontFallback: "Arial",
});
const jakarta = localFont({
  src: "../public/fonts/plus-jakarta-sans-latin.woff2",
  variable: "--font-jakarta",
  display: "swap",
  weight: "400 800",
  adjustFontFallback: "Arial",
});
export const metadata: Metadata = {
  title: {
    default: "Trilha ENEM — Um acerto de cada vez",
    template: "%s · Trilha ENEM",
  },
  description:
    "Estude com questões reais do Enem. Organize sua prática, reveja seus erros e acompanhe seus acertos.",
  applicationName: "Trilha ENEM",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Trilha ENEM",
  },
};
export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#7028ef",
};
export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR" className={`${dmSans.variable} ${jakarta.variable}`}>
      <body>
        <ExperienceProvider>{children}</ExperienceProvider>
      </body>
    </html>
  );
}
