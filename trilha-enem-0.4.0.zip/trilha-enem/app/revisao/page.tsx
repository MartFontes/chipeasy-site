import { catalog } from "@/lib/catalog";
import { ReviewApp } from "@/components/review-app";
export const metadata = { title: "Revisão do acervo" };
export default async function Page() {
  const data = await catalog();
  return <ReviewApp base={data.questions} />;
}
