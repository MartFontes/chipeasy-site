import { BrandMark } from "@/components/brand-mark";
import Link from "next/link";
import { ArrowLeft, ArrowUpRight } from "lucide-react";
import { catalog } from "@/lib/catalog";
export const metadata = { title: "Fontes e cobertura" };
export default async function Acervo() {
  const data = await catalog(),
    verified = data.questions.filter((q) => q.answerVerified).length;
  return (
    <div className="document-page">
      <header className="document-header">
        <Link className="brand" href="/">
          <span className="brand-icon">
            <BrandMark />
          </span>
          <span>
            trilha<span className="brand-enem">ENEM</span>
          </span>
        </Link>
        <Link className="button secondary" href="/">
          <ArrowLeft size={15} />
          Voltar aos estudos
        </Link>
      </header>
      <div className="eyebrow muted">SAIBA O QUE VOCÊ ESTÁ ESTUDANDO</div>
      <h1>Um acervo com origem e transparência.</h1>
      <p className="help-text">
        Esta é a biblioteca inicial do Trilha ENEM. Aqui você acompanha quais
        edições já estão disponíveis. A cobertura de todos os anos e aplicações
        ainda está em construção.
      </p>
      <div className="stats-grid">
        <div className="stat-card">
          <div>
            <p>Questões disponíveis</p>
            <strong>{data.questions.length}</strong>
            <small>com inglês e espanhol</small>
          </div>
        </div>
        <div className="stat-card">
          <div>
            <p>Gabaritos conferidos</p>
            <strong>{verified}</strong>
            <small>comparados aos PDFs do Inep</small>
          </div>
        </div>
        <div className="stat-card">
          <div>
            <p>Edições regulares</p>
            <strong>{data.coverage.length}</strong>
            <small>caderno azul, dois dias</small>
          </div>
        </div>
        <div className="stat-card">
          <div>
            <p>Resoluções comentadas</p>
            <strong>
              {data.questions.filter((q) => q.explanation).length}
            </strong>
            <small>revisadas no acervo inicial</small>
          </div>
        </div>
      </div>
      <div className="coverage-table">
        <table>
          <thead>
            <tr>
              <th>Edição</th>
              <th>Disponíveis</th>
              <th>Esperadas</th>
              <th>Situação</th>
            </tr>
          </thead>
          <tbody>
            {data.coverage.map((c) => (
              <tr key={c.year}>
                <td>
                  <b>ENEM {c.year}</b>
                  <br />
                  {c.edition}
                </td>
                <td>{c.available}</td>
                <td>{c.expected || "A conferir"}</td>
                <td>
                  {c.missing.length
                    ? `Faltam ${c.missing.join(", ")}`
                    : c.status}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="document-note">
        <h2>De onde vêm as questões?</h2>
        <p>
          As provas e os gabaritos são produzidos pelo Inep. A transcrição
          inicial usa a{" "}
          <a
            href="https://github.com/yunger7/enem-api"
            target="_blank"
            rel="noopener noreferrer"
          >
            API ENEM, de yunger7
          </a>
          . Os gabaritos foram comparados aos PDFs do Inep preservados em{" "}
          <a
            href="https://github.com/caue-paiva/ENEM_PDF_PARSER"
            target="_blank"
            rel="noopener noreferrer"
          >
            um espelho público no GitHub
          </a>
          . Quando a transcrição não estava disponível, a questão foi preservada
          como recorte do PDF.
        </p>
        <p>
          Os arquivos de origem, seus endereços e hashes estão registrados no
          relatório de importação. A conferência automática de estrutura e
          gabarito não substitui a revisão editorial das transcrições. Questões
          anuladas não entram na taxa de acertos.
        </p>
        <p>
          <a
            href="https://www.gov.br/inep/pt-br/areas-de-atuacao/avaliacao-e-exames-educacionais/enem/provas-e-gabaritos"
            target="_blank"
            rel="noopener noreferrer"
          >
            Consultar provas e gabaritos no Inep <ArrowUpRight size={13} />
          </a>
        </p>
      </div>
      <div className="document-note">
        <h2>Por que 185 questões por edição?</h2>
        <p>
          O aluno responde 180 questões na prova. O acervo guarda as cinco
          questões de inglês e as cinco de espanhol, que são opções
          alternativas, totalizando 185 itens por edição completa. Uma prática
          seleciona apenas a língua estrangeira escolhida.
        </p>
      </div>
    </div>
  );
}
