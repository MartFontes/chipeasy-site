import { catalog } from "@/lib/catalog";
import { StudyApp } from "@/components/study-app";
export default async function Home() {
  const data = await catalog();
  return <StudyApp questions={data.questions} coverage={data.coverage} />;
}
