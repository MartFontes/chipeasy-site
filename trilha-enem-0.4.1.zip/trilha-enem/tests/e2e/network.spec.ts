import { test, expect } from "@playwright/test";
import { readFileSync } from "node:fs";
import type { Question } from "../../lib/types";

const questions: Question[] = JSON.parse(
  readFileSync("data/catalog.json", "utf8"),
).questions;
const plan = JSON.parse(readFileSync("data/journey-plan.json", "utf8"));
const first = questions.find(
  (q) => q.id === plan.worlds[0].lessons[0].questionIds[0],
)!;

test("HTTP fora de localhost permite começar, responder e retomar uma lição", async ({
  page,
  baseURL,
}) => {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("console", (message) => {
    if (message.type() === "error") errors.push(message.text());
  });
  const origin = process.env.LAN_TEST_URL || "http://celular.trilha-enem.test";
  // Use a real insecure browser origin while forwarding requests to the local test server.
  if (!process.env.LAN_TEST_URL)
    await page.route(origin + "/**", async (route) => {
      const request = new URL(route.request().url());
      const response = await route.fetch({
        url: baseURL + request.pathname + request.search,
      });
      await route.fulfill({ response });
    });
  await page.goto(origin);
  expect(await page.evaluate(() => window.isSecureContext)).toBe(false);
  expect(await page.evaluate(() => typeof crypto.randomUUID)).toBe("undefined");
  await page
    .getByRole("button", { name: "Começar minha jornada", exact: true })
    .click();
  await expect(page.getByRole("dialog")).toBeVisible();
  await page
    .locator(".alternative")
    .filter({
      has: page.locator(`input[value="${first.answer}"]`),
    })
    .click();
  await page
    .getByRole("button", { name: "Conferir resposta", exact: true })
    .click();
  await expect(page.locator(".answer-xp")).toHaveText("+20 XP conquistados");
  await page
    .getByRole("button", { name: "Fechar questão", exact: true })
    .click();
  await page.reload();
  await expect(page.getByTestId("xp-total")).toHaveText("20");
  await page
    .getByRole("button", { name: "Continuar minha jornada", exact: true })
    .click();
  await expect(page.getByRole("dialog")).toBeVisible();
  const saved = await page.evaluate(() =>
    JSON.parse(localStorage.getItem("trilha-enem.progress.v1.guest")!),
  );
  expect(saved.sessions).toHaveLength(1);
  expect(saved.attempts).toHaveLength(1);
  expect(saved.attempts[0].id).toMatch(
    /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i,
  );
  expect(errors).toEqual([]);
});
