# Trilha ENEM

Aplicativo web de estudo para celular e computador. Versão **0.4.1**, construída em um projeto separado do ChipEasy.

## O que funciona

- Interface gamificada com paleta saturada, Tailwind CSS 4, botões com mola e capivara em SVG que reage às respostas com Framer Motion. XP flutuante, baú diário articulado, confetes, barras animadas e sons opcionais. Respeita movimento reduzido. Veja a [direção visual](docs/DESIGN.md) e os [estados de interação](docs/INTERACOES.md).

- Jornada com **72 lições**, quatro caminhos, etapas desbloqueáveis, XP, níveis, estrelas, missões diárias, seis conquistas e sequência de dias de estudo. O histórico anterior já conta. Veja as [regras da jornada](docs/JORNADA.md).
- Figuras recuperadas dos vetores dos PDFs e visualizador com zoom dentro da questão, incluindo no celular. Veja o [relatório de qualidade das imagens](docs/IMAGENS.md).
- Biblioteca com **370 questões reais** das aplicações regulares de 2022 e 2023, caderno azul, dois dias e as duas línguas estrangeiras. Cada edição tem 180 questões na prova e 185 itens no acervo por guardar inglês e espanhol.
- Busca, filtros por ano, área, língua e situação; alternativas, correção, imagens, fórmulas e fontes.
- Histórico de respostas, caderno de erros, favoritos, meta diária, desempenho e práticas sorteadas retomáveis.
- Progresso no navegador, exportação e importação de backup sem duplicar tentativas.
- Painel `/revisao` para importar lotes JSON, corrigir, conferir gabaritos e aprovar questões. Sem Supabase, as edições são locais ao navegador e exportáveis.
- Importador de PDFs com gabarito, recortes que preservam gráficos e fórmulas e OCR opcional. Nenhum lote novo é publicado automaticamente.
- Integração opcional com Supabase Auth, administração por perfil e progresso por usuário com RLS. Veja [configuração do banco](docs/SUPABASE.md).

## Executar

Use **Node.js 24 LTS** e npm. Python só é necessário para importar ou verificar PDFs.

```sh
npm ci
npm run dev
```

O terminal informa o endereço local na porta 3100. Para compilar e executar a versão de produção:

```sh
npm run build
npm start
```

Não é necessário preencher `.env.local` para estudar: o modo inicial salva neste dispositivo. O navegador precisa permitir armazenamento local. Limpar os dados do site apaga essa cópia; use a exportação em **Meu perfil**.

No ambiente de nuvem preparado, use `npm --cache /tmp/enem-npm-cache ci`, pois o diretório padrão de cache do npm pode estar indisponível.

## Testar no celular pela rede Wi-Fi

A versão **0.4.1** permite iniciar e responder lições por HTTP na rede local. O progresso continua sendo salvo separadamente em cada navegador.

1. Conecte o computador e o celular à mesma rede Wi-Fi.
2. Pare o servidor anterior com **Ctrl+C** e abra o terminal na pasta do projeto atualizado.
3. Execute `npm ci` e depois `npm run dev:rede`. Esse comando permite acesso pelos outros aparelhos da rede; `npm run dev` continua disponível para uso apenas no próprio computador.
4. No Windows, abra outro Prompt de Comando, execute `ipconfig` e localize o **Endereço IPv4** do adaptador Wi-Fi.
5. No navegador do celular, digite `http://IP-DO-COMPUTADOR:3100`. Exemplo: `http://192.168.1.20:3100`. Troque o endereço pelo IPv4 encontrado no seu computador.
6. Se o Windows solicitar permissão de acesso à rede, permita nas redes privadas. Mantenha o computador ligado e o terminal do servidor aberto durante o teste.

No celular, `localhost` aponta para o próprio telefone. Para levar o histórico de outro aparelho, use **Meu perfil → Exportar meu progresso / Importar progresso**. A instalação como aplicativo e o cache offline precisam de HTTPS em uma hospedagem; as atividades de estudo funcionam no acesso HTTP da rede local.

## Conferência

```sh
npm run typecheck
npm test
python3 -m unittest discover -s tests -p 'test_*.py' -v
npm run test:e2e
npm run build
```

Os testes de banco usam PostgreSQL via PGlite, sem acessar Supabase real. Os testes de navegador usam Chromium instalado no sistema ou `CHROMIUM_PATH`; em outro computador, `npx playwright install chromium` instala o navegador gerenciado. Os testes de PDF precisam de `python3 -m pip install -r requirements.txt`.

## Alimentar a biblioteca

O fluxo é **prova + gabarito → lote de importação → revisão → publicação**. Consulte [importação e proveniência](docs/IMPORTACAO.md). Os PDFs e imagens da biblioteca inicial acompanham o projeto: o aplicativo não depende de uma API externa para mostrar essas questões. A página `/acervo` informa cobertura e fontes.

## Escopo desta entrega

É uma primeira versão funcional, ainda não o catálogo completo de todas as edições. Os 370 gabaritos foram comparados aos PDFs preservados do Inep; a revisão editorial integral das transcrições continua pendente. Há **5 resoluções comentadas** conferidas. Questões recuperadas como imagem precisam de transcrição acessível. As práticas mostram percentual de acertos, **sem estimar nota TRI**.

A integração com Supabase tem migração e permissões testadas localmente, mas ainda não foi ativada num serviço de produção. Login por e-mail, entrega de mensagens, sincronização pela rede e publicação em um domínio precisam de configuração e teste nesse serviço. Não há cobrança, recuperação de senha na interface, painel de suporte, redação ou garantia de início totalmente offline. O service worker guarda apenas imagens de questões já consultadas.

Para evoluir até o lançamento: ativar hospedagem e banco próprios, revisar os conteúdos e acessibilidade, ampliar as edições pelo importador e validar a operação com alunos antes de habilitar cobrança.

## Estrutura

| Pasta                                | Responsabilidade                                         |
| ------------------------------------ | -------------------------------------------------------- |
| `app`, `components`                  | Telas de estudo, fontes e revisão                        |
| `lib`                                | Tipos, validação, catálogo, filtros e progresso          |
| `data`                               | Biblioteca, resoluções e relatório de importação         |
| `public/questions`, `public/sources` | Imagens e PDFs preservados                               |
| `tools`                              | Download, importação e geração de carga SQL              |
| `supabase`                           | Migração e carga inicial                                 |
| `tests`                              | Regras de estudo, permissões, PDFs e fluxos de navegador |

As dependências estão fixadas no lockfile. As fontes e licenças dos dados estão em [THIRD_PARTY.md](THIRD_PARTY.md).

Veja as [telas do aplicativo e os resultados da validação](docs/VALIDACAO.md).
